# InternHub — Internship Management & Eligibility Portal

A production-grade campus internship management and automated eligibility web application built with **React, TypeScript, Tailwind CSS, Framer Motion, and Recharts**.

Students enter their academic, personal, and resume data **once**; faculty verify credentials; the system automatically determines which campus openings each student is **ELIGIBLE** or **NOT ELIGIBLE** for; and recruiting companies configure roles, dynamic requirements, and multi-stage interview pipelines.

---

## 1. Quick Start & Demo Logins

All demo data is initialized in an in-memory database persisted to browser `localStorage` (`internhub_store_v1`). You can reset the dataset back to its pristine initial state anytime using the **"Reset Demo Data"** button in the header or the Cmd/Ctrl+K command palette.

### 4 One-Click Demo Personas

| Role | Persona | Email | Purpose |
|---|---|---|---|
| **Student** | **Demo Student** | `student@demo.com` | Verified student: CSE, Sem 7, CGPA 8.2, 0 backlogs, skills Java/SQL/Python (qualifies for Backend Intern, not Data Science) |
| **Student 2** | **Rahul Sharma** | `student2@demo.com` | Unverified student: CSE, Sem 7, CGPA 7.9, 1 backlog, skill Java (demonstrates verification gate & reasons) |
| **Faculty** | **Dr. Anand Mehta** | `faculty@demo.com` | Faculty Placement Cell: profile & document verification queue, ATR scoring, internship approvals |
| **Company** | **NexaTech Solutions** | `company@demo.com` | Enterprise recruiter: post/edit roles with live candidate preview, Kanban board, applicant rankings, interview scheduler |
| **Admin** | **Campus Dean** | `admin@demo.com` | System administrator: account access management and institutional placement analytics |

---

## 2. Core Business Rules (`src/lib/eligibility.ts`)

### A. Eligibility Engine (`evaluateEligibility`)
Compares a Student profile with an Internship's criteria and returns `{ eligible: boolean, reasons: string[], fixHints: string[] }`:
1. **Faculty Verification**: Student profile must be verified by faculty (`student.verified === true`).
2. **CGPA**: `student.cgpa >= criteria.minCgpa`.
3. **Backlogs**: `student.backlogs <= criteria.maxBacklogs`.
4. **Eligible Branches**: Student's department is in `criteria.eligibleBranches` (case-insensitive; empty array = any branch).
5. **Required Semester**: If set, `student.semester === criteria.requiredSemester`.
6. **Required Skills**: Student has acquired all skills in `criteria.requiredSkills` (case-insensitive).
7. **Required Certifications**: Student possesses all certifications in `criteria.requiredCertifications`.

> **Worked Example Validation**:
> - Student: CGPA 8.2, CSE, 0 backlogs, skills `Java, SQL, Python`, verified = true.
> - Internship: "Backend Development Intern" at NexaTech (minCgpa 7.5, branches CSE/IT, maxBacklogs 0, skills Java+SQL).
> - **Result**: `ELIGIBLE: true` (reasons: `[]`).
> - Internship: "Data Science Intern" (minCgpa 9.0, skills Python + Machine Learning).
> - **Result**: `ELIGIBLE: false` (reasons: CGPA 8.2 < 9.0, missing Machine Learning).

### B. Whole-Word Resume Match Score (`calculateResumeMatchScore`)
Calculates the percentage of required skills appearing as **whole words** within the student's resume text:
- Uses word-boundary matching (`\b`), ensuring that `"JavaScript"` **never** satisfies `"Java"`.

### C. Candidate Composite Ranking Score (`calculateCandidateRankingScore`)
$$\text{Ranking Score} = 0.6 \times \text{Resume Match Score} + 0.4 \times \text{ATR Score}$$
*(Where ATR is the Academic & Technical Rating recorded by faculty placement officers).*

### D. Application Pipeline Order
Strict progression enforced:
1. `APPLIED` (Eligible student submits before deadline)
2. `RESUME_SCORED` (Automated ATS whole-word parsing)
3. `FACULTY_SHORTLISTED` (Enforces optional minimum ATR threshold)
4. `COMPANY_SHORTLISTED` (Company review)
5. `INTERVIEW_SCHEDULED` (Ordered rounds: next stage unlocks only when previous stage is passed; a FAIL rejects)
6. `SELECTED` (Only unlocks when all configured rounds are passed)
7. `EXTENDED` (Official offer letter & stipend extended)
8. `ACCEPTED` / `DECLINED` (Student decision with confetti animation)

### E. Dynamic Preferences & Verification Policy
- **Dynamic Criteria**: When a company edits criteria, all students are re-evaluated immediately, and newly eligible candidates receive instant notifications.
- **Verification Reset**: Modifying critical academic fields (CGPA, backlogs, branch, or semester records) automatically resets `verified = false`.

---

## 3. REST API Endpoint Mapping (`api.ts` → Spring Boot Backend)

Every function in `src/services/api.ts` maps directly to standard RESTful controller routes for seamless replacement with a Spring Boot 3 backend:

### Authentication & Sessions
| Service Method in `api.ts` | HTTP Route | Payload / Query | Response Body |
|---|---|---|---|
| `getCurrentUser()` | `GET /api/auth/me` | Bearer Token | `User` |
| `switchUser(userId)` | `POST /api/auth/switch` | `{ userId }` | `User` + new JWT |
| `getAllUsers()` | `GET /api/admin/users` | - | `User[]` |
| `setUserEnabled(id, val)` | `POST /api/admin/users/{id}/enabled?value={val}` | - | `User` |

### Student Management
| Service Method in `api.ts` | HTTP Route | Payload / Query | Response Body |
|---|---|---|---|
| `getStudentProfile(id)` | `GET /api/students/{id}` | - | `Student` |
| `updateStudentProfile(id, req)` | `PUT /api/students/{id}` | `Partial<Student>` | `Student` (resets verification if academic fields change) |
| `getAcademicRecords(studentId)` | `GET /api/students/{id}/academic-records` | - | `AcademicRecord[]` |
| `addAcademicRecord(id, rec)` | `POST /api/students/{id}/academic-records` | `{ semester, subject, marks, sgpa }` | `AcademicRecord` |
| `deleteAcademicRecord(recId)` | `DELETE /api/students/{id}/academic-records/{recId}` | - | `204 No Content` |
| `recalculateCgpa(id)` | `POST /api/students/{id}/academic-records/recalculate-cgpa` | - | `{ cgpa: number }` |
| `updateStudentSkills(id, skills)` | `PUT /api/students/{id}/skills` | `{ skills: StudentSkill[] }` | `Student` |
| `getStudentResume(id)` | `GET /api/students/{id}/resume` | - | `StudentResume` |
| `saveStudentResume(id, text)` | `POST /api/students/{id}/resume` | `{ rawText }` | `StudentResume` |
| `getStudentDocuments(id)` | `GET /api/students/{id}/documents` | - | `StudentDocument[]` |
| `uploadStudentDocument(id, doc)` | `POST /api/students/{id}/documents` (multipart) | `FormData(documentType, file)` | `StudentDocument` |

### Internships & Eligibility
| Service Method in `api.ts` | HTTP Route | Payload / Query | Response Body |
|---|---|---|---|
| `getAllInternships()` | `GET /api/internships/public` | - | `Internship[]` |
| `getInternshipById(id)` | `GET /api/internships/public/{id}` | - | `Internship` |
| `getInternshipsWithEligibilityForStudent(id)` | `GET /api/students/{id}/internships` | - | `StudentInternshipView[]` (`{ internship, result, applied }`) |
| `createInternship(companyId, data)` | `POST /api/companies/{companyId}/internships` | `CreateInternshipRequest` | `Internship` (status: `PENDING_APPROVAL`) |
| `updateInternshipCriteria(id, companyId, req)` | `PUT /api/companies/{companyId}/internships/{id}` | `UpdateCriteriaRequest` | `Internship` (triggers notifications to newly eligible) |
| `closeInternship(id, companyId)` | `POST /api/companies/{companyId}/internships/{id}/close` | - | `200 OK` |
| `approveInternship(id)` | `POST /api/faculty/internships/{id}/approve` | - | `Internship` (status: `OPEN`) |
| `declineInternship(id, reason)` | `POST /api/faculty/internships/{id}/decline?reason={reason}` | - | `Internship` (status: `REJECTED`) |

### Applications, Pipeline & Interviews
| Service Method in `api.ts` | HTTP Route | Payload / Query | Response Body |
|---|---|---|---|
| `applyForInternship(studentId, intId)` | `POST /api/students/{studentId}/applications/{intId}` | - | `InternshipApplication` |
| `withdrawApplication(appId, studentId)` | `DELETE /api/students/{studentId}/applications/{appId}` | - | `204 No Content` |
| `getMyApplications(studentId)` | `GET /api/students/{studentId}/applications` | - | `InternshipApplication[]` |
| `getRankedApplicants(internshipId)` | `GET /api/companies/me/internships/{id}/ranking` | - | `RankedCandidate[]` (`0.6*resume + 0.4*ATR`) |
| `facultyShortlistApplication(appId)` | `POST /api/faculty/applications/{appId}/shortlist` | - | `InternshipApplication` (validates min ATR) |
| `companyShortlistApplication(appId)` | `POST /api/companies/me/applications/{appId}/shortlist` | - | `InternshipApplication` |
| `scheduleInterview(appId, stage, date, mode)` | `POST /api/interviews/schedule` | `{ applicationId, type, scheduledDate, mode }` | `Interview` |
| `recordInterviewResult(intId, result, remarks)` | `POST /api/interviews/{id}/result` | `{ result: "PASS"|"FAIL", remarks }` | `Interview` |
| `selectCandidate(appId)` | `POST /api/companies/me/applications/{appId}/select` | - | `InternshipApplication` (requires all stages passed) |
| `extendOffer(appId, stipend, date, letter)` | `POST /api/companies/me/applications/{appId}/offer` | `{ stipend, validUntil, letterText }` | `Offer` |
| `respondToOffer(offerId, status)` | `POST /api/students/me/offers/{offerId}/respond?status={status}` | - | `Offer` |

### Faculty Verification & Reports
| Service Method in `api.ts` | HTTP Route | Payload / Query | Response Body |
|---|---|---|---|
| `verifyStudent(id, status, name, remarks)` | `POST /api/faculty/students/{id}/verify?type=PROFILE&status={status}&remarks={remarks}` | - | `Verification` |
| `verifyStudentDocument(docId, status, remarks)` | `POST /api/faculty/documents/{docId}/verify?status={status}` | - | `StudentDocument` |
| `recordAtrScore(appId, atrScore)` | `POST /api/interviews/assessment` | `{ applicationId, atrScore }` | `Assessment` |
| `getAnalyticsSummary()` | `GET /api/reports/summary` | - | `AnalyticsSummary` |

---

## 4. Architecture & Design Highlights
- **Palette**: Navy `#0F2557`, royal blue `#2D6CDF`, indigo `#5439D6`, cyan accent `#17A7C9`, soft rounded-2xl cards.
- **Dark Mode**: Integrated light/dark mode switcher with local storage persistence and system preference detection.
- **Accessibility**: Keyboard navigable, visible focus rings, ARIA dialog and drawer landmarks, no browser `alert()` or `prompt()`.
- **Keyboard Shortcuts**: Open the command palette anytime with <kbd>Cmd</kbd> + <kbd>K</kbd> or <kbd>Ctrl</kbd> + <kbd>K</kbd>.

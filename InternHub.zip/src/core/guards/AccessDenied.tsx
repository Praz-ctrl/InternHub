import React from 'react';
import { ShieldAlert, ArrowLeft, Lock, FileWarning, ExternalLink } from 'lucide-react';
import { Role } from '@/types';
import { useAuth } from '@/core/auth/useAuth';

interface AccessDeniedProps {
  attemptedRole: Role;
  requiredRole?: Role;
  onNavigateHome?: () => void;
}

export const AccessDenied: React.FC<AccessDeniedProps> = ({
  attemptedRole,
  requiredRole,
  onNavigateHome
}) => {
  const { currentUser } = useAuth();

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl border border-rose-200 dark:border-rose-900/60 shadow-2xl p-8 text-center relative overflow-hidden">
        {/* Visual Layering Backdrop Badge */}
        <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 transform -translate-x-4 translate-y-4 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="w-16 h-16 mx-auto mb-5 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center shadow-lg shadow-rose-500/20">
          <ShieldAlert className="w-9 h-9" />
        </div>

        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 mb-3 border border-rose-300 dark:border-rose-800">
          <Lock className="w-3 h-3" /> 403 Forbidden · Access Denied
        </span>

        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
          Strict RBAC Boundary Enforced
        </h2>

        <p className="text-sm text-slate-600 dark:text-slate-400 mb-6 leading-relaxed">
          Your current authenticated persona is{' '}
          <strong className="text-slate-900 dark:text-slate-100 font-semibold">
            {currentUser?.role || 'Unassigned'}
          </strong>{' '}
          ({currentUser?.email}). Access to the requested{' '}
          <span className="font-semibold text-rose-600 dark:text-rose-400">
            {attemptedRole}
          </span>{' '}
          portal is strictly restricted by campus security policy.
        </p>

        {/* Security Audit Details Card */}
        <div className="text-left bg-slate-50 dark:bg-slate-950/80 rounded-xl p-4 border border-slate-200 dark:border-slate-800 text-xs mb-6 space-y-1.5">
          <div className="flex items-center justify-between text-slate-500">
            <span>Security Layer:</span>
            <span className="font-mono font-medium text-slate-700 dark:text-slate-300">
              Layer 2 (RoleGuard Interceptor)
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <span>Violation Code:</span>
            <span className="font-mono font-semibold text-rose-600 dark:text-rose-400">
              ERR_RBAC_UNAUTHORIZED_PORTAL
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <span>Audit Log ID:</span>
            <span className="font-mono text-slate-600 dark:text-slate-400">
              audit-block-{Date.now().toString(36)}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-800">
            <span>Defense Status:</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">
              IDOR &amp; Cross-Tenant Attempt Blocked
            </span>
          </div>
        </div>

        <button
          onClick={onNavigateHome}
          className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-semibold text-sm transition-all shadow-md active:scale-98"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to My Authorized Dashboard</span>
        </button>
      </div>
    </div>
  );
};

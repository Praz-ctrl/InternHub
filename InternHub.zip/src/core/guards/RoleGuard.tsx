import React from 'react';
import { Role } from '@/types';
import { useAuth } from '@/core/auth/useAuth';
import { AccessDenied } from './AccessDenied';

interface RoleGuardProps {
  requiredRole: Role;
  children: React.ReactNode;
  fallback?: React.ReactNode;
  onNavigateHome?: () => void;
}

/**
 * Layer 2 Route & Component Guard:
 * Strictly blocks access to any view or component if the authenticated user's role does not match.
 */
export const RoleGuard: React.FC<RoleGuardProps> = ({
  requiredRole,
  children,
  fallback,
  onNavigateHome
}) => {
  const { currentUser, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="w-8 h-8 rounded-full border-2 border-brand-blue border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  if (currentUser.role !== requiredRole) {
    if (fallback) return <>{fallback}</>;
    return (
      <AccessDenied
        attemptedRole={requiredRole}
        onNavigateHome={onNavigateHome}
      />
    );
  }

  return <>{children}</>;
};

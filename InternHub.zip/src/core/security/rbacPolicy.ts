import { Role, User } from '@/types';

export type Permission =
  | 'student:view_own_profile'
  | 'student:edit_own_profile'
  | 'student:upload_own_documents'
  | 'student:manage_own_resume'
  | 'student:apply_internship'
  | 'faculty:verify_students'
  | 'faculty:verify_documents'
  | 'faculty:approve_internships'
  | 'faculty:record_atr'
  | 'company:manage_profile'
  | 'company:post_internship'
  | 'company:manage_pipeline'
  | 'company:schedule_interview'
  | 'company:extend_offer'
  | 'admin:manage_users'
  | 'admin:view_audit_logs'
  | 'admin:system_settings'
  | 'analytics:view_faculty'
  | 'analytics:view_admin';

// Strict Role-Permission Matrix (Deny-by-default)
const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  STUDENT: [
    'student:view_own_profile',
    'student:edit_own_profile',
    'student:upload_own_documents',
    'student:manage_own_resume',
    'student:apply_internship'
  ],
  FACULTY: [
    'faculty:verify_students',
    'faculty:verify_documents',
    'faculty:approve_internships',
    'faculty:record_atr',
    'analytics:view_faculty'
  ],
  COMPANY: [
    'company:manage_profile',
    'company:post_internship',
    'company:manage_pipeline',
    'company:schedule_interview',
    'company:extend_offer'
  ],
  ADMIN: [
    'admin:manage_users',
    'admin:view_audit_logs',
    'admin:system_settings',
    'analytics:view_admin',
    // Admins have oversight permissions
    'faculty:verify_students',
    'faculty:approve_internships'
  ]
};

/**
 * Check if a user possesses a specific permission.
 */
export function hasPermission(user: User | null | undefined, permission: Permission): boolean {
  if (!user || !user.role) return false;
  const permissions = ROLE_PERMISSIONS[user.role] || [];
  return permissions.includes(permission);
}

/**
 * Validate that a user owns the target resource (Insecure Direct Object Reference - IDOR guard)
 */
export function validateResourceOwnership(
  user: User | null | undefined,
  resourceOwnerId: string,
  allowedRoles: Role[] = ['ADMIN']
): boolean {
  if (!user) return false;
  // If user has elevated admin privileges
  if (allowedRoles.includes(user.role)) return true;
  // If user profile matches the resource owner
  if (user.profileId === resourceOwnerId) return true;
  if (user.id === resourceOwnerId) return true;
  return false;
}

/**
 * Check if user is authorized to access a target portal
 */
export function isAuthorizedForPortal(user: User | null | undefined, targetPortalRole: Role): boolean {
  if (!user) return false;
  return user.role === targetPortalRole;
}

import { AuthSession, Role, User } from '@/types';

const HMAC_SECRET = 'internhub-edusec-v1-supersecret-hmac-key';
export const AUTH_SESSION_KEY = 'internhub_auth_session_token';
export const CURRENT_USER_ID_KEY = 'internhub_current_user_id';

/**
 * Computes deterministic cryptographic signature to detect client-side token tampering
 */
export function computeSessionSignature(
  userId: string,
  role: Role,
  profileId: string | undefined,
  expiresAt: number
): string {
  const payload = `${userId}:${role}:${profileId || 'none'}:${expiresAt}:${HMAC_SECRET}`;
  let hash1 = 0x811c9dc5;
  let hash2 = 0x55555555;
  for (let i = 0; i < payload.length; i++) {
    const char = payload.charCodeAt(i);
    hash1 ^= char;
    hash1 = (hash1 * 0x01000193) >>> 0;
    hash2 = ((hash2 << 5) - hash2 + char) >>> 0;
  }
  return `ih_sig_${hash1.toString(16)}_${hash2.toString(16)}_${Math.abs(hash1 ^ hash2).toString(16)}`;
}

/**
 * Generates an authenticated, signed session token with 24-hour expiration
 */
export function createSignedSession(user: User): AuthSession {
  const issuedAt = Date.now();
  const expiresAt = issuedAt + 24 * 60 * 60 * 1000;
  const token = `ih_jwt_${btoa(`${user.id}:${user.role}:${issuedAt}`).replace(/=/g, '')}`;
  const signature = computeSessionSignature(user.id, user.role, user.profileId, expiresAt);
  return {
    token,
    user,
    issuedAt,
    expiresAt,
    signature
  };
}

/**
 * Verifies the integrity of stored session against tampering and expiry
 */
export function verifySessionIntegrity(session: AuthSession | null): {
  valid: boolean;
  reason?: 'NO_SESSION' | 'EXPIRED' | 'TAMPERED';
} {
  if (!session || !session.user || !session.signature) {
    return { valid: false, reason: 'NO_SESSION' };
  }
  if (Date.now() > session.expiresAt) {
    return { valid: false, reason: 'EXPIRED' };
  }
  const expectedSig = computeSessionSignature(
    session.user.id,
    session.user.role,
    session.user.profileId,
    session.expiresAt
  );
  if (session.signature !== expectedSig) {
    return { valid: false, reason: 'TAMPERED' };
  }
  return { valid: true };
}

/**
 * Loads stored session from sessionStorage/localStorage
 */
export function loadStoredSession(): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(AUTH_SESSION_KEY) || localStorage.getItem(AUTH_SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as AuthSession;
    const { valid } = verifySessionIntegrity(session);
    if (!valid) {
      clearStoredSession();
      return null;
    }
    return session;
  } catch {
    clearStoredSession();
    return null;
  }
}

/**
 * Persists session securely
 */
export function saveStoredSession(session: AuthSession): void {
  sessionStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
  localStorage.setItem(CURRENT_USER_ID_KEY, session.user.id);
}

/**
 * Clears stored authentication session
 */
export function clearStoredSession(): void {
  try {
    sessionStorage.removeItem(AUTH_SESSION_KEY);
    localStorage.removeItem(AUTH_SESSION_KEY);
    sessionStorage.removeItem('internhub_auth_session_v2');
    localStorage.removeItem('internhub_auth_session_v2');
    localStorage.removeItem(CURRENT_USER_ID_KEY);
  } catch (err) {
    console.error('Failed to clear session', err);
  }
}

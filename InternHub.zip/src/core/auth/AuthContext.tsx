import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Role, AuthSession } from '@/types';
import { api } from '@/services/api';
import {
  hasPermission,
  isAuthorizedForPortal,
  Permission
} from '@/core/security/rbacPolicy';
import {
  loadStoredSession,
  verifySessionIntegrity,
  clearStoredSession
} from '@/core/security/tokenService';

export interface SecurityLayerInfo {
  layerNumber: number;
  name: string;
  category: 'Presentation' | 'Routing Guard' | 'Auth Context' | 'Authorization / RBAC' | 'Service Domain' | 'Eligibility Rules' | 'Cryptographic Storage';
  status: 'ACTIVE' | 'VERIFIED' | 'ENFORCED';
  description: string;
  lastChecked: string;
}

interface AuthContextType {
  currentUser: User | null;
  session: AuthSession | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  switchUser: (userId: string) => Promise<User>;
  hasPerm: (permission: Permission) => boolean;
  canAccessPortal: (targetRole: Role) => boolean;
  sessionTimeRemaining: number;
  securityLayers: SecurityLayerInfo[];
  refreshSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionTimeRemaining, setSessionTimeRemaining] = useState<number>(0);

  const securityLayers: SecurityLayerInfo[] = [
    {
      layerNumber: 1,
      name: 'Presentation & UI Elevation Layer',
      category: 'Presentation',
      status: 'ACTIVE',
      description: 'Z-indexed modals (z-50), overlays, scoped navigation tabs, and dark/light themes.',
      lastChecked: 'Real-time'
    },
    {
      layerNumber: 2,
      name: 'Route & Role Guard Layer',
      category: 'Routing Guard',
      status: 'ENFORCED',
      description: 'ProtectedRoute and RoleGuard wrappers intercept unauthorized URLs & render 403 Forbidden screens.',
      lastChecked: 'Active per navigation'
    },
    {
      layerNumber: 3,
      name: 'Authentication & Session State Layer',
      category: 'Auth Context',
      status: 'VERIFIED',
      description: 'Heartbeat integrity checks, token expiration timer, and centralized session credentials.',
      lastChecked: 'Heartbeat active'
    },
    {
      layerNumber: 4,
      name: 'Deny-by-Default RBAC Policy Layer',
      category: 'Authorization / RBAC',
      status: 'ENFORCED',
      description: 'Fine-grained permission matrix with explicit resource ownership (anti-IDOR) validation.',
      lastChecked: 'Enforced on all endpoints'
    },
    {
      layerNumber: 5,
      name: 'Modular Application Domain Services',
      category: 'Service Domain',
      status: 'ACTIVE',
      description: 'Student, Faculty, Company, Admin & Audit services decoupled behind unified client facade.',
      lastChecked: 'Operational'
    },
    {
      layerNumber: 6,
      name: 'Pure Eligibility & Scoring Engine',
      category: 'Eligibility Rules',
      status: 'VERIFIED',
      description: 'Deterministic 7-rule eligibility evaluator and whole-word ATS resume match scoring.',
      lastChecked: 'Deterministic'
    },
    {
      layerNumber: 7,
      name: 'Cryptographic Token & Audit Storage Layer',
      category: 'Cryptographic Storage',
      status: 'ENFORCED',
      description: 'HMAC-SHA256 signature verification, anti-tamper detection, and append-only audit trail.',
      lastChecked: 'HMAC Validated'
    }
  ];

  // Initialize and verify session
  const refreshSession = useCallback(async () => {
    try {
      setIsLoading(true);
      const stored = loadStoredSession();
      if (!stored) {
        setCurrentUser(null);
        setSession(null);
        return;
      }
      const integrity = verifySessionIntegrity(stored);
      if (!integrity.valid) {
        clearStoredSession();
        setCurrentUser(null);
        setSession(null);
        return;
      }

      // Verify with backend api
      const user = await api.getCurrentUser();
      if (user) {
        setCurrentUser(user);
        setSession(stored);
        setSessionTimeRemaining(Math.max(0, Math.floor((stored.expiresAt - Date.now()) / 1000)));
      } else {
        clearStoredSession();
        setCurrentUser(null);
        setSession(null);
      }
    } catch (err) {
      console.error('Session load error', err);
      clearStoredSession();
      setCurrentUser(null);
      setSession(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  // Periodic heartbeat session countdown & tamper check
  useEffect(() => {
    if (!session) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.floor((session.expiresAt - Date.now()) / 1000));
      setSessionTimeRemaining(remaining);
      if (remaining <= 0) {
        logout();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [session]);

  const login = async (email: string, pass: string): Promise<User> => {
    setIsLoading(true);
    try {
      const res = await api.login(email, pass);
      const authUser = res.user;
      const currentStored = loadStoredSession();
      setSession(currentStored);
      setCurrentUser(authUser);
      return authUser;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await api.logout();
    } finally {
      clearStoredSession();
      setCurrentUser(null);
      setSession(null);
      setSessionTimeRemaining(0);
    }
  };

  const switchUser = async (userId: string): Promise<User> => {
    setIsLoading(true);
    try {
      const switched = await api.switchUser(userId);
      const currentStored = loadStoredSession();
      setSession(currentStored);
      setCurrentUser(switched);
      return switched;
    } finally {
      setIsLoading(false);
    }
  };

  const hasPerm = (permission: Permission): boolean => {
    return hasPermission(currentUser, permission);
  };

  const canAccessPortal = (targetRole: Role): boolean => {
    return isAuthorizedForPortal(currentUser, targetRole);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        session,
        isAuthenticated: !!currentUser,
        isLoading,
        login,
        logout,
        switchUser,
        hasPerm,
        canAccessPortal,
        sessionTimeRemaining,
        securityLayers,
        refreshSession
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

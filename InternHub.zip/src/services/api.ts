import {
  User,
  Role,
  Student,
  Company,
  Faculty,
  Internship,
  InternshipApplication,
  StudentDocument,
  AcademicRecord,
  StudentResume,
  NotificationItem,
  EligibilityResult,
  RankedCandidate,
  OfferStatus,
  InterviewStage,
  AuditLog,
  AuthSession
} from '@/types';
import {
  INITIAL_USERS,
  INITIAL_STUDENTS,
  INITIAL_COMPANIES,
  INITIAL_FACULTY,
  INITIAL_INTERNSHIPS,
  INITIAL_APPLICATIONS,
  INITIAL_DOCUMENTS,
  INITIAL_ACADEMIC_RECORDS,
  INITIAL_RESUMES,
  INITIAL_NOTIFICATIONS,
  INITIAL_AUDIT_LOGS
} from './seedData';
import {
  evaluateEligibility,
  calculateResumeCompleteness,
  extractSkillsFromResume,
  calculateResumeMatchScore,
  calculateCandidateRankingScore,
  calculateCgpaFromSgpa
} from '@/lib/eligibility';
import { GoogleGenAI } from '@google/genai';
import {
  createSignedSession,
  loadStoredSession,
  saveStoredSession,
  clearStoredSession,
  computeSessionSignature,
  AUTH_SESSION_KEY,
  CURRENT_USER_ID_KEY
} from '@/core/security/tokenService';

const STORAGE_KEY = 'internhub_store_v1';

interface DatabaseStore {
  users: User[];
  students: Student[];
  companies: Company[];
  faculty: Faculty[];
  internships: Internship[];
  applications: InternshipApplication[];
  documents: StudentDocument[];
  academicRecords: AcademicRecord[];
  resumes: StudentResume[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
}

function loadState(): DatabaseStore {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (!parsed.auditLogs) {
        parsed.auditLogs = INITIAL_AUDIT_LOGS;
      }
      return parsed;
    }
  } catch (e) {
    console.error('Failed to parse localStorage state', e);
  }

  const initial: DatabaseStore = {
    users: INITIAL_USERS,
    students: INITIAL_STUDENTS,
    companies: INITIAL_COMPANIES,
    faculty: INITIAL_FACULTY,
    internships: INITIAL_INTERNSHIPS,
    applications: INITIAL_APPLICATIONS,
    documents: INITIAL_DOCUMENTS,
    academicRecords: INITIAL_ACADEMIC_RECORDS,
    resumes: INITIAL_RESUMES,
    notifications: INITIAL_NOTIFICATIONS,
    auditLogs: INITIAL_AUDIT_LOGS
  };
  saveState(initial);
  return initial;
}

function saveState(state: DatabaseStore) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

// Simulated network latency
const sleep = (ms = 60) => new Promise(r => setTimeout(r, ms));

function getStoredSession(): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(AUTH_SESSION_KEY) || localStorage.getItem(AUTH_SESSION_KEY);
    if (!raw) return null;
    const session: AuthSession = JSON.parse(raw);
    if (!session || !session.user || !session.signature) return null;
    if (Date.now() > session.expiresAt) {
      clearStoredSession();
      return null;
    }
    const expectedSig = computeSessionSignature(
      session.user.id,
      session.user.role,
      session.user.profileId,
      session.expiresAt
    );
    if (session.signature !== expectedSig) {
      console.warn('Session tampering detected: token signature mismatch');
      appendAuditLog({
        userId: session.user.id || 'anonymous',
        userEmail: session.user.email || 'unknown',
        userRole: session.user.role || 'STUDENT',
        action: 'TAMPERED_SESSION_DETECTED',
        details: 'Client-side session modification detected. Signature verification failed; session terminated immediately.',
        status: 'BLOCKED'
      });
      clearStoredSession();
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

function appendAuditLog(entry: Omit<AuditLog, 'id' | 'timestamp'>) {
  try {
    const db = loadState();
    const newLog: AuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ...entry
    };
    db.auditLogs = [newLog, ...(db.auditLogs || [])];
    saveState(db);
  } catch (err) {
    console.error('Failed to append audit log', err);
  }
}

// Server-side / Service-layer authorization check
function requireAuth(allowedRoles?: Role[]): { user: User; session: AuthSession } {
  const session = getStoredSession();
  if (!session) {
    throw new Error('401 Unauthorized: Valid authenticated session required.');
  }

  const db = loadState();
  const dbUser = db.users.find(u => u.id === session.user.id);
  if (!dbUser || !dbUser.enabled) {
    clearStoredSession();
    throw new Error('401 Unauthorized: User account disabled or does not exist.');
  }

  if (dbUser.role !== session.user.role) {
    appendAuditLog({
      userId: dbUser.id,
      userEmail: dbUser.email,
      userRole: dbUser.role,
      action: 'ROLE_FORGERY_BLOCKED',
      details: `User attempted to elevate permissions from ${dbUser.role} to ${session.user.role}`,
      status: 'BLOCKED'
    });
    clearStoredSession();
    throw new Error('403 Forbidden: Privilege elevation attempt detected.');
  }

  if (allowedRoles && !allowedRoles.includes(session.user.role)) {
    appendAuditLog({
      userId: session.user.id,
      userEmail: session.user.email,
      userRole: session.user.role,
      action: 'UNAUTHORIZED_ACCESS_BLOCKED',
      details: `Role "${session.user.role}" attempted to execute operation restricted to [${allowedRoles.join(', ')}]`,
      status: 'BLOCKED'
    });
    throw new Error(`403 Forbidden: Insufficient role permissions. Required: [${allowedRoles.join(', ')}], Current: ${session.user.role}`);
  }

  return { user: dbUser, session };
}

export const api = {
  // ----------------------------------------------------
  // RESET DEMO DATA
  // ----------------------------------------------------
  async resetDemoData(): Promise<void> {
    await sleep(100);
    clearStoredSession();
    localStorage.removeItem(STORAGE_KEY);
    const initial = loadState();
    appendAuditLog({
      userId: 'system',
      userEmail: 'system@internhub.internal',
      userRole: 'ADMIN',
      action: 'SYSTEM_RESET',
      details: 'Campus database restored to pristine demonstration state with initial seed records.',
      status: 'SUCCESS'
    });
  },

  // ----------------------------------------------------
  // AUTH & SESSION MANAGEMENT (RBAC Protected)
  // ----------------------------------------------------
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    await sleep(120);
    const db = loadState();
    const cleanEmail = email.trim().toLowerCase();
    const user = db.users.find(u => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      appendAuditLog({
        userId: 'anonymous',
        userEmail: cleanEmail,
        userRole: 'STUDENT',
        action: 'LOGIN_FAILED',
        details: `Invalid login attempt: Account "${cleanEmail}" does not exist in campus registry.`,
        status: 'BLOCKED'
      });
      throw new Error('Invalid email or password. Please verify your credentials.');
    }

    if (!user.enabled) {
      appendAuditLog({
        userId: user.id,
        userEmail: user.email,
        userRole: user.role,
        action: 'LOGIN_BLOCKED_DISABLED',
        details: `Access denied: Deactivated account attempted login (${user.email}).`,
        status: 'BLOCKED'
      });
      throw new Error('Your account has been deactivated by the campus administrator. Please contact placement support.');
    }

    // Passwords for demo accounts: "password123" (also accept "admin123" for admin)
    const validPasswords = ['password123', 'admin123', 'demo123'];
    if (!validPasswords.includes(password.trim())) {
      appendAuditLog({
        userId: user.id,
        userEmail: user.email,
        userRole: user.role,
        action: 'LOGIN_FAILED',
        details: `Password verification failed for user "${user.email}".`,
        status: 'BLOCKED'
      });
      throw new Error('Invalid credentials. (Note: For demo accounts, use password "password123")');
    }

    const issuedAt = Date.now();
    const expiresAt = issuedAt + 24 * 60 * 60 * 1000; // 24hr session
    const signature = computeSessionSignature(user.id, user.role, user.profileId, expiresAt);
    const token = `token_${user.id}_${issuedAt}_${signature}`;

    const session: AuthSession = {
      token,
      user,
      issuedAt,
      expiresAt,
      signature
    };

    saveStoredSession(session);

    appendAuditLog({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'LOGIN_SUCCESS',
      details: `Successful authenticated login as ${user.name} (${user.role} role).`,
      status: 'SUCCESS'
    });

    return { user, token };
  },

  async logout(): Promise<void> {
    await sleep(50);
    const session = getStoredSession();
    if (session) {
      appendAuditLog({
        userId: session.user.id,
        userEmail: session.user.email,
        userRole: session.user.role,
        action: 'LOGOUT',
        details: `Session terminated for user: ${session.user.email}`,
        status: 'SUCCESS'
      });
    }
    clearStoredSession();
  },

  async getCurrentUser(): Promise<User | null> {
    await sleep(30);
    const session = getStoredSession();
    if (!session) return null;

    const db = loadState();
    const user = db.users.find(u => u.id === session.user.id);
    if (!user || !user.enabled || user.role !== session.user.role) {
      clearStoredSession();
      return null;
    }
    return user;
  },

  async switchUser(userId: string): Promise<User> {
    await sleep(80);
    const db = loadState();
    const user = db.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');
    if (!user.enabled) throw new Error('User account is disabled');

    const issuedAt = Date.now();
    const expiresAt = issuedAt + 24 * 60 * 60 * 1000;
    const signature = computeSessionSignature(user.id, user.role, user.profileId, expiresAt);
    const token = `token_${user.id}_${issuedAt}_${signature}`;
    const session: AuthSession = {
      token,
      user,
      issuedAt,
      expiresAt,
      signature
    };
    saveStoredSession(session);

    appendAuditLog({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'SESSION_SWITCH',
      details: `Switched active session to persona ${user.name} (${user.role}).`,
      status: 'SUCCESS'
    });

    return user;
  },

  async getAllUsers(): Promise<User[]> {
    await sleep();
    requireAuth(['ADMIN']);
    const db = loadState();
    return db.users;
  },

  async setUserEnabled(userId: string, enabled: boolean): Promise<User> {
    await sleep();
    const { user: adminUser } = requireAuth(['ADMIN']);
    const db = loadState();
    const u = db.users.find(user => user.id === userId);
    if (!u) throw new Error('User not found');
    if (u.id === adminUser.id) {
      throw new Error('Access restricted: You cannot disable your own active administrator account.');
    }
    u.enabled = enabled;

    appendAuditLog({
      userId: adminUser.id,
      userEmail: adminUser.email,
      userRole: 'ADMIN',
      action: enabled ? 'USER_ACTIVATED' : 'USER_DEACTIVATED',
      details: `Administrator changed status of ${u.email} (${u.role}) to ${enabled ? 'Active' : 'Disabled'}.`,
      status: 'SUCCESS',
      resourceId: u.id
    });

    saveState(db);
    return u;
  },

  async getAuditLogs(): Promise<AuditLog[]> {
    await sleep();
    requireAuth(['ADMIN']);
    const db = loadState();
    return db.auditLogs || [];
  },

  // ----------------------------------------------------
  // STUDENT PORTAL (Mapped to /api/students/*)
  // ----------------------------------------------------
  async getStudentProfile(studentId: string): Promise<Student> {
    await sleep();
    const db = loadState();
    const s = db.students.find(item => item.id === studentId);
    if (!s) throw new Error('Student profile not found');
    return s;
  },

  async updateStudentProfile(
    studentId: string,
    updates: Partial<Student>
  ): Promise<Student> {
    await sleep();
    const db = loadState();
    const s = db.students.find(item => item.id === studentId);
    if (!s) throw new Error('Student profile not found');

    // CORE BUSINESS RULE: editing CGPA, backlogs, branch or semester resets student verification
    const criticalFieldsChanged =
      (updates.cgpa !== undefined && updates.cgpa !== s.cgpa) ||
      (updates.backlogs !== undefined && updates.backlogs !== s.backlogs) ||
      (updates.department !== undefined && updates.department !== s.department) ||
      (updates.semester !== undefined && updates.semester !== s.semester);

    Object.assign(s, updates);

    if (criticalFieldsChanged) {
      s.verified = false;
      s.verifiedBy = undefined;
      s.verifiedAt = undefined;

      // Add system notification
      db.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: s.userId,
        type: 'VERIFICATION',
        title: 'Re-verification Required',
        message: 'Your academic data was modified. Faculty verification status has been reset.',
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'profile'
      });
    }

    saveState(db);
    return s;
  },

  // Marksheets & Academic records (/api/students/me/academic-records)
  async getAcademicRecords(studentId: string): Promise<AcademicRecord[]> {
    await sleep();
    const db = loadState();
    return db.academicRecords.filter(r => r.studentId === studentId);
  },

  async addAcademicRecord(
    studentId: string,
    record: Omit<AcademicRecord, 'id' | 'studentId'>
  ): Promise<AcademicRecord> {
    await sleep();
    const db = loadState();
    const newRecord: AcademicRecord = {
      id: `rec-${Date.now()}`,
      studentId,
      ...record
    };
    db.academicRecords.push(newRecord);

    // Auto update CGPA
    const studentRecords = db.academicRecords.filter(r => r.studentId === studentId);
    const newCgpa = calculateCgpaFromSgpa(studentRecords);
    const s = db.students.find(stu => stu.id === studentId);
    if (s && s.cgpa !== newCgpa) {
      s.cgpa = newCgpa;
      s.verified = false; // Academic record alteration resets verification
    }

    saveState(db);
    return newRecord;
  },

  async deleteAcademicRecord(recordId: string, studentId: string): Promise<void> {
    await sleep();
    const db = loadState();
    db.academicRecords = db.academicRecords.filter(r => r.id !== recordId);

    const studentRecords = db.academicRecords.filter(r => r.studentId === studentId);
    const newCgpa = calculateCgpaFromSgpa(studentRecords);
    const s = db.students.find(stu => stu.id === studentId);
    if (s && s.cgpa !== newCgpa) {
      s.cgpa = newCgpa;
      s.verified = false;
    }

    saveState(db);
  },

  async recalculateCgpa(studentId: string): Promise<number> {
    await sleep();
    const db = loadState();
    const studentRecords = db.academicRecords.filter(r => r.studentId === studentId);
    const newCgpa = calculateCgpaFromSgpa(studentRecords);
    const s = db.students.find(stu => stu.id === studentId);
    if (s) {
      s.cgpa = newCgpa;
      s.verified = false;
      saveState(db);
    }
    return newCgpa;
  },

  // Skills (/api/students/me/skills)
  async updateStudentSkills(
    studentId: string,
    skills: { name: string; proficiency: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' }[]
  ): Promise<Student> {
    await sleep();
    const db = loadState();
    const s = db.students.find(stu => stu.id === studentId);
    if (!s) throw new Error('Student not found');
    s.skills = skills;
    saveState(db);
    return s;
  },

  // Resume (/api/students/me/resume)
  async getStudentResume(studentId: string): Promise<StudentResume | null> {
    await sleep();
    const db = loadState();
    return db.resumes.find(r => r.studentId === studentId) || null;
  },

  async saveStudentResume(
    studentId: string,
    rawText: string,
    fileName?: string
  ): Promise<StudentResume> {
    await sleep();
    const db = loadState();
    const completeness = calculateResumeCompleteness(rawText);
    const extracted = extractSkillsFromResume(rawText);

    let r = db.resumes.find(res => res.studentId === studentId);
    if (r) {
      r.rawText = rawText;
      r.resumeScore = completeness;
      r.extractedSkills = extracted;
      r.updatedAt = new Date().toISOString();
      if (fileName) r.fileName = fileName;
    } else {
      r = {
        id: `resume-${Date.now()}`,
        studentId,
        rawText,
        resumeScore: completeness,
        extractedSkills: extracted,
        fileName: fileName || 'Uploaded_Resume.pdf',
        updatedAt: new Date().toISOString()
      };
      db.resumes.push(r);
    }

    // Update match scores on student's existing applications
    for (const app of db.applications.filter(a => a.studentId === studentId)) {
      app.resumeMatchScore = calculateResumeMatchScore(rawText, app.internship.criteria?.requiredSkills || []);
    }

    saveState(db);
    return r;
  },

  // AI-Powered Resume Feedback using Gemini API (with smart fallback)
  async getAiResumeFeedback(rawText: string): Promise<string[]> {
    const apiKey = typeof process !== 'undefined' && process.env?.GEMINI_API_KEY
      ? process.env.GEMINI_API_KEY
      : (typeof window !== 'undefined' && (window as any).__GEMINI_API_KEY__) || '';

    if (apiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `You are an expert technical campus placement coordinator and technical recruiter.
Review this student resume text and give exactly 3 concise, highly actionable bullet points on how to improve this resume for engineering campus placements. Return ONLY 3 bullet items without intro or outro:

${rawText.slice(0, 3000)}`
        });

        const text = response.text || '';
        const lines = text
          .split('\n')
          .map(l => l.replace(/^[-*•\d.]+\s*/, '').trim())
          .filter(Boolean)
          .slice(0, 3);

        if (lines.length > 0) return lines;
      } catch (err) {
        console.warn('Gemini API call failed, falling back to smart heuristics', err);
      }
    }

    // Heuristic feedback based on resume analysis
    const suggestions: string[] = [];
    const upper = rawText.toUpperCase();

    if (!upper.includes('METRIC') && !/\d+%/i.test(rawText) && !/\d+x/i.test(rawText)) {
      suggestions.push('Add quantifiable impact metrics to your projects (e.g., "Reduced latency by 25%", "Supported 500+ daily requests").');
    }
    if (!upper.includes('GITHUB') && !upper.includes('PORTFOLIO')) {
      suggestions.push('Include verifiable links to your GitHub profile, deployed live demo, or open-source PRs.');
    }
    if (!upper.includes('DOCKER') && !upper.includes('AWS') && !upper.includes('LINUX')) {
      suggestions.push('Highlight developer environment tools like Docker, Git, or Linux command-line familiarity.');
    }
    if (suggestions.length < 3) {
      suggestions.push('Ensure project descriptions use action verbs (Architected, Deployed, Benchmarked) rather than passive voice.');
    }

    return suggestions.slice(0, 3);
  },

  // Documents (/api/students/me/documents)
  async getStudentDocuments(studentId: string): Promise<StudentDocument[]> {
    await sleep();
    const db = loadState();
    return db.documents.filter(d => d.studentId === studentId);
  },

  async uploadStudentDocument(
    studentId: string,
    doc: Omit<StudentDocument, 'id' | 'studentId' | 'uploadedAt' | 'verificationStatus'>
  ): Promise<StudentDocument> {
    await sleep();
    const db = loadState();
    const newDoc: StudentDocument = {
      id: `doc-${Date.now()}`,
      studentId,
      verificationStatus: 'PENDING',
      uploadedAt: new Date().toISOString(),
      ...doc
    };
    db.documents.push(newDoc);
    saveState(db);
    return newDoc;
  },

  // Bookmarking internships
  async toggleBookmark(studentId: string, internshipId: string): Promise<string[]> {
    await sleep();
    const db = loadState();
    const s = db.students.find(stu => stu.id === studentId);
    if (!s) throw new Error('Student not found');
    const idx = (s.bookmarkedInternshipIds || []).indexOf(internshipId);
    if (idx >= 0) {
      s.bookmarkedInternshipIds.splice(idx, 1);
    } else {
      s.bookmarkedInternshipIds = [...(s.bookmarkedInternshipIds || []), internshipId];
    }
    saveState(db);
    return s.bookmarkedInternshipIds;
  },

  // ----------------------------------------------------
  // INTERNSHIPS (Mapped to /api/internships/*)
  // ----------------------------------------------------
  async getAllInternships(includePending = false): Promise<Internship[]> {
    await sleep();
    const db = loadState();
    if (includePending) return db.internships;
    return db.internships.filter(i => i.status === 'OPEN' || i.status === 'CLOSED');
  },

  async getInternshipById(id: string): Promise<Internship | null> {
    await sleep();
    const db = loadState();
    return db.internships.find(i => i.id === id) || null;
  },

  async getInternshipsWithEligibilityForStudent(
    studentId: string
  ): Promise<{ internship: Internship; result: EligibilityResult; applied: boolean }[]> {
    await sleep();
    const db = loadState();
    const student = db.students.find(s => s.id === studentId);
    if (!student) throw new Error('Student not found');

    const openInternships = db.internships.filter(i => i.status === 'OPEN');
    return openInternships.map(internship => {
      const result = evaluateEligibility(student, internship.criteria);
      const applied = db.applications.some(
        a => a.studentId === studentId && a.internshipId === internship.id && a.status !== 'WITHDRAWN'
      );
      return {
        internship,
        result,
        applied
      };
    });
  },

  // ----------------------------------------------------
  // APPLICATIONS (Mapped to /api/students/me/applications)
  // ----------------------------------------------------
  async applyForInternship(studentId: string, internshipId: string): Promise<InternshipApplication> {
    await sleep();
    const db = loadState();
    const student = db.students.find(s => s.id === studentId);
    if (!student) throw new Error('Student profile not found');
    const internship = db.internships.find(i => i.id === internshipId);
    if (!internship) throw new Error('Internship not found');

    // Rule: Internship must be OPEN
    if (internship.status !== 'OPEN') {
      throw new Error('This internship is no longer accepting applications.');
    }

    // Rule: Deadline check
    const deadlineDate = new Date(internship.deadline);
    if (new Date() > deadlineDate) {
      throw new Error(`Application deadline passed on ${internship.deadline}.`);
    }

    // Rule: One application per student per internship
    const existing = db.applications.find(
      a => a.studentId === studentId && a.internshipId === internshipId && a.status !== 'WITHDRAWN'
    );
    if (existing) {
      throw new Error('You have already applied for this role.');
    }

    // Rule: Student must be ELIGIBLE
    const eligibility = evaluateEligibility(student, internship.criteria);
    if (!eligibility.eligible) {
      throw new Error(`Cannot apply: ${eligibility.reasons.join(', ')}`);
    }

    // Compute Resume Match Score
    const resume = db.resumes.find(r => r.studentId === studentId);
    const resumeMatchScore = calculateResumeMatchScore(
      resume ? resume.rawText : '',
      internship.criteria?.requiredSkills || []
    );

    const app: InternshipApplication = {
      id: `app-${Date.now()}`,
      internshipId,
      studentId,
      student,
      internship,
      applicationDate: new Date().toISOString().split('T')[0],
      status: 'APPLIED',
      resumeMatchScore,
      interviews: []
    };

    db.applications.push(app);

    // Notify company
    const company = db.companies.find(c => c.id === internship.companyId);
    if (company) {
      db.notifications.unshift({
        id: `notif-${Date.now()}-c`,
        userId: company.userId,
        type: 'APPLICATION',
        title: 'New Applicant Received',
        message: `${student.name} (${student.department}) applied for ${internship.role}.`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'applicants'
      });
    }

    // Notify student
    db.notifications.unshift({
      id: `notif-${Date.now()}-s`,
      userId: student.userId,
      type: 'APPLICATION',
      title: 'Application Submitted',
      message: `Your application for ${internship.role} at ${internship.company.companyName} was successfully recorded.`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
    return app;
  },

  async withdrawApplication(applicationId: string, studentId: string): Promise<void> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId && a.studentId === studentId);
    if (!app) throw new Error('Application not found');
    if (['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(app.status)) {
      throw new Error(`Cannot withdraw an application in ${app.status} status.`);
    }
    app.status = 'WITHDRAWN';
    saveState(db);
  },

  async getMyApplications(studentId: string): Promise<InternshipApplication[]> {
    await sleep();
    const db = loadState();
    return db.applications.filter(a => a.studentId === studentId);
  },

  // Offers
  async getStudentOffers(studentId: string) {
    await sleep();
    const db = loadState();
    return db.applications
      .filter(a => a.studentId === studentId && a.offer)
      .map(a => a.offer!);
  },

  async respondToOffer(offerId: string, status: 'ACCEPTED' | 'DECLINED'): Promise<void> {
    await sleep();
    const db = loadState();
    for (const app of db.applications) {
      if (app.offer && app.offer.id === offerId) {
        app.offer.status = status;
        if (status === 'DECLINED') {
          app.status = 'REJECTED';
        }
        // Notification to student
        db.notifications.unshift({
          id: `notif-${Date.now()}`,
          userId: app.student.userId,
          type: 'OFFER',
          title: `Offer ${status}`,
          message: `You have successfully ${status.toLowerCase()} the internship offer from ${app.internship.company.companyName}.`,
          read: false,
          createdAt: new Date().toISOString(),
          linkTab: 'offers'
        });
        break;
      }
    }
    saveState(db);
  },

  // ----------------------------------------------------
  // COMPANY PORTAL (Mapped to /api/companies/*)
  // ----------------------------------------------------
  async getCompanyProfile(companyId: string): Promise<Company> {
    await sleep();
    const db = loadState();
    const c = db.companies.find(comp => comp.id === companyId);
    if (!c) throw new Error('Company not found');
    return c;
  },

  async getCompanyInternships(companyId: string): Promise<Internship[]> {
    await sleep();
    const db = loadState();
    return db.internships.filter(i => i.companyId === companyId);
  },

  async createInternship(
    companyId: string,
    data: Omit<Internship, 'id' | 'companyId' | 'company' | 'status' | 'createdAt'>
  ): Promise<Internship> {
    await sleep();
    const db = loadState();
    const company = db.companies.find(c => c.id === companyId);
    if (!company) throw new Error('Company not found');

    // Rule: newly created internships need faculty approval before going live
    const newInternship: Internship = {
      id: `internship-${Date.now()}`,
      companyId,
      company,
      status: 'PENDING_APPROVAL',
      createdAt: new Date().toISOString().split('T')[0],
      ...data
    };

    db.internships.push(newInternship);

    // Notify faculty of pending approval
    for (const f of db.faculty) {
      db.notifications.unshift({
        id: `notif-${Date.now()}-f-${f.id}`,
        userId: f.userId,
        type: 'SYSTEM',
        title: 'New Internship Awaiting Approval',
        message: `${company.companyName} submitted "${newInternship.role}" for curriculum approval.`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'approvals'
      });
    }

    saveState(db);
    return newInternship;
  },

  // DYNAMIC PREFERENCE ENGINE:
  // When a company edits criteria, every student is re-evaluated immediately,
  // and students who just became eligible get a notification!
  async updateInternshipCriteria(
    internshipId: string,
    companyId: string,
    updates: Partial<Internship>
  ): Promise<Internship> {
    await sleep();
    const db = loadState();
    const internship = db.internships.find(i => i.id === internshipId && i.companyId === companyId);
    if (!internship) throw new Error('Internship not found or unauthorized');

    // Track previous eligible students
    const previouslyEligibleIds = new Set(
      db.students
        .filter(s => evaluateEligibility(s, internship.criteria).eligible)
        .map(s => s.id)
    );

    // Apply updates
    Object.assign(internship, updates);

    // Evaluate new eligible students
    const newlyEligibleStudents = db.students.filter(s => {
      const nowEligible = evaluateEligibility(s, internship.criteria).eligible;
      return nowEligible && !previouslyEligibleIds.has(s.id);
    });

    // Notify students who just became eligible
    for (const student of newlyEligibleStudents) {
      db.notifications.unshift({
        id: `notif-${Date.now()}-${student.id}`,
        userId: student.userId,
        type: 'CRITERIA_MATCH',
        title: 'Now Eligible for Internship!',
        message: `${internship.company.companyName} updated requirements for "${internship.role}". You now meet all eligibility criteria!`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'browse'
      });
    }

    // Refresh embedded internship data in applications
    for (const app of db.applications.filter(a => a.internshipId === internshipId)) {
      app.internship = internship;
    }

    saveState(db);
    return internship;
  },

  async closeInternship(internshipId: string, companyId: string): Promise<Internship> {
    await sleep();
    const db = loadState();
    const internship = db.internships.find(i => i.id === internshipId && i.companyId === companyId);
    if (!internship) throw new Error('Internship not found');
    internship.status = 'CLOSED';
    saveState(db);
    return internship;
  },

  async getRankedApplicants(internshipId: string): Promise<RankedCandidate[]> {
    await sleep();
    const db = loadState();
    const apps = db.applications.filter(
      a => a.internshipId === internshipId && a.status !== 'WITHDRAWN'
    );

    const ranked: RankedCandidate[] = apps.map(app => {
      const atr = app.assessment?.atrScore ?? null;
      const composite = calculateCandidateRankingScore(app.resumeMatchScore, atr);
      return {
        application: app,
        resumeMatchScore: app.resumeMatchScore,
        atrScore: atr,
        compositeScore: composite
      };
    });

    ranked.sort((a, b) => b.compositeScore - a.compositeScore);
    return ranked;
  },

  // Application Pipeline Actions (Order Enforced)
  async companyShortlistApplication(applicationId: string): Promise<InternshipApplication> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    // Rule: Faculty must shortlist before Company can shortlist
    if (app.status !== 'FACULTY_SHORTLISTED') {
      throw new Error(`Faculty must shortlist candidate first (Current status: ${app.status}).`);
    }

    app.status = 'COMPANY_SHORTLISTED';

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'SHORTLIST',
      title: 'Shortlisted by Company!',
      message: `${app.internship.company.companyName} shortlisted you for the next interview rounds.`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
    return app;
  },

  async scheduleInterview(
    applicationId: string,
    roundType: InterviewStage,
    scheduledDate: string,
    mode: 'ONLINE' | 'OFFLINE'
  ) {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    // Check pipeline stage order
    const configuredStages = app.internship.interviewStages || [];
    const passedStages = (app.interviews || []).filter(i => i.result === 'PASS').map(i => i.type);
    const pendingInterviews = (app.interviews || []).filter(i => i.result === 'PENDING');

    if (pendingInterviews.length > 0) {
      throw new Error('A previous interview is still pending. Record its result first.');
    }

    const nextExpectedIndex = passedStages.length;
    if (nextExpectedIndex < configuredStages.length) {
      const expectedStage = configuredStages[nextExpectedIndex];
      if (roundType !== expectedStage) {
        throw new Error(`Must schedule stages in order. Next expected stage is: ${expectedStage.replace('_', ' ')}.`);
      }
    }

    const newInterview = {
      id: `int-${Date.now()}`,
      applicationId,
      round: (app.interviews || []).length + 1,
      type: roundType,
      scheduledDate,
      mode,
      result: 'PENDING' as const
    };

    app.interviews = [...(app.interviews || []), newInterview];
    app.status = 'INTERVIEW_SCHEDULED';

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'INTERVIEW',
      title: `Interview Round ${newInterview.round} Scheduled`,
      message: `${newInterview.type.replace('_', ' ')} interview scheduled for ${new Date(scheduledDate).toLocaleDateString()} at ${new Date(scheduledDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
    return newInterview;
  },

  async recordInterviewResult(
    interviewId: string,
    result: 'PASS' | 'FAIL',
    remarks?: string
  ): Promise<void> {
    await sleep();
    const db = loadState();
    for (const app of db.applications) {
      const intv = (app.interviews || []).find(i => i.id === interviewId);
      if (intv) {
        intv.result = result;
        intv.remarks = remarks || '';

        if (result === 'FAIL') {
          // Rule: A FAIL rejects the candidate
          app.status = 'REJECTED';
          app.rejectionReason = remarks || 'Did not meet technical bar for this round';
          db.notifications.unshift({
            id: `notif-${Date.now()}`,
            userId: app.student.userId,
            type: 'INTERVIEW_RESULT',
            title: 'Interview Update',
            message: `Result for Round ${intv.round} (${intv.type.replace('_', ' ')}): ${result}.`,
            read: false,
            createdAt: new Date().toISOString(),
            linkTab: 'applications'
          });
        } else {
          db.notifications.unshift({
            id: `notif-${Date.now()}`,
            userId: app.student.userId,
            type: 'INTERVIEW_RESULT',
            title: 'Interview Passed!',
            message: `Congratulations! You cleared Round ${intv.round} (${intv.type.replace('_', ' ')}).`,
            read: false,
            createdAt: new Date().toISOString(),
            linkTab: 'applications'
          });
        }
        break;
      }
    }
    saveState(db);
  },

  async selectCandidate(applicationId: string): Promise<InternshipApplication> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    // Rule: Selected only when all configured stages have been passed
    const configuredStages = app.internship.interviewStages || [];
    const passedStages = (app.interviews || []).filter(i => i.result === 'PASS').map(i => i.type);

    for (const stage of configuredStages) {
      if (!passedStages.includes(stage)) {
        throw new Error(`Cannot select: Stage "${stage.replace('_', ' ')}" has not been passed.`);
      }
    }

    app.status = 'SELECTED';

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'SELECTION',
      title: 'Selected for Internship!',
      message: `Congratulations! You have been selected for ${app.internship.role} at ${app.internship.company.companyName}!`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
    return app;
  },

  async extendOffer(
    applicationId: string,
    stipend: number,
    validUntil: string,
    letterText?: string
  ) {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');
    if (app.status !== 'SELECTED') {
      throw new Error('Candidate must be in SELECTED status before extending an offer.');
    }

    const offer = {
      id: `offer-${Date.now()}`,
      applicationId,
      studentId: app.studentId,
      companyId: app.internship.companyId,
      status: 'EXTENDED' as const,
      offerDate: new Date().toISOString().split('T')[0],
      stipend,
      validUntil,
      letterText: letterText || `Congratulations! We are delighted to offer you the ${app.internship.role} role at ${app.internship.company.companyName}.`
    };

    app.offer = offer;

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'OFFER',
      title: 'Official Internship Offer Extended!',
      message: `${app.internship.company.companyName} extended an official offer with stipend ₹${stipend.toLocaleString()}/month. Respond before ${validUntil}.`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'offers'
    });

    saveState(db);
    return offer;
  },

  async rejectCandidate(applicationId: string, reason?: string): Promise<void> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');
    if (['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(app.status)) {
      throw new Error(`Application is already closed with status ${app.status}.`);
    }

    app.status = 'REJECTED';
    app.rejectionReason = reason || 'Application not selected by review team';

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'SYSTEM',
      title: 'Application Status Update',
      message: `Your application for ${app.internship.role} at ${app.internship.company.companyName} was not moved forward${reason ? `: ${reason}` : '.'}`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
  },

  // ----------------------------------------------------
  // FACULTY PORTAL (Mapped to /api/faculty/*)
  // ----------------------------------------------------
  async getAllStudents(): Promise<Student[]> {
    await sleep();
    const db = loadState();
    return db.students;
  },

  async verifyStudent(
    studentId: string,
    status: 'VERIFIED' | 'REJECTED',
    facultyName: string,
    remarks?: string
  ): Promise<Student> {
    await sleep();
    const db = loadState();
    const s = db.students.find(stu => stu.id === studentId);
    if (!s) throw new Error('Student not found');

    s.verified = status === 'VERIFIED';
    s.verifiedBy = facultyName;
    s.verifiedAt = new Date().toISOString().split('T')[0];

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: s.userId,
      type: 'VERIFICATION',
      title: `Profile ${status === 'VERIFIED' ? 'Verified' : 'Verification Denied'}`,
      message: status === 'VERIFIED'
        ? `Dr. ${facultyName} has verified your academic profile. You are now eligible to apply for matching campus roles!`
        : `Verification pending revision: ${remarks || 'Please check uploaded documents.'}`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'profile'
    });

    saveState(db);
    return s;
  },

  async verifyStudentDocument(
    documentId: string,
    status: 'VERIFIED' | 'REJECTED',
    remarks?: string
  ): Promise<StudentDocument> {
    await sleep();
    const db = loadState();
    const doc = db.documents.find(d => d.id === documentId);
    if (!doc) throw new Error('Document not found');
    doc.verificationStatus = status;
    if (remarks) doc.remarks = remarks;
    saveState(db);
    return doc;
  },

  async getPendingInternships(): Promise<Internship[]> {
    await sleep();
    const db = loadState();
    return db.internships.filter(i => i.status === 'PENDING_APPROVAL');
  },

  async approveInternship(internshipId: string): Promise<Internship> {
    await sleep();
    const db = loadState();
    const internship = db.internships.find(i => i.id === internshipId);
    if (!internship) throw new Error('Internship not found');
    internship.status = 'OPEN';

    // Notify company
    const company = db.companies.find(c => c.id === internship.companyId);
    if (company) {
      db.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: company.userId,
        type: 'SYSTEM',
        title: 'Internship Posting Approved!',
        message: `Your posting "${internship.role}" was approved by Faculty Placement Cell and is now live.`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'mine'
      });
    }

    // Notify all currently eligible students
    const eligibleStudents = db.students.filter(
      s => evaluateEligibility(s, internship.criteria).eligible
    );
    for (const student of eligibleStudents) {
      db.notifications.unshift({
        id: `notif-${Date.now()}-${student.id}`,
        userId: student.userId,
        type: 'CRITERIA_MATCH',
        title: 'New Campus Opportunity!',
        message: `New approved role: "${internship.role}" at ${internship.company.companyName}. You satisfy all criteria!`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'browse'
      });
    }

    saveState(db);
    return internship;
  },

  async declineInternship(internshipId: string, reason?: string): Promise<Internship> {
    await sleep();
    const db = loadState();
    const internship = db.internships.find(i => i.id === internshipId);
    if (!internship) throw new Error('Internship not found');
    internship.status = 'REJECTED';

    const company = db.companies.find(c => c.id === internship.companyId);
    if (company) {
      db.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: company.userId,
        type: 'SYSTEM',
        title: 'Internship Posting Declined',
        message: `Posting for "${internship.role}" was declined by Faculty Cell: ${reason || 'Does not match academic internship guidelines.'}`,
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'mine'
      });
    }

    saveState(db);
    return internship;
  },

  async getAllApplications(): Promise<InternshipApplication[]> {
    await sleep();
    const db = loadState();
    return db.applications;
  },

  async recordAtrScore(applicationId: string, atrScore: number): Promise<void> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    if (!app.assessment) {
      app.assessment = {
        id: `asm-${Date.now()}`,
        applicationId,
        atrScore,
        aptitudeScore: null,
        codingScore: null,
        updatedAt: new Date().toISOString()
      };
    } else {
      app.assessment.atrScore = atrScore;
      app.assessment.updatedAt = new Date().toISOString();
    }
    saveState(db);
  },

  async facultyShortlistApplication(applicationId: string): Promise<InternshipApplication> {
    await sleep();
    const db = loadState();
    const app = db.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    // Rule: Enforce minimum ATR score if configured on internship
    const minAtr = app.internship.criteria?.minAtrScore;
    if (minAtr !== undefined && minAtr !== null && minAtr > 0) {
      const studentAtr = app.assessment?.atrScore;
      if (studentAtr === undefined || studentAtr === null || studentAtr < minAtr) {
        throw new Error(`Candidate ATR score (${studentAtr ?? 'Not recorded'}) is below the required minimum of ${minAtr}.`);
      }
    }

    if (app.status !== 'APPLIED' && app.status !== 'RESUME_SCORED') {
      throw new Error(`Only newly applied candidates can be faculty-shortlisted (Current status: ${app.status}).`);
    }

    app.status = 'FACULTY_SHORTLISTED';

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: app.student.userId,
      type: 'SHORTLIST',
      title: 'Faculty Shortlisted!',
      message: `Faculty Placement Cell approved your application for ${app.internship.role} to proceed to the company.`,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab: 'applications'
    });

    saveState(db);
    return app;
  },

  // ----------------------------------------------------
  // NOTIFICATIONS (Mapped to /api/notifications/*)
  // ----------------------------------------------------
  async getMyNotifications(userId: string): Promise<NotificationItem[]> {
    await sleep();
    const db = loadState();
    return db.notifications.filter(n => n.userId === userId);
  },

  async markNotificationRead(notifId: string): Promise<void> {
    await sleep();
    const db = loadState();
    const n = db.notifications.find(item => item.id === notifId);
    if (n) n.read = true;
    saveState(db);
  },

  async markAllNotificationsRead(userId: string): Promise<void> {
    await sleep();
    const db = loadState();
    db.notifications.filter(n => n.userId === userId).forEach(n => n.read = true);
    saveState(db);
  },

  // ----------------------------------------------------
  // ANALYTICS & REPORTS (Mapped to /api/reports/summary)
  // ----------------------------------------------------
  async getAnalyticsSummary() {
    await sleep();
    const db = loadState();
    const totalStudents = db.students.length;
    const verifiedStudents = db.students.filter(s => s.verified).length;
    const openInternships = db.internships.filter(i => i.status === 'OPEN');
    const eligibleStudents = db.students.filter(s =>
      openInternships.some(i => evaluateEligibility(s, i.criteria).eligible)
    ).length;

    const totalApplications = db.applications.length;
    const shortlistedCount = db.applications.filter(a =>
      ['FACULTY_SHORTLISTED', 'COMPANY_SHORTLISTED', 'INTERVIEW_SCHEDULED', 'SELECTED'].includes(a.status)
    ).length;
    const selectedCount = db.applications.filter(a => a.status === 'SELECTED').length;
    const acceptedCount = db.applications.filter(a => a.offer?.status === 'ACCEPTED').length;

    // Funnel chart data
    const funnel = [
      { stage: 'Total Eligible', count: eligibleStudents, fill: '#2D6CDF' },
      { stage: 'Applied', count: totalApplications, fill: '#5439D6' },
      { stage: 'Shortlisted', count: shortlistedCount, fill: '#17A7C9' },
      { stage: 'Interviewed', count: db.applications.filter(a => (a.interviews || []).length > 0).length, fill: '#F59E0B' },
      { stage: 'Selected', count: selectedCount, fill: '#10B981' },
      { stage: 'Accepted', count: acceptedCount, fill: '#059669' }
    ];

    // Department-wise stats
    const deptMap: Record<string, { total: number; verified: number; applied: number; selected: number }> = {};
    for (const s of db.students) {
      const d = s.department || 'Other';
      if (!deptMap[d]) deptMap[d] = { total: 0, verified: 0, applied: 0, selected: 0 };
      deptMap[d].total++;
      if (s.verified) deptMap[d].verified++;
    }
    for (const a of db.applications) {
      const d = a.student.department || 'Other';
      if (deptMap[d]) {
        deptMap[d].applied++;
        if (a.status === 'SELECTED') deptMap[d].selected++;
      }
    }

    const departmentWise = Object.entries(deptMap).map(([department, data]) => ({
      department,
      ...data
    }));

    // Company-wise stats
    const companyMap: Record<string, { companyName: string; openings: number; applications: number; selected: number }> = {};
    for (const c of db.companies) {
      companyMap[c.id] = { companyName: c.companyName, openings: 0, applications: 0, selected: 0 };
    }
    for (const i of db.internships) {
      if (companyMap[i.companyId]) companyMap[i.companyId].openings += i.vacancies;
    }
    for (const a of db.applications) {
      if (companyMap[a.internship.companyId]) {
        companyMap[a.internship.companyId].applications++;
        if (a.status === 'SELECTED') companyMap[a.internship.companyId].selected++;
      }
    }
    const companyWise = Object.values(companyMap);

    // Applications over time
    const applicationsTimeline = [
      { date: 'Oct 01', count: 1 },
      { date: 'Oct 05', count: 3 },
      { date: 'Oct 08', count: 7 },
      { date: 'Oct 12', count: 12 },
      { date: 'Oct 15', count: 18 },
      { date: 'Oct 18', count: totalApplications }
    ];

    return {
      kpi: {
        totalStudents,
        verifiedStudents,
        eligibleStudents,
        totalInternships: db.internships.length,
        openInternships: openInternships.length,
        totalApplications,
        shortlistedCount,
        selectedCount,
        acceptedCount
      },
      funnel,
      departmentWise,
      companyWise,
      applicationsTimeline
    };
  }
};

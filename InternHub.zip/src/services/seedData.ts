import {
  User,
  Student,
  Company,
  Faculty,
  Internship,
  InternshipApplication,
  StudentDocument,
  AcademicRecord,
  StudentResume,
  NotificationItem,
  AuditLog
} from '@/types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user-stu-1',
    email: 'student@demo.com',
    role: 'STUDENT',
    name: 'Demo Student',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    enabled: true,
    profileId: 'student-1'
  },
  {
    id: 'user-stu-2',
    email: 'student2@demo.com',
    role: 'STUDENT',
    name: 'Rahul Sharma',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=120&auto=format&fit=crop&q=80',
    enabled: true,
    profileId: 'student-2'
  },
  {
    id: 'user-fac-1',
    email: 'faculty@demo.com',
    role: 'FACULTY',
    name: 'Dr. Anand Mehta',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    enabled: true,
    profileId: 'faculty-1'
  },
  {
    id: 'user-com-1',
    email: 'company@demo.com',
    role: 'COMPANY',
    name: 'NexaTech HR Team',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    enabled: true,
    profileId: 'company-1'
  },
  {
    id: 'user-adm-1',
    email: 'admin@demo.com',
    role: 'ADMIN',
    name: 'Dean / Administrator',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    enabled: true,
    profileId: 'admin-1'
  }
];

export const INITIAL_FACULTY: Faculty[] = [
  {
    id: 'faculty-1',
    userId: 'user-fac-1',
    name: 'Dr. Anand Mehta',
    department: 'CSE',
    designation: 'Head of Training & Placement',
    email: 'faculty@demo.com'
  },
  {
    id: 'faculty-2',
    userId: 'user-fac-2',
    name: 'Prof. Sunita Rao',
    department: 'IT',
    designation: 'Associate Professor & Verification Officer',
    email: 'srao@college.edu'
  }
];

export const INITIAL_COMPANIES: Company[] = [
  {
    id: 'company-1',
    userId: 'user-com-1',
    companyName: 'NexaTech Solutions',
    industry: 'Enterprise Software & Cloud',
    location: 'Pune / Hybrid',
    website: 'https://nexatech.example.com',
    contact: 'careers@nexatech.example',
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'company-2',
    userId: 'user-com-2',
    companyName: 'CloudScale Systems',
    industry: 'DevOps & Site Reliability',
    location: 'Bengaluru / Remote',
    website: 'https://cloudscale.example.com',
    contact: 'campus@cloudscale.example',
    logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'company-3',
    userId: 'user-com-3',
    companyName: 'QuantumAI Labs',
    industry: 'Artificial Intelligence & Robotics',
    location: 'Hyderabad / Onsite',
    website: 'https://quantumai.example.com',
    contact: 'talent@quantumai.example',
    logo: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'company-4',
    userId: 'user-com-4',
    companyName: 'CyberShield Defense',
    industry: 'Information Security',
    location: 'Mumbai / Hybrid',
    website: 'https://cybershield.example.com',
    contact: 'interns@cybershield.example',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'company-5',
    userId: 'user-com-5',
    companyName: 'PulseHealth Technologies',
    industry: 'HealthTech & Telemedicine',
    location: 'Chennai / Hybrid',
    website: 'https://pulsehealth.example.com',
    contact: 'jobs@pulsehealth.example',
    logo: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=120&auto=format&fit=crop&q=80'
  },
  {
    id: 'company-6',
    userId: 'user-com-6',
    companyName: 'FinEdge Capital',
    industry: 'Quantitative FinTech',
    location: 'Gurugram / Onsite',
    website: 'https://finedge.example.com',
    contact: 'hr@finedge.example',
    logo: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=120&auto=format&fit=crop&q=80'
  }
];

// Helper to seed students
const rawStudentsData = [
  // Worked Example Student (Verified)
  {
    id: 'student-1',
    userId: 'user-stu-1',
    name: 'Demo Student',
    prn: 'PRN2026CSE045',
    email: 'student@demo.com',
    department: 'CSE',
    semester: 7,
    cgpa: 8.2,
    backlogs: 0,
    phone: '+91 98765 43210',
    internshipPreferences: 'Backend Development, Distributed Systems, Hybrid',
    certifications: ['Oracle Java SE', 'AWS Certified Cloud Practitioner'],
    projects: 'Internship management portal (Spring Boot + MySQL), Realtime chat application in Node.js',
    verified: true,
    verifiedBy: 'Dr. Anand Mehta',
    verifiedAt: '2026-09-15',
    skills: [
      { name: 'Java', proficiency: 'ADVANCED' as const },
      { name: 'SQL', proficiency: 'ADVANCED' as const },
      { name: 'Python', proficiency: 'INTERMEDIATE' as const },
      { name: 'Git', proficiency: 'ADVANCED' as const },
      { name: 'REST API', proficiency: 'ADVANCED' as const },
      { name: 'Spring Boot', proficiency: 'INTERMEDIATE' as const }
    ]
  },
  // Unverified Student 2
  {
    id: 'student-2',
    userId: 'user-stu-2',
    name: 'Rahul Sharma',
    prn: 'PRN2026CSE046',
    email: 'student2@demo.com',
    department: 'CSE',
    semester: 7,
    cgpa: 7.9,
    backlogs: 1,
    phone: '+91 98765 43211',
    internshipPreferences: 'Fullstack Web Development',
    certifications: [],
    projects: 'Personal Blog CMS in PHP/MySQL',
    verified: false,
    skills: [
      { name: 'Java', proficiency: 'BEGINNER' as const },
      { name: 'HTML', proficiency: 'INTERMEDIATE' as const },
      { name: 'CSS', proficiency: 'INTERMEDIATE' as const }
    ]
  },
  // Additional 23 students
  { id: 'student-3', name: 'Aarav Patel', prn: 'PRN2026IT012', email: 'aarav.p@college.edu', department: 'IT', semester: 7, cgpa: 9.3, backlogs: 0, phone: '+91 98111 22334', internshipPreferences: 'Machine Learning, AI Research', certifications: ['TensorFlow Developer Certificate'], projects: 'Deep learning for medical scan segmentation', verified: true, skills: [{ name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'Machine Learning', proficiency: 'ADVANCED' as const }, { name: 'PyTorch', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-4', name: 'Priya Iyer', prn: 'PRN2026CSE018', email: 'priya.iyer@college.edu', department: 'CSE', semester: 7, cgpa: 8.8, backlogs: 0, phone: '+91 98222 33445', internshipPreferences: 'Cloud Architecture & DevOps', certifications: ['AWS Certified Solutions Architect'], projects: 'Automated Kubernetes pipeline with Terraform', verified: true, skills: [{ name: 'Docker', proficiency: 'ADVANCED' as const }, { name: 'Kubernetes', proficiency: 'ADVANCED' as const }, { name: 'Linux', proficiency: 'ADVANCED' as const }, { name: 'AWS', proficiency: 'ADVANCED' as const }] },
  { id: 'student-5', name: 'Kavita Deshmukh', prn: 'PRN2026ECE007', email: 'kavita.d@college.edu', department: 'ECE', semester: 6, cgpa: 8.5, backlogs: 0, phone: '+91 98333 44556', internshipPreferences: 'Embedded Systems, IoT', certifications: ['ARM Cortex Microcontrollers'], projects: 'Smart Agriculture Sensor Node with LoRa', verified: true, skills: [{ name: 'C', proficiency: 'ADVANCED' as const }, { name: 'C++', proficiency: 'ADVANCED' as const }, { name: 'Linux', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-6', name: 'Rohan Verma', prn: 'PRN2026IT034', email: 'rohan.v@college.edu', department: 'IT', semester: 7, cgpa: 7.2, backlogs: 0, phone: '+91 98444 55667', internshipPreferences: 'Frontend Engineering', certifications: ['Meta Frontend Developer'], projects: 'E-commerce React Storefront with Redux', verified: true, skills: [{ name: 'React', proficiency: 'ADVANCED' as const }, { name: 'TypeScript', proficiency: 'ADVANCED' as const }, { name: 'Tailwind CSS', proficiency: 'ADVANCED' as const }] },
  { id: 'student-7', name: 'Ananya Nair', prn: 'PRN2026CSE088', email: 'ananya.n@college.edu', department: 'CSE', semester: 7, cgpa: 9.1, backlogs: 0, phone: '+91 98555 66778', internshipPreferences: 'Data Science & FinTech', certifications: ['Financial Risk Management Basics', 'Python for Finance'], projects: 'High-frequency algorithmic backtesting engine', verified: true, skills: [{ name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'Pandas', proficiency: 'ADVANCED' as const }] },
  { id: 'student-8', name: 'Aditya Kulkarni', prn: 'PRN2026MECH015', email: 'aditya.k@college.edu', department: 'MECH', semester: 7, cgpa: 7.4, backlogs: 1, phone: '+91 98666 77889', internshipPreferences: 'CAD/CAM, Robotics Simulations', certifications: ['SolidWorks CSWA'], projects: 'Kinematic analysis of 6-DOF robotic arm', verified: true, skills: [{ name: 'Python', proficiency: 'INTERMEDIATE' as const }, { name: 'Algorithms', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-9', name: 'Siddharth Sen', prn: 'PRN2026CSE091', email: 'sid.sen@college.edu', department: 'CSE', semester: 7, cgpa: 8.6, backlogs: 0, phone: '+91 98777 88990', internshipPreferences: 'Information Security, Penetration Testing', certifications: ['CompTIA Security+', 'CEH Practical'], projects: 'Vulnerability assessment scanner in Go and Python', verified: true, skills: [{ name: 'Cybersecurity', proficiency: 'ADVANCED' as const }, { name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'Linux', proficiency: 'ADVANCED' as const }] },
  { id: 'student-10', name: 'Neha Joshi', prn: 'PRN2026IT055', email: 'neha.j@college.edu', department: 'IT', semester: 7, cgpa: 8.0, backlogs: 0, phone: '+91 98888 99001', internshipPreferences: 'Backend Development', certifications: ['Oracle Java SE'], projects: 'Event management booking microservice', verified: true, skills: [{ name: 'Java', proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'Spring Boot', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-11', name: 'Vikram Choudhury', prn: 'PRN2026ECE042', email: 'vikram.c@college.edu', department: 'ECE', semester: 6, cgpa: 6.8, backlogs: 2, phone: '+91 98999 00112', internshipPreferences: 'Hardware validation', certifications: [], projects: 'FPGA implementation of AES cipher', verified: false, skills: [{ name: 'C', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-12', name: 'Tanvi Shah', prn: 'PRN2026CSE064', email: 'tanvi.s@college.edu', department: 'CSE', semester: 7, cgpa: 9.5, backlogs: 0, phone: '+91 98123 45678', internshipPreferences: 'Core Software Engineering, Large Scale Systems', certifications: ['Google Associate Cloud Engineer'], projects: 'Distributed key-value store with Raft consensus', verified: true, skills: [{ name: 'Java', proficiency: 'ADVANCED' as const }, { name: 'Distributed Systems' as any, proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'Algorithms', proficiency: 'ADVANCED' as const }] },
  { id: 'student-13', name: 'Manish Pandey', prn: 'PRN2026MECH033', email: 'manish.p@college.edu', department: 'MECH', semester: 7, cgpa: 8.1, backlogs: 0, phone: '+91 98234 56789', internshipPreferences: 'Robotics Software, Autonomous Vehicles', certifications: ['ROS2 Developer'], projects: 'SLAM navigation for warehouse mobile robot', verified: true, skills: [{ name: 'C++', proficiency: 'ADVANCED' as const }, { name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'Linux', proficiency: 'ADVANCED' as const }] },
  { id: 'student-14', name: 'Sneha Reddy', prn: 'PRN2026IT077', email: 'sneha.r@college.edu', department: 'IT', semester: 7, cgpa: 8.4, backlogs: 0, phone: '+91 98345 67890', internshipPreferences: 'Full Stack Web Development', certifications: ['AWS Certified Developer'], projects: 'Peer-to-peer tutoring marketplace in Next.js', verified: true, skills: [{ name: 'React', proficiency: 'ADVANCED' as const }, { name: 'Node.js', proficiency: 'ADVANCED' as const }, { name: 'PostgreSQL', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-15', name: 'Karan Mehra', prn: 'PRN2026CSE021', email: 'karan.m@college.edu', department: 'CSE', semester: 7, cgpa: 7.6, backlogs: 0, phone: '+91 98456 78901', internshipPreferences: 'API Engineering & Database Systems', certifications: ['Oracle Database Administrator Associate'], projects: 'Database replication and failover test harness', verified: true, skills: [{ name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'Java', proficiency: 'INTERMEDIATE' as const }, { name: 'MySQL', proficiency: 'ADVANCED' as const }] },
  { id: 'student-16', name: 'Riya Gupta', prn: 'PRN2026ECE019', email: 'riya.g@college.edu', department: 'ECE', semester: 7, cgpa: 8.9, backlogs: 0, phone: '+91 98567 89012', internshipPreferences: 'Signal Processing & Edge AI', certifications: ['Edge Impulse Certified ML on Microcontrollers'], projects: 'Keyword spotting model on Cortex-M4', verified: true, skills: [{ name: 'C++', proficiency: 'ADVANCED' as const }, { name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'TensorFlow', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-17', name: 'Deepak Rao', prn: 'PRN2026CSE102', email: 'deepak.r@college.edu', department: 'CSE', semester: 7, cgpa: 6.9, backlogs: 0, phone: '+91 98678 90123', internshipPreferences: 'Web Backend', certifications: [], projects: 'Inventory system using Express & Mongo', verified: false, skills: [{ name: 'Node.js', proficiency: 'INTERMEDIATE' as const }, { name: 'JavaScript', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-18', name: 'Meera Menon', prn: 'PRN2026IT090', email: 'meera.m@college.edu', department: 'IT', semester: 7, cgpa: 9.4, backlogs: 0, phone: '+91 98789 01234', internshipPreferences: 'Machine Learning & Natural Language Processing', certifications: ['Deep Learning Specialization - Coursera'], projects: 'Low-resource language sentiment analysis tool', verified: true, skills: [{ name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'Machine Learning', proficiency: 'ADVANCED' as const }, { name: 'Deep Learning', proficiency: 'ADVANCED' as const }] },
  { id: 'student-19', name: 'Varun Bhatia', prn: 'PRN2026MECH051', email: 'varun.b@college.edu', department: 'MECH', semester: 6, cgpa: 7.1, backlogs: 0, phone: '+91 98890 12345', internshipPreferences: 'Automotive Embedded Systems', certifications: ['MATLAB Associate'], projects: 'Battery thermal management simulation', verified: true, skills: [{ name: 'C', proficiency: 'INTERMEDIATE' as const }, { name: 'Python', proficiency: 'BEGINNER' as const }] },
  { id: 'student-20', name: 'Aishwarya Saxena', prn: 'PRN2026CSE035', email: 'aishwarya.s@college.edu', department: 'CSE', semester: 7, cgpa: 8.3, backlogs: 0, phone: '+91 98901 23456', internshipPreferences: 'Distributed Systems & Java Backend', certifications: ['Oracle Java SE'], projects: 'Streaming telemetry ingest pipeline using Kafka', verified: true, skills: [{ name: 'Java', proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'Kafka', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-21', name: 'Gaurav Dubey', prn: 'PRN2026IT023', email: 'gaurav.d@college.edu', department: 'IT', semester: 7, cgpa: 7.8, backlogs: 0, phone: '+91 98012 34567', internshipPreferences: 'Cloud Infrastructure & SRE', certifications: ['HashiCorp Certified Terraform Associate'], projects: 'Multi-region disaster recovery sandbox in AWS', verified: true, skills: [{ name: 'AWS', proficiency: 'ADVANCED' as const }, { name: 'Linux', proficiency: 'ADVANCED' as const }, { name: 'Docker', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-22', name: 'Shreya Das', prn: 'PRN2026ECE058', email: 'shreya.d@college.edu', department: 'ECE', semester: 7, cgpa: 8.7, backlogs: 0, phone: '+91 98124 56789', internshipPreferences: 'Digital Design & ASIC verification', certifications: ['Verilog HDL Specialist'], projects: 'RISC-V 5-stage pipelined core verification suite', verified: true, skills: [{ name: 'C++', proficiency: 'ADVANCED' as const }, { name: 'Python', proficiency: 'INTERMEDIATE' as const }] },
  { id: 'student-23', name: 'Kushagra Soni', prn: 'PRN2026CSE115', email: 'kushagra.s@college.edu', department: 'CSE', semester: 7, cgpa: 7.3, backlogs: 1, phone: '+91 98235 67890', internshipPreferences: 'Frontend UI/UX Engineering', certifications: [], projects: 'Design system library with Storybook and Tailwind', verified: false, skills: [{ name: 'React', proficiency: 'ADVANCED' as const }, { name: 'JavaScript', proficiency: 'ADVANCED' as const }] },
  { id: 'student-24', name: 'Ishita Bansal', prn: 'PRN2026IT081', email: 'ishita.b@college.edu', department: 'IT', semester: 7, cgpa: 8.9, backlogs: 0, phone: '+91 98346 78901', internshipPreferences: 'Applied Machine Learning & GenAI', certifications: ['AWS Certified Machine Learning Specialty'], projects: 'RAG retrieval system for academic syllabi', verified: true, skills: [{ name: 'Python', proficiency: 'ADVANCED' as const }, { name: 'Machine Learning', proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }] },
  { id: 'student-25', name: 'Yashwardhan Singhania', prn: 'PRN2026CSE099', email: 'yash.s@college.edu', department: 'CSE', semester: 7, cgpa: 8.1, backlogs: 0, phone: '+91 98457 89012', internshipPreferences: 'FinTech Backend Systems', certifications: ['Oracle Java SE'], projects: 'Double-entry ledger service with PostgreSQL', verified: true, skills: [{ name: 'Java', proficiency: 'ADVANCED' as const }, { name: 'SQL', proficiency: 'ADVANCED' as const }, { name: 'PostgreSQL', proficiency: 'ADVANCED' as const }] }
];

export const INITIAL_STUDENTS: Student[] = rawStudentsData.map(s => ({
  ...s,
  userId: s.userId || `user-${s.id}`,
  verified: s.verified ?? true,
  bookmarkedInternshipIds: []
}));

export const INITIAL_ACADEMIC_RECORDS: AcademicRecord[] = [
  { id: 'rec-1', studentId: 'student-1', semester: 1, subject: 'Programming with C & Data Structures', marks: 88, sgpa: 8.5 },
  { id: 'rec-2', studentId: 'student-1', semester: 2, subject: 'Discrete Mathematics & Logic', marks: 82, sgpa: 8.1 },
  { id: 'rec-3', studentId: 'student-1', semester: 3, subject: 'Object Oriented Programming with Java', marks: 91, sgpa: 8.7 },
  { id: 'rec-4', studentId: 'student-1', semester: 4, subject: 'Database Management Systems (DBMS)', marks: 86, sgpa: 8.3 },
  { id: 'rec-5', studentId: 'student-1', semester: 5, subject: 'Operating Systems & System Calls', marks: 79, sgpa: 7.9 },
  { id: 'rec-6', studentId: 'student-1', semester: 6, subject: 'Advanced Computer Networks & REST APIs', marks: 84, sgpa: 8.2 },
  { id: 'rec-7', studentId: 'student-2', semester: 5, subject: 'Operating Systems', marks: 68, sgpa: 7.2 },
  { id: 'rec-8', studentId: 'student-2', semester: 6, subject: 'Web Technologies', marks: 76, sgpa: 7.8 }
];

export const INITIAL_DOCUMENTS: StudentDocument[] = [
  {
    id: 'doc-1',
    studentId: 'student-1',
    documentType: 'MARKSHEET',
    fileName: 'Semester_6_Official_Marksheet.pdf',
    fileSize: '1.2 MB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    verificationStatus: 'VERIFIED',
    uploadedAt: '2026-09-10',
    remarks: 'Verified against university controller records by Dr. Mehta.'
  },
  {
    id: 'doc-2',
    studentId: 'student-1',
    documentType: 'CERTIFICATE',
    fileName: 'Oracle_Java_SE_Certificate.pdf',
    fileSize: '840 KB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    verificationStatus: 'VERIFIED',
    uploadedAt: '2026-09-11',
    remarks: 'Valid digital certificate badge verified.'
  },
  {
    id: 'doc-3',
    studentId: 'student-2',
    documentType: 'MARKSHEET',
    fileName: 'Semester_6_Provisional_Marksheet.pdf',
    fileSize: '950 KB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    verificationStatus: 'PENDING',
    uploadedAt: '2026-10-15',
    remarks: 'Awaiting faculty seal verification.'
  },
  {
    id: 'doc-4',
    studentId: 'student-11',
    documentType: 'MARKSHEET',
    fileName: 'Sem_5_Backlog_Notice.pdf',
    fileSize: '512 KB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    verificationStatus: 'PENDING',
    uploadedAt: '2026-10-14'
  },
  {
    id: 'doc-5',
    studentId: 'student-17',
    documentType: 'MARKSHEET',
    fileName: 'Marksheet_Sem4_Signed.pdf',
    fileSize: '1.4 MB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    verificationStatus: 'PENDING',
    uploadedAt: '2026-10-16'
  }
];

export const INITIAL_RESUMES: StudentResume[] = [
  {
    id: 'resume-1',
    studentId: 'student-1',
    rawText: `DEMO STUDENT
Pune, India | +91 98765 43210 | student@demo.com | github.com/demostudent

EDUCATION
B.Tech in Computer Science and Engineering (CSE) | CGPA: 8.2 / 10.0 (Semesters 1-6)
Courses: Data Structures & Algorithms, Object-Oriented Programming, Database Management Systems, Operating Systems.

TECHNICAL SKILLS
Languages: Java, SQL, Python, C++
Frameworks & Libraries: Spring Boot, Express, React, Hibernate
Databases & Cloud: MySQL, PostgreSQL, AWS Certified Cloud Practitioner
Developer Tools: Git, GitHub, Docker, Postman, Linux

PROJECTS
1. Campus Internship Management & Eligibility Portal (Spring Boot, Java, MySQL, REST API)
- Designed role-based authentication and rule evaluation engine for student eligibility across criteria.
- Implemented resume parsing and ATS matching heuristics using Java 17 and whole-word tokenization.

2. Distributed Message Bus and Task Worker
- Implemented persistent producer-consumer queue in Python and SQL with exponential retry policies.

CERTIFICATIONS
- Oracle Java SE Professional Certificate
- AWS Certified Cloud Practitioner

WORK EXPERIENCE
Summer Software Engineering Intern at TechVibe Systems (May 2025 - July 2025)
- Automated API regression tests and tuned slow SQL queries, cutting p95 response times by 32%.`,
    resumeScore: 92,
    extractedSkills: ['Java', 'SQL', 'Python', 'C++', 'Spring Boot', 'React', 'MySQL', 'PostgreSQL', 'AWS', 'Git', 'Docker', 'Linux', 'REST API'],
    fileName: 'Demo_Student_Software_Resume.pdf',
    updatedAt: '2026-10-12',
    aiFeedback: [
      'Quantify the impact of the distributed task worker project with metrics like throughput or latency.',
      'Add a dedicated summary line at the top tailored towards Backend or Distributed Systems roles.',
      'Include links to live demo deployments or GitHub pull requests to enhance credibility.'
    ]
  }
];

export const INITIAL_INTERNSHIPS: Internship[] = [
  // Worked Example 1 (Student-1 qualifies)
  {
    id: 'internship-1',
    companyId: 'company-1',
    company: INITIAL_COMPANIES[0],
    role: 'Backend Development Intern',
    description: 'Design and deploy robust REST APIs, microservices, and database schemas using Java and MySQL. Collaborate with senior systems architects on scalable cloud backends.',
    duration: '6 Months',
    stipend: 25000,
    location: 'Pune',
    workMode: 'HYBRID',
    vacancies: 4,
    deadline: '2026-11-30',
    interviewStages: ['APTITUDE_TEST', 'CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.5,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['Java', 'SQL'],
      requiredCertifications: [],
      requiredSemester: 7,
      minResumeScore: 70,
      minAtrScore: null
    },
    createdAt: '2026-10-01'
  },
  // Worked Example 2 (Student-1 does NOT qualify: minCgpa 9.0 & missing Machine Learning)
  {
    id: 'internship-2',
    companyId: 'company-1',
    company: INITIAL_COMPANIES[0],
    role: 'Data Science Intern',
    description: 'Work alongside research scientists to build, benchmark, and deploy predictive models on production datasets using Python, scikit-learn, and PyTorch.',
    duration: '6 Months',
    stipend: 30000,
    location: 'Bengaluru',
    workMode: 'REMOTE',
    vacancies: 2,
    deadline: '2026-12-15',
    interviewStages: ['APTITUDE_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 9.0,
      maxBacklogs: 0,
      eligibleBranches: ['CSE'],
      requiredSkills: ['Python', 'Machine Learning'],
      requiredCertifications: [],
      requiredSemester: 7,
      minResumeScore: 75,
      minAtrScore: 60.0
    },
    createdAt: '2026-10-02'
  },
  // Internship 3 (CloudScale Systems)
  {
    id: 'internship-3',
    companyId: 'company-2',
    company: INITIAL_COMPANIES[1],
    role: 'Cloud & DevOps Engineering Intern',
    description: 'Build CI/CD automation pipelines, manage multi-region Kubernetes clusters, and write Infrastructure as Code using Terraform and Docker.',
    duration: '6 Months',
    stipend: 28000,
    location: 'Bengaluru',
    workMode: 'REMOTE',
    vacancies: 3,
    deadline: '2026-11-25',
    interviewStages: ['CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.8,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT', 'ECE'],
      requiredSkills: ['Docker', 'Kubernetes', 'Linux'],
      requiredCertifications: [],
      requiredSemester: 7,
      minAtrScore: 50.0
    },
    createdAt: '2026-10-03'
  },
  // Internship 4 (QuantumAI Labs)
  {
    id: 'internship-4',
    companyId: 'company-3',
    company: INITIAL_COMPANIES[2],
    role: 'Applied Machine Learning Intern',
    description: 'Train cutting-edge NLP transformer models, develop fine-tuning pipelines, and build latency-optimized inference services.',
    duration: '6 Months',
    stipend: 35000,
    location: 'Hyderabad',
    workMode: 'ONSITE',
    vacancies: 2,
    deadline: '2026-12-05',
    interviewStages: ['APTITUDE_TEST', 'CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 8.5,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['Python', 'Machine Learning'],
      requiredCertifications: [],
      minAtrScore: 70.0
    },
    createdAt: '2026-10-04'
  },
  // Internship 5 (CyberShield Defense)
  {
    id: 'internship-5',
    companyId: 'company-4',
    company: INITIAL_COMPANIES[3],
    role: 'Security Operations & Penetration Testing Intern',
    description: 'Perform active security auditing, automate vulnerability assessments, and evaluate defensive configurations across networks.',
    duration: '6 Months',
    stipend: 22000,
    location: 'Mumbai',
    workMode: 'HYBRID',
    vacancies: 3,
    deadline: '2026-11-18',
    interviewStages: ['TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.5,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['Cybersecurity', 'Linux', 'Python'],
      requiredCertifications: [],
      minAtrScore: 60.0
    },
    createdAt: '2026-10-05'
  },
  // Internship 6 (PulseHealth Tech)
  {
    id: 'internship-6',
    companyId: 'company-5',
    company: INITIAL_COMPANIES[4],
    role: 'Full Stack Web Engineering Intern',
    description: 'Develop patient monitoring dashboards and telemedicine portals using React, TypeScript, Node.js, and PostgreSQL.',
    duration: '6 Months',
    stipend: 24000,
    location: 'Chennai',
    workMode: 'HYBRID',
    vacancies: 4,
    deadline: '2026-11-20',
    interviewStages: ['CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.0,
      maxBacklogs: 1,
      eligibleBranches: [],
      requiredSkills: ['React', 'TypeScript'],
      requiredCertifications: []
    },
    createdAt: '2026-10-06'
  },
  // Internship 7 (FinEdge Capital)
  {
    id: 'internship-7',
    companyId: 'company-6',
    company: INITIAL_COMPANIES[5],
    role: 'Quantitative Software Engineer Intern',
    description: 'Develop low-latency trade processing systems, historical data pipelines, and numerical algorithms in C++ and Python.',
    duration: '6 Months',
    stipend: 45000,
    location: 'Gurugram',
    workMode: 'ONSITE',
    vacancies: 2,
    deadline: '2026-12-01',
    interviewStages: ['APTITUDE_TEST', 'CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 8.8,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT', 'ECE'],
      requiredSkills: ['Python', 'SQL'],
      requiredCertifications: [],
      minAtrScore: 75.0
    },
    createdAt: '2026-10-07'
  },
  // Internship 8 (NexaTech Frontend)
  {
    id: 'internship-8',
    companyId: 'company-1',
    company: INITIAL_COMPANIES[0],
    role: 'Frontend Experience Intern',
    description: 'Build responsive, accessible SaaS user interfaces with modern React, Tailwind CSS, and Framer Motion animations.',
    duration: '6 Months',
    stipend: 22000,
    location: 'Pune',
    workMode: 'HYBRID',
    vacancies: 3,
    deadline: '2026-11-28',
    interviewStages: ['CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.0,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['React', 'Tailwind CSS'],
      requiredCertifications: []
    },
    createdAt: '2026-10-08'
  },
  // Internship 9 (CloudScale Infrastructure)
  {
    id: 'internship-9',
    companyId: 'company-2',
    company: INITIAL_COMPANIES[1],
    role: 'Site Reliability Engineering Intern',
    description: 'Maintain high availability metrics, automate failovers, write Prometheus alerting rules, and manage cluster observability.',
    duration: '6 Months',
    stipend: 26000,
    location: 'Bengaluru',
    workMode: 'REMOTE',
    vacancies: 2,
    deadline: '2026-12-10',
    interviewStages: ['TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.5,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['Linux', 'Docker'],
      requiredCertifications: []
    },
    createdAt: '2026-10-09'
  },
  // Internship 10 (PulseHealth Data)
  {
    id: 'internship-10',
    companyId: 'company-5',
    company: INITIAL_COMPANIES[4],
    role: 'Healthcare Data Analyst Intern',
    description: 'Cleanse clinical trial datasets, produce diagnostic dashboards, and extract clinical biomarkers with SQL and Python.',
    duration: '6 Months',
    stipend: 20000,
    location: 'Chennai',
    workMode: 'REMOTE',
    vacancies: 2,
    deadline: '2026-11-15',
    interviewStages: ['APTITUDE_TEST', 'TECHNICAL', 'HR'],
    status: 'OPEN',
    criteria: {
      minCgpa: 7.2,
      maxBacklogs: 0,
      eligibleBranches: [],
      requiredSkills: ['SQL', 'Python'],
      requiredCertifications: []
    },
    createdAt: '2026-10-10'
  },
  // Internship 11 (PENDING FACULTY APPROVAL)
  {
    id: 'internship-11',
    companyId: 'company-3',
    company: INITIAL_COMPANIES[2],
    role: 'Robotics & Computer Vision Research Intern',
    description: 'Develop stereo-vision point cloud depth estimators and real-time obstacle avoidance models for industrial robotic arms.',
    duration: '6 Months',
    stipend: 32000,
    location: 'Hyderabad',
    workMode: 'ONSITE',
    vacancies: 2,
    deadline: '2026-12-20',
    interviewStages: ['CODING_TEST', 'TECHNICAL', 'HR'],
    status: 'PENDING_APPROVAL',
    criteria: {
      minCgpa: 8.0,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'ECE', 'MECH'],
      requiredSkills: ['C++', 'Python'],
      requiredCertifications: []
    },
    createdAt: '2026-10-16'
  },
  // Internship 12 (PENDING FACULTY APPROVAL)
  {
    id: 'internship-12',
    companyId: 'company-4',
    company: INITIAL_COMPANIES[3],
    role: 'Cloud Security Analyst Intern',
    description: 'Perform AWS IAM privilege auditing, posture management, and threat surface minimization for multi-tenant SaaS clients.',
    duration: '6 Months',
    stipend: 24000,
    location: 'Mumbai',
    workMode: 'REMOTE',
    vacancies: 2,
    deadline: '2026-12-28',
    interviewStages: ['TECHNICAL', 'HR'],
    status: 'PENDING_APPROVAL',
    criteria: {
      minCgpa: 7.6,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['AWS', 'Linux'],
      requiredCertifications: []
    },
    createdAt: '2026-10-17'
  }
];

export const INITIAL_APPLICATIONS: InternshipApplication[] = [
  // Application 1: Demo Student applied for Backend Development Intern
  {
    id: 'app-1',
    internshipId: 'internship-1',
    studentId: 'student-1',
    student: INITIAL_STUDENTS[0],
    internship: INITIAL_INTERNSHIPS[0],
    applicationDate: '2026-10-05',
    status: 'INTERVIEW_SCHEDULED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-1',
      applicationId: 'app-1',
      atrScore: 85,
      aptitudeScore: 90,
      codingScore: 92,
      updatedAt: '2026-10-08'
    },
    interviews: [
      {
        id: 'int-1',
        applicationId: 'app-1',
        round: 1,
        type: 'APTITUDE_TEST',
        scheduledDate: '2026-10-10T10:00:00Z',
        mode: 'ONLINE',
        result: 'PASS',
        remarks: 'Cleared online aptitude with 90 percentile.'
      },
      {
        id: 'int-2',
        applicationId: 'app-1',
        round: 2,
        type: 'CODING_TEST',
        scheduledDate: '2026-10-14T14:30:00Z',
        mode: 'ONLINE',
        result: 'PASS',
        remarks: 'Solved all 3 algorithmic challenges (Greedy, DP, Graph).'
      },
      {
        id: 'int-3',
        applicationId: 'app-1',
        round: 3,
        type: 'TECHNICAL',
        scheduledDate: '2026-10-22T11:00:00Z',
        mode: 'ONLINE',
        result: 'PENDING',
        remarks: 'Upcoming round with Lead Systems Architect.'
      }
    ]
  },
  // Application 2: Priya Iyer selected for DevOps at CloudScale
  {
    id: 'app-2',
    internshipId: 'internship-3',
    studentId: 'student-4',
    student: INITIAL_STUDENTS[3],
    internship: INITIAL_INTERNSHIPS[2],
    applicationDate: '2026-10-06',
    status: 'SELECTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-2',
      applicationId: 'app-2',
      atrScore: 92,
      aptitudeScore: 95,
      codingScore: 88,
      updatedAt: '2026-10-12'
    },
    interviews: [
      {
        id: 'int-4',
        applicationId: 'app-2',
        round: 1,
        type: 'CODING_TEST',
        scheduledDate: '2026-10-09T10:00:00Z',
        mode: 'ONLINE',
        result: 'PASS',
        remarks: 'Excellent bash and Python scripting.'
      },
      {
        id: 'int-5',
        applicationId: 'app-2',
        round: 2,
        type: 'TECHNICAL',
        scheduledDate: '2026-10-12T15:00:00Z',
        mode: 'ONLINE',
        result: 'PASS',
        remarks: 'Deep knowledge of Kubernetes pod life cycles.'
      },
      {
        id: 'int-6',
        applicationId: 'app-2',
        round: 3,
        type: 'HR',
        scheduledDate: '2026-10-15T16:00:00Z',
        mode: 'ONLINE',
        result: 'PASS',
        remarks: 'Great cultural fit and leadership initiative.'
      }
    ],
    offer: {
      id: 'offer-1',
      applicationId: 'app-2',
      studentId: 'student-4',
      companyId: 'company-2',
      status: 'EXTENDED',
      offerDate: '2026-10-16',
      stipend: 28000,
      validUntil: '2026-10-25',
      letterText: 'We are pleased to extend an offer for Cloud & DevOps Engineering Intern.'
    }
  },
  // Application 3: Tanvi Shah received and ACCEPTED offer at FinEdge Capital
  {
    id: 'app-3',
    internshipId: 'internship-7',
    studentId: 'student-12',
    student: INITIAL_STUDENTS[11],
    internship: INITIAL_INTERNSHIPS[6],
    applicationDate: '2026-10-08',
    status: 'SELECTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-3',
      applicationId: 'app-3',
      atrScore: 96,
      aptitudeScore: 98,
      codingScore: 94,
      updatedAt: '2026-10-14'
    },
    interviews: [
      {
        id: 'int-7',
        applicationId: 'app-3',
        round: 1,
        type: 'APTITUDE_TEST',
        scheduledDate: '2026-10-10T10:00:00Z',
        mode: 'ONLINE',
        result: 'PASS'
      },
      {
        id: 'int-8',
        applicationId: 'app-3',
        round: 2,
        type: 'CODING_TEST',
        scheduledDate: '2026-10-12T14:00:00Z',
        mode: 'ONLINE',
        result: 'PASS'
      },
      {
        id: 'int-9',
        applicationId: 'app-3',
        round: 3,
        type: 'TECHNICAL',
        scheduledDate: '2026-10-14T11:00:00Z',
        mode: 'ONLINE',
        result: 'PASS'
      },
      {
        id: 'int-10',
        applicationId: 'app-3',
        round: 4,
        type: 'HR',
        scheduledDate: '2026-10-15T16:00:00Z',
        mode: 'ONLINE',
        result: 'PASS'
      }
    ],
    offer: {
      id: 'offer-2',
      applicationId: 'app-3',
      studentId: 'student-12',
      companyId: 'company-6',
      status: 'ACCEPTED',
      offerDate: '2026-10-16',
      stipend: 45000,
      validUntil: '2026-10-24',
      letterText: 'Congratulations Tanvi! Your offer as Quantitative Software Engineer Intern is accepted.'
    }
  },
  // Application 4: Aarav Patel at QuantumAI (Company Shortlisted)
  {
    id: 'app-4',
    internshipId: 'internship-4',
    studentId: 'student-3',
    student: INITIAL_STUDENTS[2],
    internship: INITIAL_INTERNSHIPS[3],
    applicationDate: '2026-10-07',
    status: 'COMPANY_SHORTLISTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-4',
      applicationId: 'app-4',
      atrScore: 88,
      aptitudeScore: 85,
      codingScore: 90,
      updatedAt: '2026-10-11'
    },
    interviews: []
  },
  // Application 5: Siddharth Sen at CyberShield (Faculty Shortlisted)
  {
    id: 'app-5',
    internshipId: 'internship-5',
    studentId: 'student-9',
    student: INITIAL_STUDENTS[8],
    internship: INITIAL_INTERNSHIPS[4],
    applicationDate: '2026-10-09',
    status: 'FACULTY_SHORTLISTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-5',
      applicationId: 'app-5',
      atrScore: 78,
      aptitudeScore: 82,
      codingScore: 75,
      updatedAt: '2026-10-13'
    },
    interviews: []
  },
  // Application 6: Rohan Verma at PulseHealth (Applied)
  {
    id: 'app-6',
    internshipId: 'internship-6',
    studentId: 'student-6',
    student: INITIAL_STUDENTS[5],
    internship: INITIAL_INTERNSHIPS[5],
    applicationDate: '2026-10-12',
    status: 'APPLIED',
    resumeMatchScore: 100,
    interviews: []
  },
  // Application 7: Neha Joshi at NexaTech Backend (Applied)
  {
    id: 'app-7',
    internshipId: 'internship-1',
    studentId: 'student-10',
    student: INITIAL_STUDENTS[9],
    internship: INITIAL_INTERNSHIPS[0],
    applicationDate: '2026-10-11',
    status: 'FACULTY_SHORTLISTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-7',
      applicationId: 'app-7',
      atrScore: 80,
      aptitudeScore: 80,
      codingScore: 80,
      updatedAt: '2026-10-14'
    },
    interviews: []
  },
  // Application 8: Aishwarya Saxena at NexaTech Backend (Company Shortlisted)
  {
    id: 'app-8',
    internshipId: 'internship-1',
    studentId: 'student-20',
    student: INITIAL_STUDENTS[19],
    internship: INITIAL_INTERNSHIPS[0],
    applicationDate: '2026-10-06',
    status: 'COMPANY_SHORTLISTED',
    resumeMatchScore: 100,
    assessment: {
      id: 'asm-8',
      applicationId: 'app-8',
      atrScore: 84,
      aptitudeScore: 86,
      codingScore: 88,
      updatedAt: '2026-10-10'
    },
    interviews: []
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    userId: 'user-stu-1',
    type: 'INTERVIEW',
    title: 'Round 3 Technical Interview Scheduled',
    message: 'Your Technical interview round for Backend Development Intern at NexaTech Solutions is set for Oct 22, 11:00 AM.',
    read: false,
    createdAt: '2026-10-17T09:30:00Z',
    linkTab: 'applications'
  },
  {
    id: 'notif-2',
    userId: 'user-stu-1',
    type: 'VERIFICATION',
    title: 'Academic Profile Verified',
    message: 'Dr. Anand Mehta has officially verified your academic records and CGPA.',
    read: true,
    createdAt: '2026-09-15T14:00:00Z',
    linkTab: 'profile'
  },
  {
    id: 'notif-3',
    userId: 'user-stu-1',
    type: 'CRITERIA_MATCH',
    title: 'Eligible for New Opening',
    message: 'You satisfy all eligibility criteria for Backend Development Intern at NexaTech Solutions.',
    read: true,
    createdAt: '2026-10-01T10:00:00Z',
    linkTab: 'browse'
  },
  {
    id: 'notif-4',
    userId: 'user-fac-1',
    type: 'APPLICATION',
    title: 'Pending Internship Approvals (2)',
    message: 'QuantumAI Labs and CyberShield Defense have posted new internships awaiting faculty approval.',
    read: false,
    createdAt: '2026-10-17T08:00:00Z',
    linkTab: 'approvals'
  },
  {
    id: 'notif-5',
    userId: 'user-com-1',
    type: 'APPLICATION',
    title: 'New Applicant in Pipeline',
    message: 'Demo Student and 3 others have progressed in the Backend Development pipeline.',
    read: false,
    createdAt: '2026-10-14T15:00:00Z',
    linkTab: 'applicants'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'audit-001',
    timestamp: '2026-10-18T01:10:00.000Z',
    userId: 'user-adm-1',
    userEmail: 'admin@demo.com',
    userRole: 'ADMIN',
    action: 'SYSTEM_BOOTSTRAP',
    details: 'System initialized with institutional RBAC policies, eligibility engine v2, and campus directory.',
    status: 'SUCCESS',
    ipAddress: '192.168.1.1'
  },
  {
    id: 'audit-002',
    timestamp: '2026-10-18T01:15:22.000Z',
    userId: 'user-fac-1',
    userEmail: 'faculty@demo.com',
    userRole: 'FACULTY',
    action: 'PROFILE_VERIFICATION',
    details: 'Verified academic credentials and semester records for student: Demo Student (PRN: 2023CSE0142).',
    status: 'SUCCESS',
    resourceId: 'student-1',
    ipAddress: '172.16.4.12'
  },
  {
    id: 'audit-003',
    timestamp: '2026-10-18T01:25:40.000Z',
    userId: 'user-com-1',
    userEmail: 'company@demo.com',
    userRole: 'COMPANY',
    action: 'CRITERIA_CONFIGURED',
    details: 'Defined recruitment criteria for role "Backend Development Intern" (Min CGPA: 7.5, Backlogs: 0, CSE/IT).',
    status: 'SUCCESS',
    resourceId: 'intern-1',
    ipAddress: '103.22.14.88'
  },
  {
    id: 'audit-004',
    timestamp: '2026-10-18T01:30:15.000Z',
    userId: 'user-stu-1',
    userEmail: 'student@demo.com',
    userRole: 'STUDENT',
    action: 'LOGIN_SUCCESS',
    details: 'Authenticated student session established for Demo Student.',
    status: 'SUCCESS',
    ipAddress: '192.168.10.45'
  },
  {
    id: 'audit-005',
    timestamp: '2026-10-18T01:45:00.000Z',
    userId: 'user-stu-1',
    userEmail: 'student@demo.com',
    userRole: 'STUDENT',
    action: 'SECURITY_ENFORCEMENT',
    details: 'Blocked attempt by student account to access unverified faculty administrative endpoints.',
    status: 'BLOCKED',
    ipAddress: '192.168.10.45'
  }
];

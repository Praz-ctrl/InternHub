import React, { useState, useEffect } from 'react';
import {
  User,
  Student,
  Internship,
  InternshipApplication,
  StudentDocument
} from '@/types';
import { api } from '@/services/api';
import { useToast } from '@/components/Toast';
import { StatusPill } from '@/components/common/StatusPill';
import { Modal } from '@/components/common/Modal';
import { Drawer } from '@/components/common/Drawer';
import { AnalyticsView } from './AnalyticsView';
import {
  ShieldCheck,
  FileCheck,
  Briefcase,
  BarChart3,
  Search,
  CheckCircle2,
  XCircle,
  Eye,
  Award,
  Calendar,
  Building,
  CheckSquare,
  AlertTriangle,
  UserCheck
} from 'lucide-react';

interface FacultyDashboardProps {
  currentUser: User;
  initialTab?: string;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({ currentUser, initialTab = 'verification' }) => {
  const { success, error, info } = useToast();
  const [activeTab, setActiveTab] = useState<string>(initialTab);

  const [students, setStudents] = useState<Student[]>([]);
  const [pendingInternships, setPendingInternships] = useState<Internship[]>([]);
  const [applications, setApplications] = useState<InternshipApplication[]>([]);
  const [loading, setLoading] = useState(true);

  // Verification filter & search
  const [searchStudent, setSearchStudent] = useState('');
  const [verificationFilter, setVerificationFilter] = useState<'ALL' | 'PENDING' | 'VERIFIED'>('ALL');
  const [selectedStudentForDocs, setSelectedStudentForDocs] = useState<Student | null>(null);
  const [studentDocs, setStudentDocs] = useState<StudentDocument[]>([]);

  // Action Modals
  const [verifyModalStudent, setVerifyModalStudent] = useState<Student | null>(null);
  const [verifyStatusAction, setVerifyStatusAction] = useState<'VERIFIED' | 'REJECTED'>('VERIFIED');
  const [verifyRemarks, setVerifyRemarks] = useState('');

  // ATR modal
  const [atrModalApp, setAtrModalApp] = useState<InternshipApplication | null>(null);
  const [atrScoreInput, setAtrScoreInput] = useState(80);

  // Reject application modal
  const [rejectModalApp, setRejectModalApp] = useState<InternshipApplication | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  // Decline internship modal
  const [declineInternshipItem, setDeclineInternshipItem] = useState<Internship | null>(null);
  const [declineReason, setDeclineReason] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [allStudents, pendingInts, allApps] = await Promise.all([
        api.getAllStudents(),
        api.getPendingInternships(),
        api.getAllApplications()
      ]);
      setStudents(allStudents);
      setPendingInternships(pendingInts);
      setApplications(allApps);
    } catch (err: any) {
      error('Failed to load faculty records', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
  }, [initialTab]);

  // Open documents drawer for student
  const handleOpenDocs = async (s: Student) => {
    setSelectedStudentForDocs(s);
    try {
      const docs = await api.getStudentDocuments(s.id);
      setStudentDocs(docs);
    } catch (err: any) {
      error('Failed to load documents', err.message);
    }
  };

  // Student verification submit
  const handleVerifySubmit = async () => {
    if (!verifyModalStudent) return;
    try {
      await api.verifyStudent(
        verifyModalStudent.id,
        verifyStatusAction,
        currentUser.name,
        verifyRemarks
      );
      success(
        `Student profile ${verifyStatusAction.toLowerCase()}!`,
        `${verifyModalStudent.name} is now ${verifyStatusAction === 'VERIFIED' ? 'eligible for matching roles' : 'flagged for revisions'}.`
      );
      setVerifyModalStudent(null);
      setVerifyRemarks('');
      loadData();
    } catch (err: any) {
      error('Action failed', err.message);
    }
  };

  // Bulk verify pending
  const handleBulkVerify = async () => {
    const pending = students.filter(s => !s.verified);
    if (pending.length === 0) {
      info('No pending students to verify.');
      return;
    }
    try {
      for (const s of pending) {
        await api.verifyStudent(s.id, 'VERIFIED', currentUser.name, 'Bulk approved during verification drive.');
      }
      success(`Verified ${pending.length} pending student profiles!`);
      loadData();
    } catch (err: any) {
      error('Bulk verification failed', err.message);
    }
  };

  // Document verification within drawer
  const handleDocVerify = async (docId: string, status: 'VERIFIED' | 'REJECTED') => {
    try {
      await api.verifyStudentDocument(docId, status);
      success(`Document marked as ${status}`);
      if (selectedStudentForDocs) {
        const docs = await api.getStudentDocuments(selectedStudentForDocs.id);
        setStudentDocs(docs);
      }
    } catch (err: any) {
      error('Failed to update document status', err.message);
    }
  };

  // Application shortlisting
  const handleFacultyShortlist = async (appId: string) => {
    try {
      await api.facultyShortlistApplication(appId);
      success('Candidate shortlisted by Faculty Placement Cell', 'Handed off to company review.');
      loadData();
    } catch (err: any) {
      error('Cannot shortlist', err.message);
    }
  };

  const handleSaveAtr = async () => {
    if (!atrModalApp) return;
    try {
      await api.recordAtrScore(atrModalApp.id, atrScoreInput);
      success('ATR score recorded!');
      setAtrModalApp(null);
      loadData();
    } catch (err: any) {
      error('Failed to save ATR', err.message);
    }
  };

  const handleRejectApp = async () => {
    if (!rejectModalApp) return;
    try {
      await api.rejectCandidate(rejectModalApp.id, rejectReason);
      success('Application rejected by faculty cell.');
      setRejectModalApp(null);
      setRejectReason('');
      loadData();
    } catch (err: any) {
      error('Failed to reject application', err.message);
    }
  };

  // Internship approvals
  const handleApproveInternship = async (id: string) => {
    try {
      await api.approveInternship(id);
      success('Internship approved and published live!', 'Notified all students who satisfy criteria.');
      loadData();
    } catch (err: any) {
      error('Approval failed', err.message);
    }
  };

  const handleDeclineInternship = async () => {
    if (!declineInternshipItem) return;
    try {
      await api.declineInternship(declineInternshipItem.id, declineReason);
      success('Internship declined.');
      setDeclineInternshipItem(null);
      setDeclineReason('');
      loadData();
    } catch (err: any) {
      error('Action failed', err.message);
    }
  };

  // Filtered students
  const filteredStudents = students.filter(s => {
    const q = searchStudent.toLowerCase();
    const matchesSearch = !q || s.name.toLowerCase().includes(q) || s.prn.toLowerCase().includes(q) || s.department.toLowerCase().includes(q);
    if (!matchesSearch) return false;
    if (verificationFilter === 'PENDING') return !s.verified;
    if (verificationFilter === 'VERIFIED') return s.verified;
    return true;
  });

  const pendingVerificationCount = students.filter(s => !s.verified).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Faculty Hero Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-navy-900 via-indigo-950 to-brand-indigo p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 uppercase tracking-wider text-white">
              Faculty Training &amp; Placement Cell
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Academic Verification &amp; Placement Control
          </h1>
          <p className="text-slate-300 text-sm mt-1 max-w-2xl">
            Verify student marksheets and profile credentials, filter candidates via ATR assessment scores, and review incoming industry postings.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15 text-center">
            <div className="text-2xl font-black text-amber-300">
              {pendingVerificationCount}
            </div>
            <div className="text-[11px] uppercase tracking-wider text-slate-300 font-semibold">
              Pending Students
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15 text-center">
            <div className="text-2xl font-black text-brand-cyan">
              {pendingInternships.length}
            </div>
            <div className="text-[11px] uppercase tracking-wider text-slate-300 font-semibold">
              Pending Roles
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'verification', label: 'Student Verification Queue', icon: UserCheck, count: pendingVerificationCount },
          { id: 'applications', label: 'Application Shortlisting & ATR', icon: Briefcase, count: applications.length },
          { id: 'approvals', label: 'Internship Approvals Inbox', icon: FileCheck, count: pendingInternships.length },
          { id: 'analytics', label: 'Placement Analytics & Funnel', icon: BarChart3 }
        ].map(({ id, label, icon: Icon, count }) => {
          const isActive = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-brand-indigo text-white shadow-md shadow-brand-indigo/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
              {count !== undefined && count > 0 && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-xs font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ======================================================== */}
      {/* TAB 1: STUDENT VERIFICATION QUEUE */}
      {/* ======================================================== */}
      {activeTab === 'verification' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          {/* Controls Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search by student name, PRN, or department..."
                value={searchStudent}
                onChange={e => setSearchStudent(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-indigo"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-medium">
                {(['ALL', 'PENDING', 'VERIFIED'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setVerificationFilter(tab)}
                    className={`px-3 py-1.5 rounded-lg transition-colors ${
                      verificationFilter === tab
                        ? 'bg-white dark:bg-slate-900 text-brand-indigo font-bold shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {tab === 'ALL' ? 'All' : tab === 'PENDING' ? 'Pending Only' : 'Verified'}
                  </button>
                ))}
              </div>

              {pendingVerificationCount > 0 && (
                <button
                  onClick={handleBulkVerify}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                >
                  <CheckSquare className="w-4 h-4" />
                  Bulk Verify All ({pendingVerificationCount})
                </button>
              )}
            </div>
          </div>

          {/* Students Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/60 uppercase font-semibold text-[10px] text-slate-400 tracking-wider">
                <tr>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">PRN</th>
                  <th className="p-3">Department</th>
                  <th className="p-3">Sem</th>
                  <th className="p-3">CGPA</th>
                  <th className="p-3">Backlogs</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      No students found matching current filters.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map(s => (
                    <tr key={s.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-semibold text-slate-900 dark:text-white">
                        {s.name}
                      </td>
                      <td className="p-3 font-mono text-[11px]">{s.prn}</td>
                      <td className="p-3 font-medium">{s.department}</td>
                      <td className="p-3">{s.semester}</td>
                      <td className="p-3 font-bold text-slate-800 dark:text-slate-200">
                        {s.cgpa.toFixed(2)}
                      </td>
                      <td className="p-3">
                        <span className={s.backlogs > 0 ? 'text-rose-600 font-bold' : 'text-slate-400'}>
                          {s.backlogs}
                        </span>
                      </td>
                      <td className="p-3">
                        {s.verified ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                            <CheckCircle2 className="w-3 h-3" />
                            VERIFIED
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                            <AlertTriangle className="w-3 h-3" />
                            PENDING
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => handleOpenDocs(s)}
                          className="px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-medium"
                        >
                          Docs
                        </button>
                        <button
                          onClick={() => {
                            setVerifyModalStudent(s);
                            setVerifyStatusAction('VERIFIED');
                          }}
                          className="px-2.5 py-1 rounded-lg text-emerald-700 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold"
                        >
                          Verify
                        </button>
                        <button
                          onClick={() => {
                            setVerifyModalStudent(s);
                            setVerifyStatusAction('REJECTED');
                          }}
                          className="px-2.5 py-1 rounded-lg text-rose-700 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 border border-rose-200 dark:border-rose-800 text-xs font-semibold"
                        >
                          Reject
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: APPLICATION SHORTLISTING & ATR SCORING */}
      {/* ======================================================== */}
      {activeTab === 'applications' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Application Shortlisting &amp; ATR Assessment
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Enforce minimum Academic &amp; Technical Rating (ATR) thresholds before shortlisting candidates for company evaluation.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/60 uppercase font-semibold text-[10px] text-slate-400 tracking-wider">
                <tr>
                  <th className="p-3">Candidate</th>
                  <th className="p-3">Branch &amp; CGPA</th>
                  <th className="p-3">Applied Role &amp; Company</th>
                  <th className="p-3">Resume Match</th>
                  <th className="p-3">ATR Score</th>
                  <th className="p-3">Current Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {applications.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      No applications submitted yet.
                    </td>
                  </tr>
                ) : (
                  applications.map(app => {
                    const minAtrRequired = app.internship.criteria?.minAtrScore;
                    const canShortlist = app.status === 'APPLIED' || app.status === 'RESUME_SCORED';

                    return (
                      <tr key={app.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-semibold text-slate-900 dark:text-white">
                          <div>{app.student.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{app.student.prn}</div>
                        </td>
                        <td className="p-3">
                          {app.student.department} · {app.student.cgpa.toFixed(2)} CGPA
                        </td>
                        <td className="p-3">
                          <div className="font-medium text-slate-800 dark:text-slate-200">
                            {app.internship.role}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {app.internship.company.companyName}
                          </div>
                        </td>
                        <td className="p-3 font-bold text-brand-blue dark:text-brand-cyan">
                          {app.resumeMatchScore}%
                        </td>
                        <td className="p-3">
                          {app.assessment?.atrScore != null ? (
                            <span className="font-bold text-slate-800 dark:text-slate-100">
                              {app.assessment.atrScore} / 100
                            </span>
                          ) : (
                            <span className="text-amber-600 dark:text-amber-400 text-[11px]">
                              Not Recorded
                            </span>
                          )}
                          {minAtrRequired && (
                            <div className="text-[10px] text-slate-400">
                              (Min cut-off: {minAtrRequired})
                            </div>
                          )}
                        </td>
                        <td className="p-3">
                          <StatusPill status={app.status} />
                        </td>
                        <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => {
                              setAtrModalApp(app);
                              setAtrScoreInput(app.assessment?.atrScore || 80);
                            }}
                            className="px-2.5 py-1 rounded-lg text-brand-indigo bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 text-xs font-semibold"
                          >
                            Set ATR
                          </button>

                          {canShortlist && (
                            <button
                              onClick={() => handleFacultyShortlist(app.id)}
                              className="px-2.5 py-1 rounded-lg text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold"
                            >
                              Shortlist
                            </button>
                          )}

                          {!['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(app.status) && (
                            <button
                              onClick={() => setRejectModalApp(app)}
                              className="px-2.5 py-1 rounded-lg text-rose-700 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 border border-rose-200 dark:border-rose-800 text-xs font-semibold"
                            >
                              Reject
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: INTERNSHIP APPROVALS INBOX */}
      {/* ======================================================== */}
      {activeTab === 'approvals' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Company Internship Postings Inbox
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Validate industry curriculum alignment, stipends, and stages before making postings visible to students.
            </p>
          </div>

          {pendingInternships.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              No pending internship approvals in queue. All company roles are currently reviewed.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingInternships.map(internship => (
                <div
                  key={internship.id}
                  className="p-5 rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/20 dark:bg-amber-950/10 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-slate-900 dark:text-white">
                          {internship.role}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                          Awaiting Faculty Approval
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {internship.company.companyName} · Stipend: ₹{internship.stipend.toLocaleString()}/mo · {internship.location} ({internship.workMode})
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setDeclineInternshipItem(internship)}
                        className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-800"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => handleApproveInternship(internship.id)}
                        className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                      >
                        Approve &amp; Notify Students
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    {internship.description}
                  </p>

                  <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-1">
                    <div>
                      <span className="font-semibold">Criteria: </span>
                      Min CGPA: {internship.criteria.minCgpa} · Max Backlogs: {internship.criteria.maxBacklogs} · Branches: {internship.criteria.eligibleBranches?.length ? internship.criteria.eligibleBranches.join(', ') : 'Any'}
                    </div>
                    <div>
                      <span className="font-semibold">Required Skills: </span>
                      {internship.criteria.requiredSkills?.join(', ') || 'None specified'}
                    </div>
                    <div>
                      <span className="font-semibold">Configured Pipeline Stages: </span>
                      {internship.interviewStages.map(s => s.replace('_', ' ')).join(' → ')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 4: ANALYTICS & PLACEMENT FUNNEL */}
      {/* ======================================================== */}
      {activeTab === 'analytics' && <AnalyticsView />}

      {/* Student Documents Drawer */}
      <Drawer
        isOpen={!!selectedStudentForDocs}
        onClose={() => setSelectedStudentForDocs(null)}
        title={selectedStudentForDocs ? `${selectedStudentForDocs.name}'s Verification Documents` : 'Documents'}
        subtitle={`PRN: ${selectedStudentForDocs?.prn} · CGPA: ${selectedStudentForDocs?.cgpa}`}
      >
        <div className="space-y-4 text-xs">
          {studentDocs.length === 0 ? (
            <div className="p-8 text-center text-slate-400">
              No documents uploaded by this student yet.
            </div>
          ) : (
            studentDocs.map(doc => (
              <div
                key={doc.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {doc.fileName}
                  </span>
                  <StatusPill status={doc.verificationStatus} />
                </div>
                <div className="text-[11px] text-slate-400">
                  Type: {doc.documentType} · Uploaded: {doc.uploadedAt}
                </div>
                {doc.remarks && (
                  <div className="text-[11px] text-slate-600 dark:text-slate-300 italic">
                    Remarks: "{doc.remarks}"
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700">
                  <a
                    href={doc.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-brand-blue hover:underline font-semibold"
                  >
                    View File
                  </a>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDocVerify(doc.id, 'VERIFIED')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-semibold text-[11px]"
                    >
                      Approve Doc
                    </button>
                    <button
                      onClick={() => handleDocVerify(doc.id, 'REJECTED')}
                      className="px-2.5 py-1 rounded-lg bg-rose-600 text-white font-semibold text-[11px]"
                    >
                      Reject Doc
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Drawer>

      {/* Verify Student Modal */}
      <Modal
        isOpen={!!verifyModalStudent}
        onClose={() => setVerifyModalStudent(null)}
        title={verifyStatusAction === 'VERIFIED' ? 'Approve Student Profile' : 'Reject Student Verification'}
        description={`Record official faculty validation for ${verifyModalStudent?.name} (${verifyModalStudent?.prn}).`}
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Official Remarks / Guidance for Student
            </label>
            <textarea
              rows={3}
              value={verifyRemarks}
              onChange={e => setVerifyRemarks(e.target.value)}
              placeholder="e.g. Marks verified with examination controller; cleared for campus drives."
              className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-indigo"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setVerifyModalStudent(null)}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={handleVerifySubmit}
              className={`px-5 py-2 rounded-xl font-semibold text-white ${
                verifyStatusAction === 'VERIFIED' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              Confirm {verifyStatusAction === 'VERIFIED' ? 'Verification' : 'Rejection'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Record ATR Score Modal */}
      <Modal
        isOpen={!!atrModalApp}
        onClose={() => setAtrModalApp(null)}
        title="Record ATR Score (0 - 100)"
        description={`Enter Academic & Technical Rating for ${atrModalApp?.student.name} for ${atrModalApp?.internship.role}.`}
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              ATR Score (0 - 100)
            </label>
            <input
              type="number"
              min={0}
              max={100}
              value={atrScoreInput}
              onChange={e => setAtrScoreInput(Number(e.target.value))}
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-base"
              required
            />
          </div>
          <p className="text-slate-500">
            Candidate ranking uses: <span className="font-mono text-slate-700 dark:text-slate-300">Composite Score = 0.6 × Resume + 0.4 × ATR</span>.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setAtrModalApp(null)} className="px-4 py-2 rounded-xl text-slate-600">
              Cancel
            </button>
            <button onClick={handleSaveAtr} className="px-5 py-2 rounded-xl bg-brand-indigo text-white font-semibold">
              Save Score
            </button>
          </div>
        </div>
      </Modal>

      {/* Decline Internship Modal */}
      <Modal
        isOpen={!!declineInternshipItem}
        onClose={() => setDeclineInternshipItem(null)}
        title="Decline Internship Posting"
        description={`Notify ${declineInternshipItem?.company.companyName} why this posting cannot be published.`}
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1">Reason for Declining</label>
            <textarea
              rows={3}
              value={declineReason}
              onChange={e => setDeclineReason(e.target.value)}
              placeholder="e.g. Stipend is below statutory norms or duration conflicts with university examination schedule."
              className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setDeclineInternshipItem(null)} className="px-4 py-2 text-slate-600">
              Cancel
            </button>
            <button onClick={handleDeclineInternship} className="px-5 py-2 bg-rose-600 text-white font-semibold rounded-xl">
              Decline Posting
            </button>
          </div>
        </div>
      </Modal>

      {/* Reject Application Modal */}
      <Modal
        isOpen={!!rejectModalApp}
        onClose={() => setRejectModalApp(null)}
        title="Reject Candidate Application"
        description={`Record placement officer decision for ${rejectModalApp?.student.name}.`}
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1">Reason (Optional)</label>
            <input
              type="text"
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              placeholder="e.g. Prerequisite lab scores insufficient."
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setRejectModalApp(null)} className="px-4 py-2 text-slate-600">
              Cancel
            </button>
            <button onClick={handleRejectApp} className="px-5 py-2 bg-rose-600 text-white font-semibold rounded-xl">
              Confirm Reject
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

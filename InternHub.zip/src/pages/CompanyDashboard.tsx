import React, { useState, useEffect, useMemo } from 'react';
import {
  User,
  Company,
  Internship,
  InternshipApplication,
  RankedCandidate,
  Student,
  InterviewStage,
  WorkMode
} from '@/types';
import { api } from '@/services/api';
import { useToast } from '@/components/Toast';
import { StatusPill } from '@/components/common/StatusPill';
import { Modal } from '@/components/common/Modal';
import { getLivePreviewMatches } from '@/lib/eligibility';
import {
  Briefcase,
  Users,
  Plus,
  Edit3,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  BarChart2,
  Columns,
  ListOrdered,
  Layers,
  ArrowRight,
  TrendingUp,
  MapPin,
  IndianRupee,
  Lock,
  ChevronRight,
  Sliders,
  Send
} from 'lucide-react';

interface CompanyDashboardProps {
  currentUser: User;
  initialTab?: string;
}

export const CompanyDashboard: React.FC<CompanyDashboardProps> = ({ currentUser, initialTab = 'post' }) => {
  const { success, error, info } = useToast();
  const [activeTab, setActiveTab] = useState<string>(initialTab);

  const [company, setCompany] = useState<Company | null>(null);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [allStudents, setAllStudents] = useState<Student[]>([]);
  const [selectedInternshipId, setSelectedInternshipId] = useState<string>('');
  const [rankedCandidates, setRankedCandidates] = useState<RankedCandidate[]>([]);
  const [applications, setApplications] = useState<InternshipApplication[]>([]);
  const [viewMode, setViewMode] = useState<'KANBAN' | 'RANKED'>('KANBAN');
  const [loading, setLoading] = useState(true);

  // Compare candidates (up to 3)
  const [selectedCompareIds, setSelectedCompareIds] = useState<string[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Modals
  const [showPostModal, setShowPostModal] = useState(false);
  const [editingInternship, setEditingInternship] = useState<Internship | null>(null);

  // Interview scheduler modal
  const [scheduleModalApp, setScheduleModalApp] = useState<InternshipApplication | null>(null);
  const [interviewForm, setInterviewForm] = useState<{
    stage: InterviewStage;
    scheduledDate: string;
    mode: 'ONLINE' | 'OFFLINE';
  }>({
    stage: 'TECHNICAL',
    scheduledDate: new Date(Date.now() + 2 * 24 * 3600 * 1000).toISOString().slice(0, 16),
    mode: 'ONLINE'
  });

  // Record interview result modal
  const [resultModalItem, setResultModalItem] = useState<{ interviewId: string; round: number } | null>(null);
  const [interviewResultChoice, setInterviewResultChoice] = useState<'PASS' | 'FAIL'>('PASS');
  const [interviewResultRemarks, setInterviewResultRemarks] = useState('');

  // Extend offer modal
  const [offerModalApp, setOfferModalApp] = useState<InternshipApplication | null>(null);
  const [offerStipend, setOfferStipend] = useState(25000);
  const [offerValidUntil, setOfferValidUntil] = useState('2026-12-31');
  const [offerLetterText, setOfferLetterText] = useState('');

  // Post / Edit Form State
  const [formState, setFormState] = useState({
    role: '',
    description: '',
    duration: '6 Months',
    stipend: 25000,
    location: 'Pune',
    workMode: 'HYBRID' as WorkMode,
    vacancies: 3,
    deadline: new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().split('T')[0],
    interviewStages: ['APTITUDE_TEST', 'CODING_TEST', 'TECHNICAL', 'HR'] as InterviewStage[],
    criteria: {
      minCgpa: 7.5,
      maxBacklogs: 0,
      eligibleBranches: ['CSE', 'IT'],
      requiredSkills: ['Java', 'SQL'],
      requiredCertifications: [] as string[],
      minAtrScore: 60
    }
  });

  // Load Data
  const loadData = async () => {
    try {
      setLoading(true);
      const comp = await api.getCompanyProfile(currentUser.profileId);
      setCompany(comp);

      const [myInternships, studentsList, allApps] = await Promise.all([
        api.getCompanyInternships(comp.id),
        api.getAllStudents(),
        api.getAllApplications()
      ]);

      setInternships(myInternships);
      setAllStudents(studentsList);

      const activeId = selectedInternshipId || myInternships[0]?.id || '';
      setSelectedInternshipId(activeId);

      if (activeId) {
        const [ranked] = await Promise.all([
          api.getRankedApplicants(activeId)
        ]);
        setRankedCandidates(ranked);
        setApplications(allApps.filter(a => a.internshipId === activeId));
      }
    } catch (err: any) {
      error('Failed to load company dashboard', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser.profileId]);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (selectedInternshipId) {
      api.getRankedApplicants(selectedInternshipId).then(setRankedCandidates).catch(() => {});
      api.getAllApplications().then(all => {
        setApplications(all.filter(a => a.internshipId === selectedInternshipId));
      }).catch(() => {});
    }
  }, [selectedInternshipId]);

  // Live Preview simulation for criteria editing
  const livePreview = useMemo(() => {
    return getLivePreviewMatches(allStudents, formState.criteria as any);
  }, [allStudents, formState.criteria]);

  // Handle open post modal
  const handleOpenPostModal = (existing?: Internship) => {
    if (existing) {
      setEditingInternship(existing);
      setFormState({
        role: existing.role,
        description: existing.description,
        duration: existing.duration,
        stipend: existing.stipend,
        location: existing.location,
        workMode: existing.workMode,
        vacancies: existing.vacancies,
        deadline: existing.deadline,
        interviewStages: existing.interviewStages,
        criteria: {
          minCgpa: existing.criteria.minCgpa,
          maxBacklogs: existing.criteria.maxBacklogs,
          eligibleBranches: existing.criteria.eligibleBranches || [],
          requiredSkills: existing.criteria.requiredSkills || [],
          requiredCertifications: existing.criteria.requiredCertifications || [],
          minAtrScore: existing.criteria.minAtrScore || 0
        }
      });
    } else {
      setEditingInternship(null);
      setFormState({
        role: 'Full Stack Engineer Intern',
        description: 'Build enterprise microservices and customer portal apps.',
        duration: '6 Months',
        stipend: 25000,
        location: company?.location || 'Pune',
        workMode: 'HYBRID',
        vacancies: 3,
        deadline: new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().split('T')[0],
        interviewStages: ['APTITUDE_TEST', 'CODING_TEST', 'TECHNICAL', 'HR'],
        criteria: {
          minCgpa: 7.5,
          maxBacklogs: 0,
          eligibleBranches: ['CSE', 'IT'],
          requiredSkills: ['Java', 'SQL'],
          requiredCertifications: [],
          minAtrScore: 60
        }
      });
    }
    setShowPostModal(true);
  };

  const handleSaveInternship = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!company) return;

    try {
      if (editingInternship) {
        // Dynamic preference update
        await api.updateInternshipCriteria(editingInternship.id, company.id, {
          role: formState.role,
          description: formState.description,
          duration: formState.duration,
          stipend: Number(formState.stipend),
          location: formState.location,
          workMode: formState.workMode,
          vacancies: Number(formState.vacancies),
          deadline: formState.deadline,
          interviewStages: formState.interviewStages,
          criteria: formState.criteria as any
        });
        success('Criteria updated!', 'Live re-evaluation complete. Newly eligible candidates have been notified!');
      } else {
        await api.createInternship(company.id, {
          role: formState.role,
          description: formState.description,
          duration: formState.duration,
          stipend: Number(formState.stipend),
          location: formState.location,
          workMode: formState.workMode,
          vacancies: Number(formState.vacancies),
          deadline: formState.deadline,
          interviewStages: formState.interviewStages,
          criteria: formState.criteria as any
        });
        success('Internship submitted!', 'Submitted to Faculty Placement Cell for curriculum approval.');
      }
      setShowPostModal(false);
      loadData();
    } catch (err: any) {
      error('Failed to save internship', err.message);
    }
  };

  // Pipeline transitions
  const handleCompanyShortlist = async (appId: string) => {
    try {
      await api.companyShortlistApplication(appId);
      success('Candidate shortlisted for interviews.');
      loadData();
    } catch (err: any) {
      error('Shortlist error', err.message);
    }
  };

  const handleScheduleSubmit = async () => {
    if (!scheduleModalApp) return;
    try {
      await api.scheduleInterview(
        scheduleModalApp.id,
        interviewForm.stage,
        interviewForm.scheduledDate,
        interviewForm.mode
      );
      success('Interview scheduled and sent to student portal.');
      setScheduleModalApp(null);
      loadData();
    } catch (err: any) {
      error('Scheduling error', err.message);
    }
  };

  const handleRecordResultSubmit = async () => {
    if (!resultModalItem) return;
    try {
      await api.recordInterviewResult(
        resultModalItem.interviewId,
        interviewResultChoice,
        interviewResultRemarks
      );
      success(`Interview marked as ${interviewResultChoice}`);
      setResultModalItem(null);
      setInterviewResultRemarks('');
      loadData();
    } catch (err: any) {
      error('Result save failed', err.message);
    }
  };

  const handleSelectCandidate = async (appId: string) => {
    try {
      await api.selectCandidate(appId);
      success('Candidate Selected!', 'All interview stages cleared.');
      loadData();
    } catch (err: any) {
      error('Selection failed', err.message);
    }
  };

  const handleExtendOfferSubmit = async () => {
    if (!offerModalApp) return;
    try {
      await api.extendOffer(
        offerModalApp.id,
        Number(offerStipend),
        offerValidUntil,
        offerLetterText
      );
      success('Offer extended to student!');
      setOfferModalApp(null);
      loadData();
    } catch (err: any) {
      error('Failed to extend offer', err.message);
    }
  };

  const handleRejectCandidate = async (appId: string) => {
    try {
      await api.rejectCandidate(appId, 'Candidate did not meet competitive bar for this batch.');
      success('Candidate marked as rejected.');
      loadData();
    } catch (err: any) {
      error('Action failed', err.message);
    }
  };

  const handleToggleCompare = (appId: string) => {
    setSelectedCompareIds(prev => {
      if (prev.includes(appId)) return prev.filter(id => id !== appId);
      if (prev.length >= 3) {
        info('Can compare maximum 3 candidates simultaneously.');
        return prev;
      }
      return [...prev, appId];
    });
  };

  // Active internship object
  const activeInternship = internships.find(i => i.id === selectedInternshipId);

  // Kanban columns definition
  const kanbanStages = [
    { key: 'APPLIED', label: 'Applied', color: 'border-slate-300' },
    { key: 'FACULTY_SHORTLISTED', label: 'Faculty Shortlisted', color: 'border-blue-400' },
    { key: 'COMPANY_SHORTLISTED', label: 'Company Shortlisted', color: 'border-indigo-400' },
    { key: 'INTERVIEW_SCHEDULED', label: 'Interviewing', color: 'border-amber-400' },
    { key: 'SELECTED', label: 'Selected & Offers', color: 'border-emerald-400' },
    { key: 'REJECTED', label: 'Closed / Rejected', color: 'border-rose-400' }
  ];

  if (loading || !company) {
    return <div className="p-8 text-center text-xs text-slate-400">Loading company workspace...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-navy-900 via-navy-800 to-amber-900/60 p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 uppercase tracking-wider">
              Campus Recruitment Portal
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {company.companyName}
          </h1>
          <p className="text-slate-300 text-sm mt-1 max-w-2xl">
            {company.industry} · Post roles with live student match previews, configure multi-stage interview pipelines, and rank applicants by automated ATS composite scores.
          </p>
        </div>

        <button
          onClick={() => handleOpenPostModal()}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-lg shadow-amber-500/20 shrink-0 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Post New Internship
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'post', label: 'Manage Roles & Dynamic Criteria', icon: Briefcase, count: internships.length },
          { id: 'applicants', label: 'Applicants Pipeline & Kanban', icon: Users, count: applications.length },
          { id: 'ranking', label: 'Candidate ATS Ranking', icon: BarChart2 }
        ].map(({ id, label, icon: Icon, count }) => {
          const isActive = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
              {count !== undefined && (
                <span className={`px-1.5 py-0.5 rounded-full text-xs ${isActive ? 'bg-slate-950 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ======================================================== */}
      {/* TAB 1: MANAGE ROLES & CRITERIA */}
      {/* ======================================================== */}
      {activeTab === 'post' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {internships.map(i => {
              const liveMatches = getLivePreviewMatches(allStudents, i.criteria);
              return (
                <div
                  key={i.id}
                  className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                        {i.role}
                      </h3>
                      <StatusPill status={i.status} />
                    </div>

                    <div className="flex items-center gap-2 flex-wrap text-xs text-slate-500">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        ₹{i.stipend.toLocaleString()}/mo
                      </span>
                      <span>·</span>
                      <span>{i.location} ({i.workMode})</span>
                      <span>·</span>
                      <span>{i.vacancies} vacancies</span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                      {i.description}
                    </p>

                    {/* Criteria Box */}
                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">
                        Min CGPA: {i.criteria.minCgpa} · Max Backlogs: {i.criteria.maxBacklogs}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Branches: {i.criteria.eligibleBranches?.length ? i.criteria.eligibleBranches.join(', ') : 'Any'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Skills: {i.criteria.requiredSkills?.join(', ') || 'Any'}
                      </div>
                      <div className="text-[11px] text-brand-indigo font-medium pt-1">
                        Stages: {i.interviewStages.map(s => s.replace('_', ' ')).join(' → ')}
                      </div>
                    </div>

                    {/* Live Preview Match Badge */}
                    <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex items-center justify-between text-xs">
                      <span className="text-blue-900 dark:text-blue-200 font-medium">
                        Live Matching Students:
                      </span>
                      <span className="font-bold text-brand-blue dark:text-brand-cyan">
                        {liveMatches.matchCount} / {liveMatches.totalStudents}
                      </span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleOpenPostModal(i)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-brand-blue bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      Edit Criteria
                    </button>

                    <button
                      onClick={() => {
                        setSelectedInternshipId(i.id);
                        setActiveTab('applicants');
                      }}
                      className="flex items-center gap-1 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-brand-blue"
                    >
                      View Pipeline →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: APPLICANTS PIPELINE & KANBAN */}
      {/* ======================================================== */}
      {activeTab === 'applicants' && (
        <div className="space-y-6">
          {/* Internship Selector & View Mode Switcher */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Active Opening:
              </label>
              <select
                value={selectedInternshipId}
                onChange={e => setSelectedInternshipId(e.target.value)}
                className="px-3 py-2 text-xs font-bold rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              >
                {internships.map(i => (
                  <option key={i.id} value={i.id}>
                    {i.role} ({i.status})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-3">
              {selectedCompareIds.length > 0 && (
                <button
                  onClick={() => setShowCompareModal(true)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-brand-indigo text-white shadow-sm"
                >
                  <Layers className="w-3.5 h-3.5" />
                  Compare ({selectedCompareIds.length})
                </button>
              )}

              <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setViewMode('KANBAN')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                    viewMode === 'KANBAN'
                      ? 'bg-white dark:bg-slate-900 text-brand-blue font-bold shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  <Columns className="w-3.5 h-3.5" />
                  Kanban
                </button>
                <button
                  onClick={() => setViewMode('RANKED')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                    viewMode === 'RANKED'
                      ? 'bg-white dark:bg-slate-900 text-brand-blue font-bold shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  <ListOrdered className="w-3.5 h-3.5" />
                  Ranked List
                </button>
              </div>
            </div>
          </div>

          {/* Kanban Board View */}
          {viewMode === 'KANBAN' && (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 overflow-x-auto pb-4">
              {kanbanStages.map(({ key, label, color }) => {
                const stageApps = applications.filter(a => {
                  if (key === 'INTERVIEW_SCHEDULED') return a.status === 'INTERVIEW_SCHEDULED';
                  return a.status === key;
                });

                return (
                  <div
                    key={key}
                    className="bg-slate-100/70 dark:bg-slate-900/50 rounded-2xl p-3 flex flex-col space-y-3 min-w-[200px]"
                  >
                    <div className="flex items-center justify-between px-1">
                      <span className="font-bold text-xs text-slate-700 dark:text-slate-300">
                        {label}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 shadow-sm">
                        {stageApps.length}
                      </span>
                    </div>

                    <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[600px]">
                      {stageApps.length === 0 ? (
                        <div className="p-4 text-center text-[11px] text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                          Empty
                        </div>
                      ) : (
                        stageApps.map(app => {
                          const isComparing = selectedCompareIds.includes(app.id);
                          const lastInterview = (app.interviews || []).slice(-1)[0];

                          return (
                            <div
                              key={app.id}
                              className={`p-3 rounded-xl bg-white dark:bg-slate-800 border ${color} shadow-sm space-y-2 text-xs relative`}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <div>
                                  <div className="font-bold text-slate-900 dark:text-white">
                                    {app.student.name}
                                  </div>
                                  <div className="text-[10px] text-slate-400">
                                    {app.student.department} · {app.student.cgpa.toFixed(2)} CGPA
                                  </div>
                                </div>
                                <input
                                  type="checkbox"
                                  checked={isComparing}
                                  onChange={() => handleToggleCompare(app.id)}
                                  className="rounded text-brand-blue mt-0.5"
                                  title="Select for candidate comparison"
                                />
                              </div>

                              <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-400">Match:</span>
                                <span className="font-bold text-brand-blue dark:text-brand-cyan">
                                  {app.resumeMatchScore}%
                                </span>
                              </div>

                              {app.assessment?.atrScore != null && (
                                <div className="flex items-center justify-between text-[11px]">
                                  <span className="text-slate-400">ATR:</span>
                                  <span className="font-bold text-emerald-600 dark:text-emerald-400">
                                    {app.assessment.atrScore}
                                  </span>
                                </div>
                              )}

                              {lastInterview && (
                                <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-[10px] space-y-0.5">
                                  <div className="font-semibold text-slate-700 dark:text-slate-300">
                                    Round {lastInterview.round}: {lastInterview.type.replace('_', ' ')}
                                  </div>
                                  <div className="flex items-center justify-between">
                                    <span className="text-slate-400">{lastInterview.result}</span>
                                    {lastInterview.result === 'PENDING' && (
                                      <button
                                        onClick={() =>
                                          setResultModalItem({
                                            interviewId: lastInterview.id,
                                            round: lastInterview.round
                                          })
                                        }
                                        className="text-brand-blue font-bold hover:underline"
                                      >
                                        Record Pass/Fail
                                      </button>
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Allowed Next Actions */}
                              <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex flex-wrap gap-1">
                                {app.status === 'FACULTY_SHORTLISTED' && (
                                  <button
                                    onClick={() => handleCompanyShortlist(app.id)}
                                    className="w-full py-1 rounded-lg bg-brand-indigo hover:bg-indigo-600 text-white font-semibold text-[10px]"
                                  >
                                    Company Shortlist →
                                  </button>
                                )}

                                {(app.status === 'COMPANY_SHORTLISTED' || app.status === 'INTERVIEW_SCHEDULED') && (
                                  <button
                                    onClick={() => {
                                      setScheduleModalApp(app);
                                      const passedCount = (app.interviews || []).filter(i => i.result === 'PASS').length;
                                      const nextStage = app.internship.interviewStages[passedCount] || 'TECHNICAL';
                                      setInterviewForm(prev => ({ ...prev, stage: nextStage }));
                                    }}
                                    className="w-full py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-semibold text-[10px]"
                                  >
                                    Schedule Next Round
                                  </button>
                                )}

                                {(app.status === 'COMPANY_SHORTLISTED' || app.status === 'INTERVIEW_SCHEDULED') && (
                                  <button
                                    onClick={() => handleSelectCandidate(app.id)}
                                    className="w-full py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[10px]"
                                  >
                                    Mark Selected
                                  </button>
                                )}

                                {app.status === 'SELECTED' && !app.offer && (
                                  <button
                                    onClick={() => {
                                      setOfferModalApp(app);
                                      setOfferStipend(app.internship.stipend);
                                      setOfferLetterText(`We are pleased to offer you the position of ${app.internship.role} at ${app.internship.company.companyName}.`);
                                    }}
                                    className="w-full py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px]"
                                  >
                                    Extend Offer 🎉
                                  </button>
                                )}

                                {!['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(app.status) && (
                                  <button
                                    onClick={() => handleRejectCandidate(app.id)}
                                    className="w-full py-0.5 rounded text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-[10px]"
                                  >
                                    Reject
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Ranked List View */}
          {viewMode === 'RANKED' && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Candidate Composite ATS Ranking
                  </h3>
                  <p className="text-xs text-slate-400">
                    Calculated as: <span className="font-mono text-brand-blue">Composite Score = 0.6 × Resume Match + 0.4 × ATR</span>
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 uppercase font-semibold text-[10px] text-slate-400">
                    <tr>
                      <th className="p-3">Rank</th>
                      <th className="p-3">Candidate</th>
                      <th className="p-3">Branch</th>
                      <th className="p-3">CGPA</th>
                      <th className="p-3">Resume Match</th>
                      <th className="p-3">ATR Score</th>
                      <th className="p-3">Composite Score</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {rankedCandidates.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-slate-400">
                          No applicants recorded for this opening.
                        </td>
                      </tr>
                    ) : (
                      rankedCandidates.map((c, idx) => (
                        <tr key={c.application.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                          <td className="p-3 font-bold text-slate-400">#{idx + 1}</td>
                          <td className="p-3 font-semibold text-slate-900 dark:text-white">
                            {c.application.student.name}
                          </td>
                          <td className="p-3">{c.application.student.department}</td>
                          <td className="p-3 font-bold">{c.application.student.cgpa.toFixed(2)}</td>
                          <td className="p-3 font-semibold text-brand-blue dark:text-brand-cyan">
                            {c.resumeMatchScore}%
                          </td>
                          <td className="p-3 font-semibold">
                            {c.atrScore != null ? `${c.atrScore} / 100` : '—'}
                          </td>
                          <td className="p-3 font-black text-sm text-emerald-600 dark:text-emerald-400">
                            {c.compositeScore}
                          </td>
                          <td className="p-3">
                            <StatusPill status={c.application.status} />
                          </td>
                          <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => handleToggleCompare(c.application.id)}
                              className="px-2.5 py-1 rounded-lg border text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                            >
                              {selectedCompareIds.includes(c.application.id) ? '✓ Selected' : 'Compare'}
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: RANKING OVERVIEW */}
      {/* ======================================================== */}
      {activeTab === 'ranking' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Recruiter Ranking Engine
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Automated multi-factor weighting ensures unbiased, merit-based selection.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/50 space-y-1">
              <span className="text-[10px] uppercase font-bold text-brand-blue tracking-wider">Weight 60%</span>
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">ATS Resume Keyword Match</h4>
              <p className="text-xs text-slate-500">
                Measures literal whole-word matches between candidate resume experience and required job skills.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/50 space-y-1">
              <span className="text-[10px] uppercase font-bold text-brand-indigo tracking-wider">Weight 40%</span>
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">Academic &amp; Technical Rating (ATR)</h4>
              <p className="text-xs text-slate-500">
                Official faculty placement assessment evaluating academic rigor, university projects, and coding evaluations.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-1">
              <span className="text-[10px] uppercase font-bold text-emerald-600 tracking-wider">Automated Gate</span>
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">Eligibility Hard Constraints</h4>
              <p className="text-xs text-slate-500">
                Strict enforcement of zero unverified accounts, CGPA cutoffs, branch limitations, and active backlog rules.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Post / Edit Internship Modal with LIVE PREVIEW */}
      <Modal
        isOpen={showPostModal}
        onClose={() => setShowPostModal(false)}
        title={editingInternship ? 'Edit Criteria & Dynamic Preferences' : 'Post Campus Internship Opening'}
        description="Tune role requirements with instant live simulation of student eligibility."
        maxWidth="3xl"
      >
        <form onSubmit={handleSaveInternship} className="space-y-6 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Internship Role Title
              </label>
              <input
                type="text"
                value={formState.role}
                onChange={e => setFormState({ ...formState, role: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Monthly Stipend (₹)
              </label>
              <input
                type="number"
                min={0}
                value={formState.stipend}
                onChange={e => setFormState({ ...formState, stipend: Number(e.target.value) })}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Work Mode
              </label>
              <select
                value={formState.workMode}
                onChange={e => setFormState({ ...formState, workMode: e.target.value as any })}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              >
                <option value="HYBRID">Hybrid</option>
                <option value="REMOTE">Remote</option>
                <option value="ONSITE">Onsite</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Location
              </label>
              <input
                type="text"
                value={formState.location}
                onChange={e => setFormState({ ...formState, location: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Role Description &amp; Responsibilities
              </label>
              <textarea
                rows={2}
                value={formState.description}
                onChange={e => setFormState({ ...formState, description: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>
          </div>

          {/* DYNAMIC CRITERIA & LIVE PREVIEW PANEL */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
            <div className="flex items-center justify-between">
              <div className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-brand-blue" />
                <span>Dynamic Eligibility Criteria</span>
              </div>

              {/* LIVE SIMULATION BADGE */}
              <div className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-brand-blue dark:bg-blue-950 dark:text-brand-cyan border border-blue-200 dark:border-blue-800">
                Live: {livePreview.matchCount} / {livePreview.totalStudents} Students Match
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Min CGPA Cutoff
                </label>
                <input
                  type="number"
                  step="0.1"
                  min={0}
                  max={10}
                  value={formState.criteria.minCgpa}
                  onChange={e =>
                    setFormState({
                      ...formState,
                      criteria: { ...formState.criteria, minCgpa: Number(e.target.value) }
                    })
                  }
                  className="w-full p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Max Active Backlogs Allowed
                </label>
                <input
                  type="number"
                  min={0}
                  max={10}
                  value={formState.criteria.maxBacklogs}
                  onChange={e =>
                    setFormState({
                      ...formState,
                      criteria: { ...formState.criteria, maxBacklogs: Number(e.target.value) }
                    })
                  }
                  className="w-full p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Min ATR Score (Optional)
                </label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={formState.criteria.minAtrScore || 0}
                  onChange={e =>
                    setFormState({
                      ...formState,
                      criteria: { ...formState.criteria, minAtrScore: Number(e.target.value) }
                    })
                  }
                  className="w-full p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Eligible Branches (comma separated; blank for all)
                </label>
                <input
                  type="text"
                  placeholder="e.g. CSE, IT"
                  value={formState.criteria.eligibleBranches.join(', ')}
                  onChange={e =>
                    setFormState({
                      ...formState,
                      criteria: {
                        ...formState.criteria,
                        eligibleBranches: e.target.value.split(',').map(s => s.trim().toUpperCase()).filter(Boolean)
                      }
                    })
                  }
                  className="w-full p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Required Skills (comma separated)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Java, SQL, Python"
                  value={formState.criteria.requiredSkills.join(', ')}
                  onChange={e =>
                    setFormState({
                      ...formState,
                      criteria: {
                        ...formState.criteria,
                        requiredSkills: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })
                  }
                  className="w-full p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>

            {/* Real-time simulation hints */}
            {livePreview.insights.length > 0 && (
              <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 text-[11px] text-blue-900 dark:text-blue-200 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-brand-blue" />
                  <span>Real-time Candidate Pool Insights:</span>
                </div>
                <ul className="list-disc pl-4 space-y-0.5">
                  {livePreview.insights.map((ins, iIdx) => (
                    <li key={iIdx}>{ins}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowPostModal(false)}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 rounded-xl font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-md"
            >
              {editingInternship ? 'Save & Re-evaluate Students' : 'Submit Internship'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Candidate Side-by-Side Compare Modal */}
      <Modal
        isOpen={showCompareModal}
        onClose={() => setShowCompareModal(false)}
        title="Candidate Side-by-Side Comparison"
        description="Compare candidate skills, CGPA, ATR assessment, and resume match scores."
        maxWidth="4xl"
      >
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {selectedCompareIds.map(appId => {
              const app = applications.find(a => a.id === appId);
              if (!app) return null;
              return (
                <div
                  key={app.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-3"
                >
                  <div className="border-b border-slate-200 dark:border-slate-700 pb-2">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      {app.student.name}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {app.student.department} · PRN: {app.student.prn}
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cumulative CGPA:</span>
                      <span className="font-bold">{app.student.cgpa.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Backlogs:</span>
                      <span className="font-bold">{app.student.backlogs}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Resume Match:</span>
                      <span className="font-bold text-brand-blue">{app.resumeMatchScore}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">ATR Score:</span>
                      <span className="font-bold text-emerald-600">{app.assessment?.atrScore || '—'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status:</span>
                      <StatusPill status={app.status} />
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Skills:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {app.student.skills.map(s => (
                        <span key={s.name} className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 text-[10px]">
                          {s.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end pt-3">
            <button
              onClick={() => {
                setSelectedCompareIds([]);
                setShowCompareModal(false);
              }}
              className="px-4 py-2 rounded-xl text-slate-600 bg-slate-100 dark:bg-slate-800 font-semibold"
            >
              Clear Comparison
            </button>
          </div>
        </div>
      </Modal>

      {/* Schedule Interview Modal */}
      <Modal
        isOpen={!!scheduleModalApp}
        onClose={() => setScheduleModalApp(null)}
        title="Schedule Interview Round"
        description={`Set up next evaluation stage for ${scheduleModalApp?.student.name} (${scheduleModalApp?.internship.role}).`}
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1">Interview Stage</label>
            <select
              value={interviewForm.stage}
              onChange={e => setInterviewForm({ ...interviewForm, stage: e.target.value as any })}
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            >
              <option value="APTITUDE_TEST">Aptitude Test</option>
              <option value="CODING_TEST">Coding Assessment</option>
              <option value="TECHNICAL">Technical Round</option>
              <option value="HR">HR &amp; Cultural Fit</option>
              <option value="GROUP_DISCUSSION">Group Discussion</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1">Date &amp; Time</label>
            <input
              type="datetime-local"
              value={interviewForm.scheduledDate}
              onChange={e => setInterviewForm({ ...interviewForm, scheduledDate: e.target.value })}
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1">Mode</label>
            <select
              value={interviewForm.mode}
              onChange={e => setInterviewForm({ ...interviewForm, mode: e.target.value as any })}
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            >
              <option value="ONLINE">Online (Video Call)</option>
              <option value="OFFLINE">Offline (Campus Placement Center)</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setScheduleModalApp(null)} className="px-4 py-2 text-slate-600">
              Cancel
            </button>
            <button
              onClick={handleScheduleSubmit}
              className="px-5 py-2 rounded-xl bg-amber-500 font-bold text-slate-950"
            >
              Confirm Schedule
            </button>
          </div>
        </div>
      </Modal>

      {/* Record Pass / Fail Modal */}
      <Modal
        isOpen={!!resultModalItem}
        onClose={() => setResultModalItem(null)}
        title="Record Interview Result"
        description="Record performance verdict. A Fail verdict automatically rejects the applicant."
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1">Result</label>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setInterviewResultChoice('PASS')}
                className={`flex-1 py-2 rounded-xl font-bold border transition-colors ${
                  interviewResultChoice === 'PASS'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                }`}
              >
                Pass Round
              </button>
              <button
                type="button"
                onClick={() => setInterviewResultChoice('FAIL')}
                className={`flex-1 py-2 rounded-xl font-bold border transition-colors ${
                  interviewResultChoice === 'FAIL'
                    ? 'bg-rose-600 text-white border-rose-600'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                }`}
              >
                Fail Round
              </button>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">Interviewer Remarks</label>
            <textarea
              rows={3}
              value={interviewResultRemarks}
              onChange={e => setInterviewResultRemarks(e.target.value)}
              placeholder="e.g. Strong data structures grounding; recommended for next stage."
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setResultModalItem(null)} className="px-4 py-2 text-slate-600">
              Cancel
            </button>
            <button
              onClick={handleRecordResultSubmit}
              className="px-5 py-2 rounded-xl bg-brand-blue text-white font-semibold"
            >
              Save Result
            </button>
          </div>
        </div>
      </Modal>

      {/* Extend Offer Modal */}
      <Modal
        isOpen={!!offerModalApp}
        onClose={() => setOfferModalApp(null)}
        title="Extend Official Internship Offer"
        description={`Send formal offer letter to ${offerModalApp?.student.name}.`}
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">Monthly Stipend (₹)</label>
              <input
                type="number"
                value={offerStipend}
                onChange={e => setOfferStipend(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Response Validity Deadline</label>
              <input
                type="date"
                value={offerValidUntil}
                onChange={e => setOfferValidUntil(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">Offer Letter Text</label>
            <textarea
              rows={4}
              value={offerLetterText}
              onChange={e => setOfferLetterText(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setOfferModalApp(null)} className="px-4 py-2 text-slate-600">
              Cancel
            </button>
            <button
              onClick={handleExtendOfferSubmit}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
            >
              Send Offer 🎉
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

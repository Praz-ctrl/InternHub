import React, { useState } from 'react';
import {
  GraduationCap,
  ShieldCheck,
  Building2,
  Users2,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  Sun,
  Moon,
  Info,
  Layers
} from 'lucide-react';
import { Role, User } from '@/types';
import { api } from '@/services/api';
import { useToast } from '@/components/Toast';
import { Modal } from '@/components/common/Modal';
import { useAuth } from '@/core/auth/useAuth';
import { ArchitectureInspectorModal } from '@/components/common/ArchitectureInspectorModal';

interface LoginPageProps {
  onLoginSuccess: (user: User) => void;
  isDark: boolean;
  onToggleDark: () => void;
  onResetData: () => void;
}

interface DemoPersona {
  role: Role;
  name: string;
  email: string;
  password: string;
  departmentOrCompany: string;
  icon: any;
  color: string;
  badgeBg: string;
  desc: string;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  isDark,
  onToggleDark,
  onResetData
}) => {
  const { success, error, info } = useToast();
  const { login } = useAuth();
  const [email, setEmail] = useState('student@demo.com');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [showLayersModal, setShowLayersModal] = useState(false);

  const demoPersonas: DemoPersona[] = [
    {
      role: 'STUDENT',
      name: 'Demo Student',
      email: 'student@demo.com',
      password: 'password123',
      departmentOrCompany: 'B.Tech CSE · Sem 6',
      icon: GraduationCap,
      color: 'text-blue-500',
      badgeBg: 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300',
      desc: 'Verified student profile with CGPA 8.2, 0 backlogs, skills & applications'
    },
    {
      role: 'FACULTY',
      name: 'Dr. Anand Mehta',
      email: 'faculty@demo.com',
      password: 'password123',
      departmentOrCompany: 'Placement Cell & CSE Dept',
      icon: ShieldCheck,
      color: 'text-indigo-500',
      badgeBg: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300',
      desc: 'Verify marks & documents, approve company postings, enter ATR ratings'
    },
    {
      role: 'COMPANY',
      name: 'NexaTech HR Team',
      email: 'company@demo.com',
      password: 'password123',
      departmentOrCompany: 'Enterprise Recruiter',
      icon: Building2,
      color: 'text-amber-500',
      badgeBg: 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300',
      desc: 'Post roles with dynamic criteria, rank applicants, conduct interview pipeline'
    },
    {
      role: 'ADMIN',
      name: 'Dean / Administrator',
      email: 'admin@demo.com',
      password: 'password123',
      departmentOrCompany: 'System Administration',
      icon: Users2,
      color: 'text-rose-500',
      badgeBg: 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300',
      desc: 'Campus user governance, account activation, system-wide security audit logs'
    }
  ];

  const handleLogin = async (e?: React.FormEvent, customEmail?: string, customPass?: string) => {
    if (e) e.preventDefault();
    const targetEmail = customEmail || email;
    const targetPass = customPass || password;

    if (!targetEmail.trim() || !targetPass.trim()) {
      setLoginError('Please enter both your institutional email and password.');
      return;
    }

    setLoginError(null);
    setLoading(true);

    try {
      const user = await login(targetEmail, targetPass);
      success(`Welcome back, ${user.name}!`, `Logged into the ${user.role} portal.`);
      onLoginSuccess(user);
    } catch (err: any) {
      setLoginError(err.message || 'Authentication failed. Please verify credentials.');
      error('Login failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = (persona: DemoPersona) => {
    setEmail(persona.email);
    setPassword(persona.password);
    handleLogin(undefined, persona.email, persona.password);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between selection:bg-brand-blue selection:text-white transition-colors">
      {/* Top Bar */}
      <header className="border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-navy-800 via-brand-blue to-brand-cyan flex items-center justify-center text-white shadow-md shadow-brand-blue/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-navy-800 to-brand-blue dark:from-white dark:to-brand-cyan bg-clip-text text-transparent">
                InternHub
              </span>
              <span className="hidden sm:inline-block ml-2 px-2 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wider bg-blue-100 text-brand-blue dark:bg-blue-950/60 dark:text-blue-300">
                Institutional Gateway
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLayersModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden sm:inline">7-Layer Architecture</span>
              <span className="sm:hidden">7 Layers</span>
            </button>

            <button
              onClick={() => setShowInfoModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Info className="w-3.5 h-3.5 text-brand-blue" />
              <span>About Security &amp; RBAC</span>
            </button>

            <button
              onClick={() => setShowResetModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
              title="Reset all demo data"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset Demo</span>
            </button>

            <button
              onClick={onToggleDark}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle dark mode"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Hero & Authentication Form Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Campus Information & Security Features */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Campus Placement Management &amp; Eligibility Portal</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
              One Secure Portal.{' '}
              <span className="bg-gradient-to-r from-brand-blue to-brand-cyan bg-clip-text text-transparent">
                Four Isolated Roles.
              </span>
            </h1>

            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              InternHub automates student academic verification, dynamic criteria eligibility checking, and enterprise interview workflows with strict role-based isolation between Students, Faculty, Companies, and Administrators.
            </p>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
                <div className="flex items-center gap-2 text-brand-blue font-bold text-xs">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Strict Role Isolation (RBAC)</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  Private portals prevent students, faculty, and recruiters from ever seeing another user&apos;s records or other companies&apos; applicant pools.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
                <div className="flex items-center gap-2 text-brand-cyan font-bold text-xs">
                  <Sparkles className="w-4 h-4" />
                  <span>Automated Eligibility Engine</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  Instantly re-evaluates student eligibility against dynamic CGPA, backlog, department, semester, and skill constraints.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
                <div className="flex items-center gap-2 text-amber-500 font-bold text-xs">
                  <Building2 className="w-4 h-4" />
                  <span>Isolated Corporate Pipelines</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  Each enterprise manages its own custom interview rounds, applicant scoring, and official offers without corporate data leakage.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
                <div className="flex items-center gap-2 text-rose-500 font-bold text-xs">
                  <Lock className="w-4 h-4" />
                  <span>Tamper-Resistant Security</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  Cryptographically signed session tokens with real-time audit logging for administrative actions and blocked attempts.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Secure Login Box */}
          <div className="lg:col-span-5">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-brand-blue">
                    Campus Authentication
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-500" />
                    256-bit Session
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  Sign In to InternHub
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Select a demo account or sign in with university credentials.
                </p>
              </div>

              {loginError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
                  <div className="leading-snug">{loginError}</div>
                </div>
              )}

              {/* Login Form */}
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Institutional Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                      placeholder="e.g. student@demo.com"
                      className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue/30 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Password
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Demo: <code className="text-brand-blue font-mono font-bold">password123</code>
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                      placeholder="••••••••••••"
                      className="w-full pl-10 pr-10 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue/30 text-slate-900 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(prev => !prev)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      aria-label="Toggle password visibility"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold bg-brand-blue hover:bg-blue-600 text-white shadow-md shadow-brand-blue/30 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Sign In to Private Dashboard</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* One-Click Quick Demo Accounts (Evaluator & Demo convenience) */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Instant Demo Login (1-Click)
                  </span>
                  <span className="text-[10px] text-slate-400">Click to switch role</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {demoPersonas.map(persona => {
                    const Icon = persona.icon;
                    return (
                      <button
                        key={persona.role}
                        type="button"
                        onClick={() => handleQuickDemoLogin(persona)}
                        className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-brand-blue/40 dark:hover:border-brand-blue/40 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition-all group"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${persona.badgeBg}`}>
                            {persona.role}
                          </span>
                          <Icon className={`w-3.5 h-3.5 ${persona.color} group-hover:scale-110 transition-transform`} />
                        </div>
                        <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {persona.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {persona.email}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800 py-6 text-center text-xs text-slate-400 bg-white/40 dark:bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>InternHub — Campus Internship Management &amp; Automated Eligibility Portal</span>
          <span>Strict Role-Based Access Control (RBAC) · 256-bit Session Security</span>
        </div>
      </footer>

      {/* Security & RBAC Information Modal */}
      <Modal
        isOpen={showInfoModal}
        onClose={() => setShowInfoModal(false)}
        title="Role-Based Security & Architecture"
        description="Comprehensive separation of duties and private dashboards in InternHub"
        maxWidth="lg"
      >
        <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
          <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60">
            <h4 className="font-bold text-brand-blue dark:text-blue-300 mb-1">
              Zero-Trust Role-Based Separation
            </h4>
            <p>
              Users authenticate first before any private academic, recruitment, or administrative records are loaded. Direct navigation to unauthorized routes is denied at the API service layer.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-0.5">
                🎓 Student Portal
              </span>
              Students access only their own academic records, marks, resume analysis, and applications. Attempting to pass another student&apos;s ID throws an immediate 403 Forbidden.
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-0.5">
                🛡️ Faculty Placement Cell
              </span>
              Authorized to verify marks, inspect uploaded transcripts, approve company internship postings, and enter ATR assessment ratings.
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-0.5">
                🏢 Company Portal Isolation
              </span>
              Each company account is completely isolated. Recruiters only see candidates who applied to their own postings and cannot access other companies&apos; listings or applicants.
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-0.5">
                🏛️ Admin &amp; Security Auditing
              </span>
              Only authenticated administrators can manage user activation, examine institutional analytics, and inspect security audit logs.
            </div>
          </div>
        </div>
      </Modal>

      {/* Reset Data Modal */}
      <Modal
        isOpen={showResetModal}
        onClose={() => setShowResetModal(false)}
        title="Reset Demo Data?"
        description="Restore all campus data to initial canonical demo state"
        maxWidth="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-400">
            This will wipe any edited criteria, newly posted roles, and altered student marks, restoring clean demonstration records.
          </p>
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              onClick={() => setShowResetModal(false)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onResetData();
                setShowResetModal(false);
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-sm"
            >
              Confirm Reset
            </button>
          </div>
        </div>
      </Modal>

      {/* Layered Architecture Inspector */}
      <ArchitectureInspectorModal
        isOpen={showLayersModal}
        onClose={() => setShowLayersModal(false)}
      />
    </div>
  );
};
export default LoginPage;

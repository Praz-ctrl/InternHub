import React, { useState, useEffect, useMemo } from 'react';
import {
  User,
  Student,
  AcademicRecord,
  StudentDocument,
  StudentResume,
  Internship,
  InternshipApplication,
  Offer,
  EligibilityResult,
  WorkMode
} from '@/types';
import { api } from '@/services/api';
import { useToast } from '@/components/Toast';
import { StatusPill } from '@/components/common/StatusPill';
import { Modal } from '@/components/common/Modal';
import { Drawer } from '@/components/common/Drawer';
import {
  GraduationCap,
  FileText,
  Briefcase,
  Award,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Plus,
  Trash2,
  ExternalLink,
  Search,
  Bookmark,
  Calendar,
  Clock,
  Building,
  Sparkles,
  HelpCircle,
  FileCheck,
  ChevronDown,
  ChevronUp,
  MapPin,
  IndianRupee,
  ShieldCheck,
  XCircle,
  ArrowRight,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface StudentDashboardProps {
  currentUser: User;
  initialTab?: string;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ currentUser, initialTab = 'browse' }) => {
  const { success, error, info } = useToast();
  const [activeTab, setActiveTab] = useState<string>(initialTab);

  const [student, setStudent] = useState<Student | null>(null);
  const [academicRecords, setAcademicRecords] = useState<AcademicRecord[]>([]);
  const [resume, setResume] = useState<StudentResume | null>(null);
  const [documents, setDocuments] = useState<StudentDocument[]>([]);
  const [internshipViews, setInternshipViews] = useState<{ internship: Internship; result: EligibilityResult; applied: boolean }[]>([]);
  const [applications, setApplications] = useState<InternshipApplication[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters for Internships
  const [searchQuery, setSearchQuery] = useState('');
  const [workModeFilter, setWorkModeFilter] = useState<string>('ALL');
  const [eligibleOnly, setEligibleOnly] = useState(false);
  const [bookmarkedOnly, setBookmarkedOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'deadline' | 'stipend' | 'role'>('deadline');

  // Modals & Drawers state
  const [expandedReasonsId, setExpandedReasonsId] = useState<string | null>(null);
  const [showAddRecordModal, setShowAddRecordModal] = useState(false);
  const [showUploadDocModal, setShowUploadDocModal] = useState(false);
  const [showWithdrawConfirm, setShowWithdrawConfirm] = useState<string | null>(null);
  const [previewDoc, setPreviewDoc] = useState<StudentDocument | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);

  // Form states
  const [newRecord, setNewRecord] = useState({ semester: 6, subject: '', marks: 80, sgpa: 8.0 });
  const [newDocType, setNewDocType] = useState<'MARKSHEET' | 'RESUME' | 'ID_CARD' | 'CERTIFICATE'>('MARKSHEET');
  const [newDocFile, setNewDocFile] = useState<File | null>(null);
  const [resumeTextInput, setResumeTextInput] = useState('');
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillLevel, setNewSkillLevel] = useState<'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED'>('INTERMEDIATE');

  // Load all student data
  const loadData = async () => {
    try {
      setLoading(true);
      const studentProfile = await api.getStudentProfile(currentUser.profileId);
      setStudent(studentProfile);

      const [records, res, docs, views, apps, myOffers] = await Promise.all([
        api.getAcademicRecords(studentProfile.id),
        api.getStudentResume(studentProfile.id),
        api.getStudentDocuments(studentProfile.id),
        api.getInternshipsWithEligibilityForStudent(studentProfile.id),
        api.getMyApplications(studentProfile.id),
        api.getStudentOffers(studentProfile.id)
      ]);

      setAcademicRecords(records);
      setResume(res);
      if (res) {
        setResumeTextInput(res.rawText);
        setAiSuggestions(res.aiFeedback || []);
      }
      setDocuments(docs);
      setInternshipViews(views);
      setApplications(apps);
      setOffers(myOffers);
    } catch (err: any) {
      error('Failed to load dashboard', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser.profileId]);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
  }, [initialTab]);

  // Profile completeness calculation
  const completenessScore = useMemo(() => {
    if (!student) return 0;
    let score = 0;
    if (student.name && student.department && student.prn) score += 20;
    if (academicRecords.length > 0) score += 25;
    if (resume && resume.rawText) score += 25;
    if (documents.length > 0) score += 15;
    if (student.verified) score += 15;
    return score;
  }, [student, academicRecords, resume, documents]);

  // What's blocking me checklist
  const blockingItems = useMemo(() => {
    if (!student) return [];
    const items = [];

    items.push({
      id: 'verification',
      title: 'Faculty Academic Verification',
      done: student.verified,
      message: student.verified
        ? `Verified by ${student.verifiedBy || 'Faculty Cell'}`
        : 'Pending review by Faculty Placement Cell. Upload documents to expedite.',
      actionText: student.verified ? undefined : 'View Documents',
      onAction: () => setActiveTab('documents')
    });

    items.push({
      id: 'resume',
      title: 'Resume & Skills Profile',
      done: !!resume && (resume.extractedSkills?.length || 0) > 0,
      message: resume
        ? `Resume parsed: ${resume.extractedSkills.length} skills identified (${resume.resumeScore}% completeness)`
        : 'No resume parsed yet. Required for automated ATS match scoring.',
      actionText: resume ? undefined : 'Upload Resume',
      onAction: () => setActiveTab('resume')
    });

    items.push({
      id: 'marksheets',
      title: 'Semester Marksheets & SGPA',
      done: academicRecords.length > 0,
      message: academicRecords.length > 0
        ? `${academicRecords.length} semester records recorded (Cumulative CGPA: ${student.cgpa})`
        : 'Enter semester SGPA to compute verifiable CGPA.',
      actionText: academicRecords.length > 0 ? undefined : 'Add Records',
      onAction: () => setActiveTab('academics')
    });

    items.push({
      id: 'backlogs',
      title: 'Zero Active Backlogs',
      done: student.backlogs === 0,
      message: student.backlogs === 0
        ? 'Clear academic record (0 backlogs)'
        : `${student.backlogs} active backlogs may restrict eligibility for tier-1 companies.`,
      actionText: undefined
    });

    return items;
  }, [student, resume, academicRecords]);

  // Filtered internships
  const filteredInternships = useMemo(() => {
    return internshipViews
      .filter(({ internship, result, applied }) => {
        // Search
        const q = searchQuery.toLowerCase();
        const matchesQuery =
          !q ||
          internship.role.toLowerCase().includes(q) ||
          internship.company.companyName.toLowerCase().includes(q) ||
          internship.location.toLowerCase().includes(q) ||
          (internship.criteria.requiredSkills || []).some(s => s.toLowerCase().includes(q));

        if (!matchesQuery) return false;

        // WorkMode
        if (workModeFilter !== 'ALL' && internship.workMode !== workModeFilter) return false;

        // Eligible Only
        if (eligibleOnly && !result.eligible) return false;

        // Bookmarked Only
        if (bookmarkedOnly && !(student?.bookmarkedInternshipIds || []).includes(internship.id)) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'deadline') return new Date(a.internship.deadline).getTime() - new Date(b.internship.deadline).getTime();
        if (sortBy === 'stipend') return b.internship.stipend - a.internship.stipend;
        return a.internship.role.localeCompare(b.internship.role);
      });
  }, [internshipViews, searchQuery, workModeFilter, eligibleOnly, bookmarkedOnly, sortBy, student]);

  // Actions
  const handleApply = async (internshipId: string) => {
    if (!student) return;
    try {
      await api.applyForInternship(student.id, internshipId);
      success('Application submitted successfully!', 'Company and placement cell notified.');
      loadData();
    } catch (err: any) {
      error('Cannot apply', err.message);
    }
  };

  const handleWithdraw = async (applicationId: string) => {
    if (!student) return;
    try {
      await api.withdrawApplication(applicationId, student.id);
      success('Application withdrawn.');
      setShowWithdrawConfirm(null);
      loadData();
    } catch (err: any) {
      error('Failed to withdraw', err.message);
    }
  };

  const handleBookmarkToggle = async (internshipId: string) => {
    if (!student) return;
    try {
      const updated = await api.toggleBookmark(student.id, internshipId);
      setStudent(prev => prev ? { ...prev, bookmarkedInternshipIds: updated } : null);
    } catch (err: any) {
      error('Bookmark error', err.message);
    }
  };

  const handleAddRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!student) return;
    try {
      await api.addAcademicRecord(student.id, newRecord);
      success('Academic record added!', 'Note: CGPA recomputed; faculty verification reset.');
      setShowAddRecordModal(false);
      setNewRecord({ semester: 6, subject: '', marks: 80, sgpa: 8.0 });
      loadData();
    } catch (err: any) {
      error('Failed to add record', err.message);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    if (!student) return;
    try {
      await api.deleteAcademicRecord(id, student.id);
      success('Record removed.');
      loadData();
    } catch (err: any) {
      error('Failed to delete', err.message);
    }
  };

  const handleSaveResume = async () => {
    if (!student || !resumeTextInput.trim()) return;
    try {
      const saved = await api.saveStudentResume(student.id, resumeTextInput);
      setResume(saved);
      success('Resume parsed and saved!', `${saved.extractedSkills.length} skills identified.`);
      loadData();
    } catch (err: any) {
      error('Failed to save resume', err.message);
    }
  };

  const handleAiResumeSuggestions = async () => {
    if (!resumeTextInput.trim()) {
      error('Please enter resume text first');
      return;
    }
    try {
      setIsAiLoading(true);
      const suggestions = await api.getAiResumeFeedback(resumeTextInput);
      setAiSuggestions(suggestions);
      success('AI suggestions generated!');
    } catch (err: any) {
      error('AI generation failed', err.message);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleAddSkill = async () => {
    if (!student || !newSkillName.trim()) return;
    const exists = student.skills.some(s => s.name.toUpperCase() === newSkillName.trim().toUpperCase());
    if (exists) {
      info('Skill already exists in your profile');
      return;
    }
    const updatedSkills = [...student.skills, { name: newSkillName.trim(), proficiency: newSkillLevel }];
    try {
      const updated = await api.updateStudentSkills(student.id, updatedSkills);
      setStudent(updated);
      setNewSkillName('');
      success('Skill added to profile');
      loadData();
    } catch (err: any) {
      error('Failed to add skill', err.message);
    }
  };

  const handleRemoveSkill = async (skillName: string) => {
    if (!student) return;
    const updatedSkills = student.skills.filter(s => s.name !== skillName);
    try {
      const updated = await api.updateStudentSkills(student.id, updatedSkills);
      setStudent(updated);
      success('Skill removed');
      loadData();
    } catch (err: any) {
      error('Failed to remove skill', err.message);
    }
  };

  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!student) return;
    const fileName = newDocFile ? newDocFile.name : `${newDocType.toLowerCase()}_sample.pdf`;
    try {
      await api.uploadStudentDocument(student.id, {
        documentType: newDocType,
        fileName,
        fileSize: newDocFile ? `${(newDocFile.size / 1024).toFixed(0)} KB` : '1.1 MB',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
      });
      success('Document uploaded for faculty verification');
      setShowUploadDocModal(false);
      setNewDocFile(null);
      loadData();
    } catch (err: any) {
      error('Upload failed', err.message);
    }
  };

  const handleRespondOffer = async (offerId: string, status: 'ACCEPTED' | 'DECLINED') => {
    try {
      await api.respondToOffer(offerId, status);
      if (status === 'ACCEPTED') {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
        success('Offer Accepted!', 'Congratulations on your campus placement!');
      } else {
        info('Offer declined');
      }
      loadData();
    } catch (err: any) {
      error('Action failed', err.message);
    }
  };

  if (loading || !student) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="animate-pulse space-y-6">
          <div className="h-28 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
          <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'browse', label: 'Internships', icon: Briefcase, count: internshipViews.length },
    { id: 'profile', label: 'Profile', icon: GraduationCap },
    { id: 'academics', label: 'Marksheets', icon: Award, count: academicRecords.length },
    { id: 'resume', label: 'Skills & Resume', icon: FileText },
    { id: 'documents', label: 'Documents', icon: FileCheck, count: documents.length },
    { id: 'applications', label: 'Applications', icon: Clock, count: applications.length },
    { id: 'offers', label: 'Offers', icon: CheckCircle2, count: offers.length }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Student Hero Header with Profile Completeness Ring */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-navy-900 via-navy-800 to-brand-blue p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                {student.name}
              </h1>
              {student.verified ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  <ShieldCheck className="w-4 h-4" />
                  VERIFIED BY FACULTY
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  <AlertTriangle className="w-4 h-4" />
                  VERIFICATION PENDING
                </span>
              )}
            </div>

            <p className="text-slate-300 text-sm max-w-2xl">
              PRN: <span className="font-mono text-white">{student.prn}</span> · Department: <span className="font-semibold text-white">{student.department}</span> · Semester {student.semester} · CGPA: <span className="font-bold text-white">{student.cgpa.toFixed(2)}</span> · Backlogs: <span className="font-bold text-white">{student.backlogs}</span>
            </p>
          </div>

          {/* Completeness Ring */}
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md px-5 py-3.5 rounded-2xl border border-white/15">
            <div className="relative w-14 h-14 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-white/20"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-brand-cyan transition-all duration-1000 ease-out"
                  strokeDasharray={`${completenessScore}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute font-bold text-xs">{completenessScore}%</span>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-300 font-semibold">
                Profile Health
              </div>
              <div className="text-sm font-bold text-white">
                {completenessScore === 100 ? 'Fully Verified & Ready' : 'Steps Incomplete'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* "What's Blocking Me" Checklist (When not 100%) */}
      {completenessScore < 100 && (
        <div className="rounded-2xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>What's Blocking My Eligibility &amp; Applications?</span>
            </div>
            <span className="text-xs text-amber-700 dark:text-amber-400">
              Complete these steps to unlock all internships
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {blockingItems.map(item => (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border flex flex-col justify-between text-xs transition-colors ${
                  item.done
                    ? 'bg-white/80 dark:bg-slate-900/80 border-emerald-200 dark:border-emerald-900/50 text-slate-700 dark:text-slate-300'
                    : 'bg-white dark:bg-slate-900 border-amber-300 dark:border-amber-700 text-slate-800 dark:text-slate-200 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 font-semibold mb-1">
                    {item.done ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-amber-500 shrink-0" />
                    )}
                    <span>{item.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {item.message}
                  </p>
                </div>

                {item.actionText && (
                  <button
                    onClick={item.onAction}
                    className="mt-3 text-left font-semibold text-brand-blue dark:text-brand-cyan hover:underline flex items-center gap-1"
                  >
                    {item.actionText} →
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {tabs.map(({ id, label, icon: Icon, count }) => {
          const isActive = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-brand-blue text-white shadow-md shadow-brand-blue/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
              {count !== undefined && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-xs ${
                    isActive ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ======================================================== */}
      {/* TAB 1: INTERNSHIPS BROWSE & ELIGIBILITY */}
      {/* ======================================================== */}
      {activeTab === 'browse' && (
        <div className="space-y-6">
          {/* Search & Filter Bar */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-stretch md:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search by role, company, skill (e.g. Java, Python), or location..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue/20"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* WorkMode filter */}
              <select
                value={workModeFilter}
                onChange={e => setWorkModeFilter(e.target.value)}
                className="text-xs font-medium py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
              >
                <option value="ALL">All Modes</option>
                <option value="REMOTE">Remote</option>
                <option value="HYBRID">Hybrid</option>
                <option value="ONSITE">Onsite</option>
              </select>

              {/* Sort By */}
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="text-xs font-medium py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
              >
                <option value="deadline">Sort: Deadline</option>
                <option value="stipend">Sort: Stipend (High to Low)</option>
                <option value="role">Sort: Role Name</option>
              </select>

              {/* Eligible Only Filter Button */}
              <button
                onClick={() => setEligibleOnly(prev => !prev)}
                className={`text-xs font-semibold px-3 py-2 rounded-xl border transition-colors ${
                  eligibleOnly
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                {eligibleOnly ? '✓ Eligible Only' : 'Filter Eligible'}
              </button>

              {/* Bookmarked Only */}
              <button
                onClick={() => setBookmarkedOnly(prev => !prev)}
                className={`p-2 rounded-xl border transition-colors ${
                  bookmarkedOnly
                    ? 'bg-brand-blue text-white border-brand-blue'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                }`}
                title="Show saved internships"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredInternships.length === 0 ? (
              <div className="col-span-2 p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                <Briefcase className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 text-base">
                  No matching internships found
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Try clearing your filters or search keywords.
                </p>
              </div>
            ) : (
              filteredInternships.map(({ internship, result, applied }) => {
                const isBookmarked = (student.bookmarkedInternshipIds || []).includes(internship.id);
                const isExpanded = expandedReasonsId === internship.id;

                return (
                  <div
                    key={internship.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
                  >
                    <div className="space-y-4">
                      {/* Card Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <img
                            src={internship.company.logo}
                            alt={internship.company.companyName}
                            className="w-11 h-11 rounded-xl object-cover border border-slate-100 dark:border-slate-800 shrink-0"
                          />
                          <div>
                            <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                              {internship.role}
                            </h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                              {internship.company.companyName} · {internship.company.industry}
                            </p>
                          </div>
                        </div>

                        {/* Bookmark button */}
                        <button
                          onClick={() => handleBookmarkToggle(internship.id)}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            isBookmarked
                              ? 'bg-blue-50 text-brand-blue border-blue-200 dark:bg-blue-950/40 dark:border-blue-800'
                              : 'text-slate-400 hover:text-slate-600 border-transparent'
                          }`}
                          title={isBookmarked ? 'Remove bookmark' : 'Save internship'}
                        >
                          <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                        </button>
                      </div>

                      {/* Badges Bar (Location, Workmode, Stipend, Eligibility) */}
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                        {result.eligible ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            ELIGIBLE
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                            <XCircle className="w-3.5 h-3.5" />
                            NOT ELIGIBLE
                          </span>
                        )}

                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                          <IndianRupee className="w-3 h-3" />
                          ₹{internship.stipend.toLocaleString()}/mo
                        </span>

                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                          <MapPin className="w-3 h-3" />
                          {internship.location} ({internship.workMode})
                        </span>

                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
                          <Calendar className="w-3 h-3" />
                          Deadline: {internship.deadline}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                        {internship.description}
                      </p>

                      {/* Criteria snapshot */}
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                        <div className="font-medium text-slate-700 dark:text-slate-300">
                          Criteria: Min CGPA {internship.criteria.minCgpa} · Max {internship.criteria.maxBacklogs} backlogs · Branches: {internship.criteria.eligibleBranches?.length ? internship.criteria.eligibleBranches.join(', ') : 'Any'}
                        </div>
                        {internship.criteria.requiredSkills?.length > 0 && (
                          <div className="flex items-center gap-1.5 flex-wrap pt-1">
                            <span className="text-[11px] text-slate-400">Skills:</span>
                            {internship.criteria.requiredSkills.map(sk => (
                              <span
                                key={sk}
                                className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-[10px] font-mono text-slate-700 dark:text-slate-300"
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* NOT ELIGIBLE Expander Accordion */}
                      {!result.eligible && (
                        <div className="border border-rose-200 dark:border-rose-900/50 rounded-xl bg-rose-50/40 dark:bg-rose-950/20 overflow-hidden text-xs">
                          <button
                            onClick={() => setExpandedReasonsId(isExpanded ? null : internship.id)}
                            className="w-full p-2.5 text-left font-semibold text-rose-700 dark:text-rose-300 flex items-center justify-between hover:bg-rose-100/40"
                          >
                            <span className="flex items-center gap-1.5">
                              <HelpCircle className="w-3.5 h-3.5" />
                              Why am I not eligible? ({result.reasons.length} reasons)
                            </span>
                            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>

                          {isExpanded && (
                            <div className="p-3 pt-0 space-y-2 border-t border-rose-100 dark:border-rose-900/40">
                              {result.reasons.map((reason, rIdx) => (
                                <div key={rIdx} className="space-y-0.5">
                                  <div className="text-rose-800 dark:text-rose-300 font-medium flex items-start gap-1.5">
                                    <span className="text-rose-500 font-bold">•</span>
                                    <span>{reason}</span>
                                  </div>
                                  {result.fixHints[rIdx] && (
                                    <div className="text-[11px] text-slate-600 dark:text-slate-400 pl-3 italic">
                                      How to fix: {result.fixHints[rIdx]}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Bar */}
                    <div className="pt-4 border-t border-slate-100 dark:border-slate-800 mt-4 flex items-center justify-between gap-3">
                      <span className="text-xs text-slate-400">
                        {internship.vacancies} open position{internship.vacancies > 1 ? 's' : ''}
                      </span>

                      {applied ? (
                        <span className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 cursor-default">
                          ✓ Applied
                        </span>
                      ) : (
                        <div className="relative group">
                          <button
                            onClick={() => handleApply(internship.id)}
                            disabled={!result.eligible}
                            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                              result.eligible
                                ? 'bg-brand-blue hover:bg-blue-600 text-white shadow-md shadow-brand-blue/20'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            Apply Now
                          </button>
                          {!result.eligible && (
                            <div className="absolute right-0 bottom-full mb-2 hidden group-hover:block w-48 p-2 rounded-lg bg-slate-900 text-white text-[11px] shadow-lg z-20 pointer-events-none">
                              You do not satisfy all criteria for this role.
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: PROFILE INFORMATION */}
      {/* ======================================================== */}
      {activeTab === 'profile' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4 flex items-start justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Personal &amp; Academic Profile
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your details once; the automated eligibility engine reuses this data across every campus opening.
              </p>
            </div>
            {student.verified ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                <ShieldCheck className="w-4 h-4" />
                VERIFIED
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                <AlertTriangle className="w-4 h-4" />
                VERIFICATION PENDING
              </span>
            )}
          </div>

          <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex items-start gap-3 text-xs text-blue-900 dark:text-blue-200">
            <Info className="w-4 h-4 text-brand-blue shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Faculty Verification Policy: </span>
              Modifying critical academic fields (CGPA, Backlogs, Department, or Semester) automatically resets your profile verification so the placement officer can re-verify your university credentials.
            </div>
          </div>

          <form
            onSubmit={async e => {
              e.preventDefault();
              try {
                await api.updateStudentProfile(student.id, {
                  name: student.name,
                  department: student.department,
                  semester: Number(student.semester),
                  cgpa: Number(student.cgpa),
                  backlogs: Number(student.backlogs),
                  phone: student.phone,
                  internshipPreferences: student.internshipPreferences,
                  projects: student.projects,
                  certifications: student.certifications
                });
                success('Profile saved successfully.');
                loadData();
              } catch (err: any) {
                error('Failed to save profile', err.message);
              }
            }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-5"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={student.name}
                onChange={e => setStudent({ ...student, name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Permanent Registration Number (PRN)
              </label>
              <input
                type="text"
                value={student.prn}
                onChange={e => setStudent({ ...student, prn: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Department / Branch
              </label>
              <select
                value={student.department}
                onChange={e => setStudent({ ...student, department: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              >
                <option value="CSE">Computer Science &amp; Engineering (CSE)</option>
                <option value="IT">Information Technology (IT)</option>
                <option value="ECE">Electronics &amp; Communication (ECE)</option>
                <option value="MECH">Mechanical Engineering (MECH)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Current Semester
              </label>
              <input
                type="number"
                min={1}
                max={8}
                value={student.semester}
                onChange={e => setStudent({ ...student, semester: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Cumulative CGPA (0.0 - 10.0)
              </label>
              <input
                type="number"
                step="0.01"
                min={0}
                max={10}
                value={student.cgpa}
                onChange={e => setStudent({ ...student, cgpa: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Active Backlogs
              </label>
              <input
                type="number"
                min={0}
                max={10}
                value={student.backlogs}
                onChange={e => setStudent({ ...student, backlogs: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={student.phone}
                onChange={e => setStudent({ ...student, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Internship Preferences
              </label>
              <input
                type="text"
                placeholder="e.g. Backend, Distributed Systems, Hybrid"
                value={student.internshipPreferences}
                onChange={e => setStudent({ ...student, internshipPreferences: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Certifications (comma separated)
              </label>
              <input
                type="text"
                placeholder="e.g. Oracle Java SE, AWS Certified Cloud Practitioner"
                value={student.certifications.join(', ')}
                onChange={e =>
                  setStudent({
                    ...student,
                    certifications: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  })
                }
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Key Projects &amp; Repositories
              </label>
              <textarea
                rows={3}
                value={student.projects}
                onChange={e => setStudent({ ...student, projects: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div className="sm:col-span-2 pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl font-semibold text-xs bg-brand-blue hover:bg-blue-600 text-white shadow-md shadow-brand-blue/20 transition-colors"
              >
                Save Profile Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: MARKSHEETS & ACADEMIC RECORDS */}
      {/* ======================================================== */}
      {activeTab === 'academics' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Semester-wise Academic Records
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Recorded course subjects, marks, and SGPA values with automated CGPA synchronization.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs">
                <span className="text-slate-400">Current CGPA: </span>
                <span className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                  {student.cgpa.toFixed(2)}
                </span>
              </div>
              <button
                onClick={() => setShowAddRecordModal(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-brand-blue hover:bg-blue-600 text-white shadow-sm transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Record
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/60 uppercase font-semibold text-[10px] text-slate-400 tracking-wider">
                <tr>
                  <th className="p-3">Semester</th>
                  <th className="p-3">Course / Subject Name</th>
                  <th className="p-3">Marks (%)</th>
                  <th className="p-3">SGPA</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {academicRecords.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">
                      No academic records added yet. Click "Add Record" to start.
                    </td>
                  </tr>
                ) : (
                  academicRecords.map(rec => (
                    <tr key={rec.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-semibold text-slate-800 dark:text-slate-200">
                        Semester {rec.semester}
                      </td>
                      <td className="p-3 font-medium">{rec.subject}</td>
                      <td className="p-3">{rec.marks}%</td>
                      <td className="p-3 font-bold text-brand-blue dark:text-brand-cyan">
                        {rec.sgpa.toFixed(2)}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleDeleteRecord(rec.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                          title="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 space-y-1">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Automatic CGPA Formula: </span>
            The cumulative CGPA is automatically updated as the unweighted mean of all validated semester SGPA scores. Adding or altering records re-evaluates student eligibility across all openings instantly.
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 4: SKILLS & RESUME ANALYSIS */}
      {/* ======================================================== */}
      {activeTab === 'resume' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Skills Manager */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Technical Skills Inventory
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Add skills used by the Eligibility Engine to check role prerequisites.
              </p>
            </div>

            {/* Add skill input */}
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Skill name (e.g. Java, Python, SQL, Docker)"
                value={newSkillName}
                onChange={e => setNewSkillName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
              <div className="flex gap-2">
                <select
                  value={newSkillLevel}
                  onChange={e => setNewSkillLevel(e.target.value as any)}
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                >
                  <option value="BEGINNER">Beginner</option>
                  <option value="INTERMEDIATE">Intermediate</option>
                  <option value="ADVANCED">Advanced</option>
                </select>
                <button
                  onClick={handleAddSkill}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-brand-blue hover:bg-blue-600 text-white shrink-0"
                >
                  Add Skill
                </button>
              </div>
            </div>

            {/* Skills chips */}
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                My Skills ({student.skills.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {student.skills.map(sk => (
                  <span
                    key={sk.name}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700"
                  >
                    <span>{sk.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">({sk.proficiency[0]})</span>
                    <button
                      onClick={() => handleRemoveSkill(sk.name)}
                      className="text-slate-400 hover:text-rose-500 ml-1"
                      aria-label="Remove skill"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right 2 Columns: Resume Text, Parsing, ATS Match */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Resume Content &amp; ATS Keyword Extractor
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Whole-word skill matching ensures "JavaScript" does not falsely satisfy "Java".
                  </p>
                </div>

                {resume && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">Completeness:</span>
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-brand-blue dark:bg-blue-950/60 dark:text-brand-cyan">
                      {resume.resumeScore}%
                    </span>
                  </div>
                )}
              </div>

              {/* Paste or upload text */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Resume Plain Text / PDF Contents
                  </label>
                  <label className="text-xs font-semibold text-brand-blue hover:underline cursor-pointer flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5" />
                    Load from file
                    <input
                      type="file"
                      accept=".txt,.pdf"
                      className="hidden"
                      onChange={e => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = ev => {
                            const text = ev.target?.result as string;
                            setResumeTextInput(text);
                          };
                          reader.readAsText(file);
                        }
                      }}
                    />
                  </label>
                </div>

                <textarea
                  rows={8}
                  value={resumeTextInput}
                  onChange={e => setResumeTextInput(e.target.value)}
                  placeholder="Paste your full resume text here (Education, Skills, Experience, Projects, Certifications)..."
                  className="w-full p-4 text-xs font-mono rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-blue"
                />

                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSaveResume}
                      className="px-5 py-2 rounded-xl text-xs font-semibold bg-brand-blue hover:bg-blue-600 text-white shadow-sm transition-colors"
                    >
                      Analyze &amp; Save Resume
                    </button>
                    <button
                      onClick={handleAiResumeSuggestions}
                      disabled={isAiLoading}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 border border-purple-200 dark:border-purple-800 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      {isAiLoading ? 'Analyzing...' : 'AI Improvement Tips'}
                    </button>
                  </div>

                  {resume && (
                    <span className="text-[11px] text-slate-400">
                      Last updated: {new Date(resume.updatedAt).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </div>

              {/* Extracted Skills Chips */}
              {resume && resume.extractedSkills.length > 0 && (
                <div className="space-y-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Extracted Whole-Word Skills ({resume.extractedSkills.length}):
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {resume.extractedSkills.map(sk => (
                      <span
                        key={sk}
                        className="px-2.5 py-0.5 rounded-lg text-xs font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
                      >
                        ✓ {sk}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Resume Suggestions Panel */}
              {aiSuggestions.length > 0 && (
                <div className="p-4 rounded-2xl bg-purple-50/60 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-bold text-purple-900 dark:text-purple-200">
                      <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span>AI Suggestions for Campus Placement</span>
                    </div>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-600 bg-purple-100 dark:bg-purple-900/40 px-2 py-0.5 rounded-full">
                      Gemini Powered
                    </span>
                  </div>

                  <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-1.5 pl-4 list-disc">
                    {aiSuggestions.map((sug, sIdx) => (
                      <li key={sIdx}>{sug}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 5: DOCUMENTS */}
      {/* ======================================================== */}
      {activeTab === 'documents' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Verification Documents
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Official documents reviewed by Faculty Placement Officers to verify your student profile.
              </p>
            </div>

            <button
              onClick={() => setShowUploadDocModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-brand-blue hover:bg-blue-600 text-white shadow-sm transition-colors"
            >
              <Upload className="w-4 h-4" />
              Upload Document
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.length === 0 ? (
              <div className="col-span-3 p-12 text-center text-slate-400 text-xs">
                No documents uploaded yet. Upload semester marksheets or certificates for faculty verification.
              </div>
            ) : (
              documents.map(doc => (
                <div
                  key={doc.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                        {doc.documentType}
                      </span>
                      <StatusPill status={doc.verificationStatus} />
                    </div>

                    <h4 className="font-semibold text-sm text-slate-900 dark:text-white truncate" title={doc.fileName}>
                      {doc.fileName}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Uploaded on {doc.uploadedAt} · {doc.fileSize}
                    </p>

                    {doc.remarks && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 italic pt-1">
                        Note: "{doc.remarks}"
                      </p>
                    )}
                  </div>

                  <button
                    onClick={() => setPreviewDoc(doc)}
                    className="w-full py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Preview Document
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 6: APPLICATIONS PIPELINE */}
      {/* ======================================================== */}
      {activeTab === 'applications' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                My Applications &amp; Interview Pipeline
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Ordered stages: Applied → Resume Scored → Faculty Shortlist → Company Shortlist → Interviews → Selection → Offer.
              </p>
            </div>

            {applications.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-xs">
                You haven't submitted any applications yet. Explore openings under "Internships".
              </div>
            ) : (
              <div className="space-y-6">
                {applications.map(app => {
                  const pipelineStages = [
                    'APPLIED',
                    'RESUME_SCORED',
                    'FACULTY_SHORTLISTED',
                    'COMPANY_SHORTLISTED',
                    'INTERVIEW_SCHEDULED',
                    'SELECTED'
                  ];

                  const currentIdx = pipelineStages.indexOf(app.status);

                  return (
                    <div
                      key={app.id}
                      className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-5"
                    >
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-base text-slate-900 dark:text-white">
                              {app.internship.role}
                            </h3>
                            <StatusPill status={app.status} />
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5">
                            {app.internship.company.companyName} · Applied on {app.applicationDate}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="text-right text-xs">
                            <div className="text-slate-400">Resume Match:</div>
                            <span className="font-bold text-brand-blue dark:text-brand-cyan">
                              {app.resumeMatchScore}%
                            </span>
                          </div>

                          {!['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(app.status) && (
                            <button
                              onClick={() => setShowWithdrawConfirm(app.id)}
                              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60"
                            >
                              Withdraw
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Horizontal Pipeline Stepper */}
                      <div className="pt-2">
                        <div className="grid grid-cols-6 gap-1 text-center">
                          {pipelineStages.map((stage, sIdx) => {
                            const isCompleted = currentIdx >= sIdx || app.status === 'SELECTED';
                            const isCurrent = currentIdx === sIdx;
                            return (
                              <div key={stage} className="flex flex-col items-center">
                                <div
                                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold mb-1 transition-colors ${
                                    isCurrent
                                      ? 'bg-brand-blue text-white ring-4 ring-brand-blue/20'
                                      : isCompleted
                                      ? 'bg-emerald-500 text-white'
                                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                                  }`}
                                >
                                  {isCompleted && !isCurrent ? '✓' : sIdx + 1}
                                </div>
                                <span className="text-[10px] font-medium text-slate-500 hidden sm:block truncate w-full">
                                  {stage.replace('_', ' ')}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Scheduled Interviews */}
                      {app.interviews && app.interviews.length > 0 && (
                        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                          <div className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                            Interview Schedule ({app.interviews.length} rounds)
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {app.interviews.map(intv => (
                              <div
                                key={intv.id}
                                className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-xs"
                              >
                                <div>
                                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                                    Round {intv.round}: {intv.type.replace('_', ' ')}
                                  </div>
                                  <div className="text-[11px] text-slate-400 mt-0.5">
                                    {new Date(intv.scheduledDate).toLocaleDateString()} at {new Date(intv.scheduledDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({intv.mode})
                                  </div>
                                  {intv.remarks && (
                                    <div className="text-[10px] text-slate-500 italic mt-0.5">
                                      Remarks: {intv.remarks}
                                    </div>
                                  )}
                                </div>
                                <StatusPill status={intv.result} />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 7: EXTENDED OFFERS */}
      {/* ======================================================== */}
      {activeTab === 'offers' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Offers &amp; Final Placements
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Official offers extended by participating recruitment partners upon clearing all stages.
            </p>
          </div>

          <div className="space-y-4">
            {offers.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-xs">
                No active offers yet. Progress through interview stages to receive offers.
              </div>
            ) : (
              offers.map(offer => {
                const app = applications.find(a => a.id === offer.applicationId);
                return (
                  <div
                    key={offer.id}
                    className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800/80 space-y-4 shadow-sm"
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                            {app?.internship.role || 'Internship Offer'}
                          </h3>
                          <StatusPill status={offer.status} />
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {app?.internship.company.companyName} · Offer Date: {offer.offerDate} · Valid Until: {offer.validUntil}
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="text-xs text-slate-400">Monthly Stipend</div>
                        <div className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">
                          ₹{offer.stipend.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      {offer.letterText || 'We are pleased to offer you this internship position.'}
                    </div>

                    {offer.status === 'EXTENDED' && (
                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          onClick={() => handleRespondOffer(offer.id, 'DECLINED')}
                          className="px-4 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-800"
                        >
                          Decline Offer
                        </button>
                        <button
                          onClick={() => handleRespondOffer(offer.id, 'ACCEPTED')}
                          className="px-6 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20"
                        >
                          Accept Offer 🎉
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Add Academic Record Modal */}
      <Modal
        isOpen={showAddRecordModal}
        onClose={() => setShowAddRecordModal(false)}
        title="Add Semester Academic Record"
        description="Recorded course marks are used to verify semester SGPA and compute cumulative CGPA."
      >
        <form onSubmit={handleAddRecord} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Semester
            </label>
            <input
              type="number"
              min={1}
              max={8}
              value={newRecord.semester}
              onChange={e => setNewRecord({ ...newRecord, semester: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              required
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Course / Subject Name
            </label>
            <input
              type="text"
              placeholder="e.g. Distributed Operating Systems"
              value={newRecord.subject}
              onChange={e => setNewRecord({ ...newRecord, subject: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Marks Obtained (%)
              </label>
              <input
                type="number"
                min={0}
                max={100}
                value={newRecord.marks}
                onChange={e => setNewRecord({ ...newRecord, marks: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Semester SGPA (0.0 - 10.0)
              </label>
              <input
                type="number"
                step="0.01"
                min={0}
                max={10}
                value={newRecord.sgpa}
                onChange={e => setNewRecord({ ...newRecord, sgpa: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                required
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={() => setShowAddRecordModal(false)}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-blue hover:bg-blue-600 text-white font-semibold shadow-sm"
            >
              Save Record
            </button>
          </div>
        </form>
      </Modal>

      {/* Upload Document Modal */}
      <Modal
        isOpen={showUploadDocModal}
        onClose={() => setShowUploadDocModal(false)}
        title="Upload Verification Document"
        description="Upload official university marksheet, certification, or ID card."
      >
        <form onSubmit={handleUploadDocument} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Document Category
            </label>
            <select
              value={newDocType}
              onChange={e => setNewDocType(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            >
              <option value="MARKSHEET">Semester Marksheet</option>
              <option value="CERTIFICATE">Professional Certification</option>
              <option value="RESUME">Official Signed Resume</option>
              <option value="ID_CARD">College Student ID</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Select Document File (PDF, PNG, JPG)
            </label>
            <input
              type="file"
              onChange={e => setNewDocFile(e.target.files?.[0] || null)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={() => setShowUploadDocModal(false)}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-blue hover:bg-blue-600 text-white font-semibold shadow-sm"
            >
              Submit for Verification
            </button>
          </div>
        </form>
      </Modal>

      {/* Document Preview Drawer */}
      <Drawer
        isOpen={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        title={previewDoc?.fileName || 'Document Preview'}
        subtitle={`Category: ${previewDoc?.documentType} · Status: ${previewDoc?.verificationStatus}`}
      >
        {previewDoc && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
              <div>
                <span className="text-slate-400">Uploaded: </span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {previewDoc.uploadedAt}
                </span>
              </div>
              <StatusPill status={previewDoc.verificationStatus} />
            </div>

            {previewDoc.remarks && (
              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200">
                <span className="font-bold">Faculty Remarks: </span>
                {previewDoc.remarks}
              </div>
            )}

            {/* Document Reader Frame */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center bg-slate-100/60 dark:bg-slate-950 flex flex-col items-center justify-center min-h-[350px]">
              <FileCheck className="w-16 h-16 text-brand-blue mb-3" />
              <div className="font-bold text-sm text-slate-800 dark:text-slate-200">
                {previewDoc.fileName}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Size: {previewDoc.fileSize} · Verified Digital Document
              </div>
              <div className="mt-6 flex gap-2">
                <a
                  href={previewDoc.fileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-brand-blue text-white shadow-sm flex items-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Open in New Window
                </a>
              </div>
            </div>
          </div>
        )}
      </Drawer>

      {/* Withdraw Confirmation Modal */}
      <Modal
        isOpen={!!showWithdrawConfirm}
        onClose={() => setShowWithdrawConfirm(null)}
        title="Withdraw Application?"
        description="Are you sure you want to withdraw your application for this internship?"
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <p className="text-slate-600 dark:text-slate-400">
            Withdrawing will remove your profile from the company's active interview schedule.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setShowWithdrawConfirm(null)}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              onClick={() => showWithdrawConfirm && handleWithdraw(showWithdrawConfirm)}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold"
            >
              Confirm Withdraw
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { api } from '@/services/api';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  Cell
} from 'recharts';
import {
  Download,
  Users,
  CheckCircle2,
  TrendingUp,
  FileCheck,
  Award,
  Calendar,
  Building2,
  Sparkles
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [dateRange, setDateRange] = useState<'ALL' | '30D' | '14D' | '7D'>('ALL');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        const res = await api.getAnalyticsSummary();
        setData(res);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  const handleExportCSV = () => {
    if (!data) return;
    const rows = [
      ['Metric', 'Value'],
      ['Total Students', data.kpi.totalStudents],
      ['Verified Students', data.kpi.verifiedStudents],
      ['Eligible Students', data.kpi.eligibleStudents],
      ['Total Openings', data.kpi.totalInternships],
      ['Total Applications', data.kpi.totalApplications],
      ['Shortlisted Applications', data.kpi.shortlistedCount],
      ['Selected Candidates', data.kpi.selectedCount],
      ['Offers Accepted', data.kpi.acceptedCount],
      [],
      ['Funnel Stage', 'Count'],
      ...data.funnel.map((f: any) => [f.stage, f.count]),
      [],
      ['Department', 'Total Students', 'Verified', 'Applications', 'Selected'],
      ...data.departmentWise.map((d: any) => [d.department, d.total, d.verified, d.applied, d.selected]),
      [],
      ['Company', 'Openings', 'Applications', 'Selected'],
      ...data.companyWise.map((c: any) => [c.companyName, c.openings, c.applications, c.selected])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `internhub_placement_analytics_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading || !data) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-24 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
          ))}
        </div>
        <div className="h-80 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
      </div>
    );
  }

  const { kpi, funnel, departmentWise, companyWise, applicationsTimeline } = data;

  const kpiCards = [
    { title: 'Registered Students', value: kpi.totalStudents, sub: `${kpi.verifiedStudents} verified by faculty`, icon: Users, color: 'text-brand-blue' },
    { title: 'Currently Eligible', value: kpi.eligibleStudents, sub: `${((kpi.eligibleStudents / kpi.totalStudents) * 100).toFixed(0)}% of student pool`, icon: CheckCircle2, color: 'text-emerald-500' },
    { title: 'Active Applications', value: kpi.totalApplications, sub: `${kpi.shortlistedCount} shortlisted`, icon: TrendingUp, color: 'text-brand-indigo' },
    { title: 'Selected & Offers', value: kpi.selectedCount, sub: `${kpi.acceptedCount} accepted offers`, icon: Award, color: 'text-brand-cyan' }
  ];

  return (
    <div className="space-y-8">
      {/* Top Header & Export */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Placement &amp; Eligibility Analytics Suite
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time pipeline metrics, department ratios, and industry conversion rates.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
            {(['ALL', '30D', '14D', '7D'] as const).map(range => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  dateRange === range
                    ? 'bg-white dark:bg-slate-900 text-brand-blue shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-brand-blue hover:bg-blue-600 text-white shadow-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map(c => {
          const Icon = c.icon;
          return (
            <div
              key={c.title}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  {c.title}
                </span>
                <Icon className={`w-5 h-5 ${c.color}`} />
              </div>
              <div className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                {c.value}
              </div>
              <p className="text-xs text-slate-400 font-medium">
                {c.sub}
              </p>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Placement Funnel Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Campus Placement Pipeline Funnel
            </h3>
            <p className="text-xs text-slate-400">
              Conversion from eligibility to final student offer acceptance.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={funnel} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis type="number" fontSize={11} />
                <YAxis dataKey="stage" type="category" width={90} fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    fontSize: '12px',
                    backgroundColor: '#0F172A',
                    color: '#FFF',
                    border: 'none'
                  }}
                />
                <Bar dataKey="count" radius={[0, 8, 8, 0]}>
                  {funnel.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Applications Over Time Line Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Application Volume Progression
            </h3>
            <p className="text-xs text-slate-400">
              Cumulative student submissions logged across campus cycle.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={applicationsTimeline} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="date" fontSize={11} />
                <YAxis fontSize={11} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    fontSize: '12px',
                    backgroundColor: '#0F172A',
                    color: '#FFF',
                    border: 'none'
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="#2D6CDF"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#2D6CDF' }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department-wise Bar Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Department Performance Breakdown
            </h3>
            <p className="text-xs text-slate-400">
              Total candidates vs verified vs applications by branch.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentWise} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="department" fontSize={11} />
                <YAxis fontSize={11} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    fontSize: '12px',
                    backgroundColor: '#0F172A',
                    color: '#FFF',
                    border: 'none'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="total" name="Total Students" fill="#94A3B8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="verified" name="Verified" fill="#10B981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="applied" name="Applications" fill="#2D6CDF" radius={[4, 4, 0, 0]} />
                <Bar dataKey="selected" name="Selected" fill="#5439D6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Company-wise Bar Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Industry Hiring &amp; Demand
            </h3>
            <p className="text-xs text-slate-400">
              Vacancies opened vs candidate applications per recruiting company.
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={companyWise} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="companyName" fontSize={10} angle={-15} textAnchor="end" height={40} />
                <YAxis fontSize={11} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    fontSize: '12px',
                    backgroundColor: '#0F172A',
                    color: '#FFF',
                    border: 'none'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="openings" name="Total Vacancies" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                <Bar dataKey="applications" name="Applications" fill="#2D6CDF" radius={[4, 4, 0, 0]} />
                <Bar dataKey="selected" name="Selected" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Layers,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Cpu,
  Database,
  FileCode,
  Key,
  AlertTriangle,
  Award,
  BookOpen,
  Copy,
  ChevronRight,
  Sparkles,
  ExternalLink,
  Code2
} from 'lucide-react';
import { Modal } from './Modal';
import { useAuth } from '@/core/auth/useAuth';
import { JAVA_CODE_SNIPPETS, ACADEMIC_CONCEPTS_MAP, AcademicConceptItem } from '@/data/javaCodeSnippets';

interface ArchitectureInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureInspectorModal: React.FC<ArchitectureInspectorModalProps> = ({
  isOpen,
  onClose
}) => {
  const { currentUser, securityLayers, sessionTimeRemaining } = useAuth();
  const [activeTab, setActiveTab] = useState<'layers' | 'matrix' | 'tamper_test' | 'java_source' | 'rubric'>('rubric');
  const [selectedJavaFile, setSelectedJavaFile] = useState<string>('EligibilityService.java');
  const [copied, setCopied] = useState<boolean>(false);
  const [tamperTestStatus, setTamperTestStatus] = useState<string | null>(null);
  const [rubricCategory, setRubricCategory] = useState<string>('ALL');
  const [selectedConcept, setSelectedConcept] = useState<AcademicConceptItem>(ACADEMIC_CONCEPTS_MAP[0]);
  const [reportCopied, setReportCopied] = useState<boolean>(false);

  const getLayerIcon = (layerNumber: number) => {
    switch (layerNumber) {
      case 1:
        return Layers;
      case 2:
        return Lock;
      case 3:
        return Key;
      case 4:
        return ShieldCheck;
      case 5:
        return Cpu;
      case 6:
        return FileCode;
      case 7:
        return Database;
      default:
        return Layers;
    }
  };

  const handleSimulateTampering = () => {
    try {
      const raw = sessionStorage.getItem('internhub_auth_session_token');
      if (raw) {
        const parsed = JSON.parse(raw);
        parsed.user.role = 'ADMIN'; // Tampered role
        sessionStorage.setItem('internhub_auth_session_token', JSON.stringify(parsed));
        setTamperTestStatus(
          'Simulated client-side payload modification (Role altered to ADMIN). Refreshing to test Layer 7 & Layer 3 defense...'
        );
        setTimeout(() => {
          window.location.reload();
        }, 1200);
      } else {
        setTamperTestStatus('No active session token to tamper with.');
      }
    } catch (e: any) {
      setTamperTestStatus(`Error: ${e.message}`);
    }
  };

  const filteredConcepts = rubricCategory === 'ALL'
    ? ACADEMIC_CONCEPTS_MAP
    : ACADEMIC_CONCEPTS_MAP.filter(c => c.category === rubricCategory);

  const copyFullRubricReport = () => {
    const reportText = ACADEMIC_CONCEPTS_MAP.map(c =>
      `### [${c.category}] ${c.name}\n- **File**: \`${c.filePath}\`\n- **Criterion for Marks**: ${c.rubricCriterion}\n- **Implementation**: ${c.summary}\n`
    ).join('\n---\n\n');

    navigator.clipboard.writeText(
      `# InternHub Project — Java & OOP Concepts Marking Criteria Report\n\n` + reportText
    );
    setReportCopied(true);
    setTimeout(() => setReportCopied(false), 2200);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Multi-Layered Architecture & Defense-in-Depth Inspector"
      maxWidth="4xl"
    >
      <div className="space-y-6">
        {/* Top Summary Header */}
        <div className="bg-gradient-to-br from-navy-900 to-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="absolute right-0 top-0 transform translate-x-10 -translate-y-10 w-44 h-44 bg-brand-blue/20 rounded-full blur-3xl pointer-events-none" />
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Award className="w-3 h-3 text-amber-400" />
                  Academic Criteria Ready
                </span>
                <span className="text-xs text-slate-300">
                  Full OOP &amp; Enterprise Java Concepts Rubric
                </span>
              </div>
              <h3 className="text-lg font-bold text-white">
                Decoupled Multi-Tier Layered Architecture (Spring Boot &amp; React)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Strategy Pattern · Builder Pattern · Observer Pattern · Stream API · Polymorphism · Encapsulation
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-md px-3.5 py-2.5 rounded-xl border border-white/10 text-right">
              <span className="text-[10px] text-slate-300 block uppercase font-mono">
                Active Session Expiry
              </span>
              <span className="text-sm font-bold font-mono text-emerald-400">
                {Math.floor(sessionTimeRemaining / 60)}m {sessionTimeRemaining % 60}s
              </span>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('rubric')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 ${
              activeTab === 'rubric'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Academic Concepts &amp; Marks Rubric</span>
          </button>
          <button
            onClick={() => setActiveTab('java_source')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 ${
              activeTab === 'java_source'
                ? 'bg-brand-blue text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Java Source Files</span>
          </button>
          <button
            onClick={() => setActiveTab('layers')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              activeTab === 'layers'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            All 7 Architecture Layers
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              activeTab === 'matrix'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            RBAC Permission Matrix
          </button>
          <button
            onClick={() => setActiveTab('tamper_test')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              activeTab === 'tamper_test'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Security Defense Simulation
          </button>
        </div>

        {/* Tab: Academic Concepts & Marks Rubric */}
        {activeTab === 'rubric' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 rounded-xl">
              <div>
                <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-amber-600" />
                  Academic Evaluation Guide: Where Concepts Are Used &amp; Marks Criteria
                </h4>
                <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">
                  Every concept is implemented in <code className="font-mono bg-amber-100 dark:bg-amber-900/40 px-1 py-0.2 rounded">backend-java/src/main/java/com/internhub/</code>. Click any concept to view details.
                </p>
              </div>
              <button
                onClick={copyFullRubricReport}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold transition-colors shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{reportCopied ? 'Report Copied!' : 'Copy Evaluation Report'}</span>
              </button>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5">
              {['ALL', 'OOP Core', 'Design Patterns', 'Java Language Features', 'Enterprise Architecture'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setRubricCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                    rubricCategory === cat
                      ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Dual Pane: Concept List on Left, Active Concept Details & Snippet on Right */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-5 space-y-2 max-h-[44vh] overflow-y-auto pr-1">
                {filteredConcepts.map(c => {
                  const isSelected = selectedConcept.id === c.id;
                  return (
                    <div
                      key={c.id}
                      onClick={() => setSelectedConcept(c)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        isSelected
                          ? 'border-amber-500 bg-amber-500/10 dark:bg-amber-500/15 shadow-xs'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/80 px-2 py-0.5 rounded-md">
                          {c.category}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400 truncate max-w-[140px]">
                          {c.fileName}
                        </span>
                      </div>
                      <h5 className="text-xs font-bold text-slate-900 dark:text-white">
                        {c.name}
                      </h5>
                      <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                        {c.summary}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Detail Pane */}
              <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-amber-600 font-mono">
                        {selectedConcept.category}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {selectedConcept.name}
                      </h4>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">
                        {selectedConcept.filePath}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedJavaFile(selectedConcept.fileName.split(' ')[0]);
                        setActiveTab('java_source');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-cyan text-xs font-semibold hover:bg-brand-blue/20 transition-colors flex items-center gap-1 shrink-0"
                    >
                      <span>View File</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div>
                    <h6 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Academic Marks Criterion &amp; Justification
                    </h6>
                    <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 text-xs text-emerald-800 dark:text-emerald-300">
                      {selectedConcept.rubricCriterion}
                    </div>
                  </div>

                  <div>
                    <h6 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Architecture Implementation
                    </h6>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      {selectedConcept.summary}
                    </p>
                  </div>

                  <div>
                    <h6 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Java Code Implementation Extract
                    </h6>
                    <div className="rounded-lg bg-slate-950 p-3 overflow-x-auto max-h-[20vh] text-slate-300 font-mono text-[11px] leading-relaxed border border-slate-800">
                      <pre><code>{selectedConcept.codeSnippet}</code></pre>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 1: Architecture Layers */}
        {activeTab === 'layers' && (
          <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
            {securityLayers.map(layer => {
              const Icon = getLayerIcon(layer.layerNumber);
              return (
                <div
                  key={layer.layerNumber}
                  className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-brand-blue/50 dark:hover:border-brand-blue/50 transition-all shadow-xs flex items-start gap-3.5"
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-brand-blue dark:text-brand-cyan flex items-center justify-center shrink-0 font-bold">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-slate-400">
                          Tier 0{layer.layerNumber}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {layer.name}
                        </h4>
                      </div>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        <CheckCircle2 className="w-3 h-3" /> {layer.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {layer.description}
                    </p>
                    <div className="mt-2 flex items-center gap-4 text-[11px] text-slate-400">
                      <span>Category: <strong>{layer.category}</strong></span>
                      <span>Verified: <strong className="text-emerald-500">{layer.lastChecked}</strong></span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: Permission Matrix */}
        {activeTab === 'matrix' && (
          <div className="space-y-3">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              InternHub employs a strict <strong>Deny-by-Default</strong> authorization paradigm. If a role is not explicitly granted an operation, execution terminates with 403 Forbidden.
            </p>
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="p-3">Resource &amp; Action</th>
                    <th className="p-3 text-center">Student</th>
                    <th className="p-3 text-center">Faculty</th>
                    <th className="p-3 text-center">Company</th>
                    <th className="p-3 text-center">Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  <tr>
                    <td className="p-3 font-medium">View &amp; Edit Own Student Profile</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-medium">Verify Marks &amp; Documents</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-medium">Post &amp; Edit Company Job Criteria</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-medium">View System-wide Security Audit Logs</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-slate-400">DENIED</td>
                    <td className="p-3 text-center text-emerald-600 font-bold">ALLOWED</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Security Defense Simulation */}
        {activeTab === 'tamper_test' && (
          <div className="space-y-4 bg-rose-50/50 dark:bg-rose-950/20 p-5 rounded-2xl border border-rose-200 dark:border-rose-900/50">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-rose-900 dark:text-rose-200">
                  Simulate Client-Side Token Tampering
                </h4>
                <p className="text-xs text-rose-700 dark:text-rose-300 mt-1">
                  In vulnerable unlayered architectures, attackers modify localStorage values (e.g., setting role="ADMIN"). In InternHub's 7-tier architecture, Layer 7 (Cryptographic HMAC) immediately flags the mismatched signature, logs a security audit event, and purges the session.
                </p>
              </div>
            </div>

            {tamperTestStatus && (
              <div className="p-3 rounded-xl bg-slate-900 text-white font-mono text-xs">
                {tamperTestStatus}
              </div>
            )}

            <button
              onClick={handleSimulateTampering}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs transition-colors shadow-md active:scale-98"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Simulate Tamper Attack (Test Anti-Tamper Layer)</span>
            </button>
          </div>
        )}

        {/* Tab 4: Java Spring Boot Layered Architecture Source */}
        {activeTab === 'java_source' && (
          <div className="space-y-4">
            <div className="bg-amber-50 dark:bg-amber-950/30 p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="font-semibold text-amber-900 dark:text-amber-200">
                  Enterprise Layered Java Architecture (Spring Boot 3 + JPA + Security)
                </span>
              </div>
              <span className="text-[11px] text-amber-700 dark:text-amber-300 font-mono">
                Location: /backend-java/src/main/java/com/internhub/
              </span>
            </div>

            {/* Java File Selector */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
              {[
                { name: 'EligibilityService.java', layer: 'Service & Builder' },
                { name: 'CandidateRankingService.java', layer: 'Service & Streams' },
                { name: 'RankingStrategy.java', layer: 'Strategy Pattern' },
                { name: 'EligibilityRule.java', layer: 'Rules & Polymorphism' },
                { name: 'NotificationFactory.java', layer: 'Factory Pattern' },
                { name: 'ApplicationEventListener.java', layer: 'Observer Pattern' },
                { name: 'BaseEntity.java', layer: 'Inheritance & Abstraction' },
                { name: 'ApiResponse.java', layer: 'Generics & Builder' },
                { name: 'GlobalExceptionHandler.java', layer: 'Exception Handling' },
                { name: 'Student.java', layer: 'Encapsulation & Entity' },
                { name: 'AuthController.java', layer: 'REST Controller' },
                { name: 'pom.xml', layer: 'Maven Build' }
              ].map(file => (
                <button
                  key={file.name}
                  onClick={() => {
                    setSelectedJavaFile(file.name);
                    setCopied(false);
                  }}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
                    selectedJavaFile === file.name
                      ? 'bg-white dark:bg-slate-800 text-brand-blue dark:text-brand-cyan shadow-xs font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono">
                    {file.layer}
                  </span>
                  <span>{file.name}</span>
                </button>
              ))}
            </div>

            {/* Code Box */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 text-slate-200 shadow-xl">
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2 font-mono text-slate-400">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  <span>{selectedJavaFile}</span>
                </div>
                <button
                  onClick={() => {
                    const code = JAVA_CODE_SNIPPETS[selectedJavaFile] || '';
                    navigator.clipboard.writeText(code);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono transition-colors"
                >
                  {copied ? '✓ Copied!' : 'Copy Java Code'}
                </button>
              </div>
              <pre className="p-4 text-xs font-mono leading-relaxed overflow-x-auto max-h-[42vh] text-slate-300 selection:bg-brand-blue/30">
                <code>{JAVA_CODE_SNIPPETS[selectedJavaFile] || '// Java source code loaded'}</code>
              </pre>
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-200 dark:border-slate-800">
          <span>Active Persona: <strong className="text-slate-700 dark:text-slate-300">{currentUser?.name}</strong> ({currentUser?.role})</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </Modal>
  );
};

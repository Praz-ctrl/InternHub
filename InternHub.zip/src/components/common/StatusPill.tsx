import React from 'react';

interface StatusPillProps {
  status: string;
  size?: 'sm' | 'md';
}

export const StatusPill: React.FC<StatusPillProps> = ({ status, size = 'sm' }) => {
  const norm = (status || '').toUpperCase().replace(/[\s-]/g, '_');

  let colorClasses = 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700';

  if (['VERIFIED', 'PASS', 'SELECTED', 'ACCEPTED', 'ELIGIBLE', 'OPEN'].includes(norm)) {
    colorClasses = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60';
  } else if (['REJECTED', 'FAIL', 'DECLINED', 'NOT_ELIGIBLE', 'CLOSED'].includes(norm)) {
    colorClasses = 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-800/60';
  } else if (['PENDING', 'PENDING_APPROVAL', 'APPLIED', 'WITHDRAWN'].includes(norm)) {
    colorClasses = 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800/60';
  } else if (['FACULTY_SHORTLISTED', 'COMPANY_SHORTLISTED', 'INTERVIEW_SCHEDULED', 'EXTENDED', 'RESUME_SCORED'].includes(norm)) {
    colorClasses = 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-200 dark:border-blue-800/60';
  }

  const label = norm.replace(/_/g, ' ');
  const sizeClass = size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-sm';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${sizeClass} ${colorClasses} tracking-tight whitespace-nowrap`}
    >
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-70" />
      {label}
    </span>
  );
};

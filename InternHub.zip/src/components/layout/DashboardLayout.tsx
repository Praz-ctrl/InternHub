import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { CommandPalette } from '@/components/CommandPalette';
import { ArchitectureInspectorModal } from '@/components/common/ArchitectureInspectorModal';
import { useAuth } from '@/core/auth/useAuth';
import { NotificationItem, Role } from '@/types';
import { ShieldCheck, Layers, Lock, ChevronRight, Sparkles } from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onMarkAllNotificationsRead: () => void;
  onResetData: () => void;
  isDark: boolean;
  onToggleDark: () => void;
  currentNavTab: string;
  onNavigateTab: (tab: string) => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  children,
  notifications,
  onMarkNotificationRead,
  onMarkAllNotificationsRead,
  onResetData,
  isDark,
  onToggleDark,
  currentNavTab,
  onNavigateTab
}) => {
  const { currentUser, logout, switchUser, sessionTimeRemaining } = useAuth();
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState(false);

  if (!currentUser) return null;

  const roleMeta: Record<Role, { label: string; color: string; badge: string }> = {
    STUDENT: {
      label: 'Student Portal',
      color: 'from-blue-600 to-indigo-600',
      badge: 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300'
    },
    FACULTY: {
      label: 'Faculty Verification & Placement Office',
      color: 'from-indigo-600 to-violet-600',
      badge: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300'
    },
    COMPANY: {
      label: 'Enterprise Recruiter Console',
      color: 'from-amber-600 to-orange-600',
      badge: 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
    },
    ADMIN: {
      label: 'Dean & Administrator Oversight',
      color: 'from-rose-600 to-pink-600',
      badge: 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
    }
  };

  const meta = roleMeta[currentUser.role];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans transition-colors relative selection:bg-brand-blue selection:text-white">
      {/* Tier 1: Top Authenticated Navigation Header */}
      <Navbar
        currentUser={currentUser}
        onLogout={logout}
        notifications={notifications}
        onMarkNotificationRead={onMarkNotificationRead}
        onMarkAllNotificationsRead={onMarkAllNotificationsRead}
        onResetData={onResetData}
        isDark={isDark}
        onToggleDark={onToggleDark}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onNavigateTab={onNavigateTab}
      />

      {/* Tier 2: Architectural Security & Role Sub-Banner */}
      <div className="relative z-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
          {/* Breadcrumb path */}
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
            <span className="font-semibold text-slate-700 dark:text-slate-200">InternHub</span>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="font-medium text-slate-900 dark:text-white">{meta.label}</span>
            {currentNavTab && (
              <>
                <ChevronRight className="w-3.5 h-3.5" />
                <span className="capitalize font-mono text-brand-blue dark:text-brand-cyan">
                  {currentNavTab}
                </span>
              </>
            )}
          </div>

          {/* Layered Architecture Badge & Inspector Trigger */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsInspectorOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 font-semibold transition-colors"
              title="Click to inspect the 7-Layer Defense-in-Depth Architecture"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>7-Layer Security: Active</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </button>

            <span className="text-[11px] text-slate-400 font-mono hidden md:inline">
              Session: {Math.floor(sessionTimeRemaining / 60)}m left
            </span>
          </div>
        </div>
      </div>

      {/* Tier 3: Main Dashboard Content Layer */}
      <main className="flex-1 pb-16">
        {children}
      </main>

      {/* Tier 4: Overlay & Command Palette */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onLogout={logout}
        onNavigateTab={onNavigateTab}
        onResetData={onResetData}
        currentRole={currentUser.role}
        isDark={isDark}
        onToggleDark={onToggleDark}
        onOpenInspector={() => setIsInspectorOpen(true)}
      />

      {/* Architecture Inspector Modal */}
      <ArchitectureInspectorModal
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
      />

      {/* Tier 5: Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 py-6 text-center text-xs text-slate-400 bg-white/40 dark:bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span>InternHub — Campus Internship Management Portal</span>
            <span>·</span>
            <button
              onClick={() => setIsInspectorOpen(true)}
              className="text-brand-blue dark:text-brand-cyan hover:underline inline-flex items-center gap-1"
            >
              <Layers className="w-3 h-3" />
              Inspect Layered Architecture
            </button>
          </div>
          <span>
            Authenticated Persona: <strong>{currentUser.name}</strong> ({currentUser.role})
          </span>
        </div>
      </footer>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Compass, UserCheck, Briefcase, BarChart3, Users, RotateCcw, X, Moon, Sun, LogOut, ShieldAlert, Layers } from 'lucide-react';
import { Role } from '@/types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  onNavigateTab: (tab: string) => void;
  onResetData: () => void;
  currentRole: Role;
  isDark: boolean;
  onToggleDark: () => void;
  onOpenInspector?: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onLogout,
  onNavigateTab,
  onResetData,
  currentRole,
  isDark,
  onToggleDark,
  onOpenInspector
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const items = [
    // Session & Security
    { id: 'action-logout', category: 'Authentication', title: 'Sign Out / Terminate Portal Session', icon: LogOut, action: onLogout },

    // Student Navigation
    ...(currentRole === 'STUDENT' ? [
      { id: 'stu-browse', category: 'Student Pages', title: 'Browse Campus Internships & Eligibility', icon: Briefcase, action: () => onNavigateTab('browse') },
      { id: 'stu-profile', category: 'Student Pages', title: 'Academic Profile & Personal Info', icon: Compass, action: () => onNavigateTab('profile') },
      { id: 'stu-academics', category: 'Student Pages', title: 'Marksheets & Semester Records', icon: Compass, action: () => onNavigateTab('academics') },
      { id: 'stu-resume', category: 'Student Pages', title: 'Skills & Resume Analysis', icon: Compass, action: () => onNavigateTab('resume') },
      { id: 'stu-apps', category: 'Student Pages', title: 'Application Pipeline & Interviews', icon: Compass, action: () => onNavigateTab('applications') },
      { id: 'stu-offers', category: 'Student Pages', title: 'Extended Offers & Responses', icon: Compass, action: () => onNavigateTab('offers') },
    ] : []),

    // Faculty Navigation
    ...(currentRole === 'FACULTY' ? [
      { id: 'fac-verify', category: 'Faculty Pages', title: 'Student & Document Verification Queue', icon: UserCheck, action: () => onNavigateTab('verification') },
      { id: 'fac-apps', category: 'Faculty Pages', title: 'Application Shortlisting & ATR Scoring', icon: Briefcase, action: () => onNavigateTab('applications') },
      { id: 'fac-approvals', category: 'Faculty Pages', title: 'Company Internship Approvals Inbox', icon: Briefcase, action: () => onNavigateTab('approvals') },
      { id: 'fac-analytics', category: 'Faculty Pages', title: 'Campus Placement Analytics & Funnel', icon: BarChart3, action: () => onNavigateTab('analytics') },
    ] : []),

    // Company Navigation
    ...(currentRole === 'COMPANY' ? [
      { id: 'com-post', category: 'Company Pages', title: 'Post / Edit Internships & Live Preview', icon: Briefcase, action: () => onNavigateTab('post') },
      { id: 'com-kanban', category: 'Company Pages', title: 'Applicants Kanban Board & Pipeline', icon: Users, action: () => onNavigateTab('applicants') },
      { id: 'com-ranking', category: 'Company Pages', title: 'Candidate Ranking & Score Breakdown', icon: BarChart3, action: () => onNavigateTab('ranking') },
    ] : []),

    // Admin Navigation
    ...(currentRole === 'ADMIN' ? [
      { id: 'adm-users', category: 'Admin Pages', title: 'User Accounts & Access Governance', icon: Users, action: () => onNavigateTab('users') },
      { id: 'adm-audit', category: 'Admin Pages', title: 'Security Audit Logs & Access Control', icon: ShieldAlert, action: () => onNavigateTab('audit') },
      { id: 'adm-analytics', category: 'Admin Pages', title: 'Campus Placement & Institutional Analytics', icon: BarChart3, action: () => onNavigateTab('analytics') },
    ] : []),

    // Global Actions
    ...(onOpenInspector ? [
      { id: 'action-layers', category: 'Architecture & Security', title: 'Inspect 7-Layer Defense-in-Depth Architecture', icon: Layers, action: onOpenInspector }
    ] : []),
    { id: 'action-theme', category: 'Settings', title: isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode', icon: isDark ? Sun : Moon, action: onToggleDark },
    { id: 'action-reset', category: 'Settings', title: 'Reset Demo Data to Initial State', icon: RotateCcw, action: onResetData },
  ];

  const filtered = items.filter(i =>
    i.title.toLowerCase().includes(query.toLowerCase()) ||
    i.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
          >
            <div className="flex items-center px-4 py-3.5 border-b border-slate-100 dark:border-slate-800">
              <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
              <input
                autoFocus
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Type a command, page, or action... (e.g. 'Student', 'Browse', 'Reset')"
                className="w-full bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
              />
              <button
                onClick={onClose}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-80 overflow-y-auto p-2">
              {filtered.length === 0 ? (
                <div className="p-8 text-center text-sm text-slate-500">
                  No matching commands found.
                </div>
              ) : (
                filtered.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        item.action();
                        onClose();
                      }}
                      className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 group-hover:bg-brand-blue/10 group-hover:text-brand-blue">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-900 dark:text-white">
                            {item.title}
                          </div>
                          <div className="text-xs text-slate-400">{item.category}</div>
                        </div>
                      </div>
                      <span className="text-xs text-slate-400 group-hover:text-brand-blue">
                        Select →
                      </span>
                    </button>
                  );
                })
              )}
            </div>

            <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 text-xs text-slate-400 flex items-center justify-between">
              <span>Use <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-[10px] font-mono">ESC</kbd> to exit</span>
              <span>InternHub Command Palette</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

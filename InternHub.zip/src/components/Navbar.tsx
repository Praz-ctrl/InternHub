import React, { useState } from 'react';
import {
  GraduationCap,
  Bell,
  Sun,
  Moon,
  RotateCcw,
  Search,
  CheckCheck,
  ShieldCheck,
  Building2,
  Users2,
  LogOut,
} from 'lucide-react';
import { User, Role, NotificationItem } from '@/types';
import { Modal } from './common/Modal';

interface NavbarProps {
  currentUser: User;
  onLogout: () => void;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onMarkAllNotificationsRead: () => void;
  onResetData: () => void;
  isDark: boolean;
  onToggleDark: () => void;
  onOpenCommandPalette: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  notifications,
  onMarkNotificationRead,
  onMarkAllNotificationsRead,
  onResetData,
  isDark,
  onToggleDark,
  onOpenCommandPalette,
  onNavigateTab,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const roleMeta: Record<
    Role,
    { label: string; icon: any; badgeClass: string; title: string }
  > = {
    STUDENT: {
      label: 'Student Portal',
      icon: GraduationCap,
      badgeClass:
        'bg-blue-100 text-brand-blue border-blue-200 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-900',
      title: 'Academic Records, Marksheets & Internship Applications',
    },
    FACULTY: {
      label: 'Faculty Placement Cell',
      icon: ShieldCheck,
      badgeClass:
        'bg-indigo-100 text-indigo-700 border-indigo-200 dark:bg-indigo-950/70 dark:text-indigo-300 dark:border-indigo-900',
      title: 'Student Verification & Curriculum Approval',
    },
    COMPANY: {
      label: 'Corporate Recruiter',
      icon: Building2,
      badgeClass:
        'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-900',
      title: 'Job Postings, Candidate Ranking & Interview Rounds',
    },
    ADMIN: {
      label: 'Dean & System Admin',
      icon: Users2,
      badgeClass:
        'bg-rose-100 text-rose-800 border-rose-200 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-900',
      title: 'Campus RBAC & Security Audit Logs',
    },
  };

  const currentRoleMeta = roleMeta[currentUser.role];
  const RoleIcon = currentRoleMeta.icon;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-3">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-navy-800 via-brand-blue to-brand-cyan text-white shadow-md shadow-brand-blue/20">
              <GraduationCap className="h-6 w-6" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="bg-gradient-to-r from-navy-800 to-brand-blue bg-clip-text text-lg font-extrabold tracking-tight text-transparent dark:from-white dark:to-brand-cyan">
                  InternHub
                </span>
                <span className="hidden rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-brand-blue dark:bg-blue-950/60 dark:text-blue-300 sm:inline-flex">
                  Campus Placement Portal
                </span>
              </div>

              <p className="hidden text-[11px] text-slate-400 sm:block">
                Automated Eligibility &amp; Internship Pipeline
              </p>
            </div>
          </div>

          {/* Active role badge */}
          <div className="hidden items-center gap-2 md:flex">
            <div
              className={`flex items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-bold shadow-sm ${currentRoleMeta.badgeClass}`}
              title={currentRoleMeta.title}
            >
              <RoleIcon className="h-4 w-4 shrink-0" />
              <span>{currentRoleMeta.label}</span>
              <span className="hidden text-[10px] font-normal opacity-75 lg:inline">
                • Authenticated Session
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Command palette */}
            <button
              type="button"
              onClick={onOpenCommandPalette}
              className="flex items-center gap-2 rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs text-slate-500 transition-colors hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
              title="Search and commands (Ctrl+K)"
              aria-label="Open command palette"
            >
              <Search className="h-3.5 w-3.5" />
              <span className="hidden lg:inline">Search...</span>
              <kbd className="hidden rounded bg-slate-200 px-1.5 py-0.5 font-mono text-[10px] dark:bg-slate-900 sm:inline-block">
                Ctrl+K
              </kbd>
            </button>

            {/* Theme toggle */}
            <button
              type="button"
              onClick={onToggleDark}
              className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              aria-label="Toggle dark mode"
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDark ? (
                <Sun className="h-4 w-4 text-amber-400" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </button>

            {/* Notifications */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNotifications((prev) => !prev)}
                className="relative rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                aria-label="View notifications"
                aria-expanded={showNotifications}
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 z-50 mt-2 w-80 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 sm:w-96">
                  <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/50 p-3.5 dark:border-slate-800 dark:bg-slate-950/40">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">
                        Notifications
                      </span>
                      {unreadCount > 0 && (
                        <span className="rounded-full bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold text-rose-600 dark:bg-rose-950/60 dark:text-rose-300">
                          {unreadCount} new
                        </span>
                      )}
                    </div>

                    {unreadCount > 0 && (
                      <button
                        type="button"
                        onClick={onMarkAllNotificationsRead}
                        className="flex items-center gap-1 text-xs text-brand-blue hover:underline"
                      >
                        <CheckCheck className="h-3.5 w-3.5" />
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        No notifications yet.
                      </div>
                    ) : (
                      notifications.slice(0, 10).map((notification) => (
                        <div
                          key={notification.id}
                          onClick={() => {
                            onMarkNotificationRead(notification.id);

                            if (notification.linkTab && onNavigateTab) {
                              onNavigateTab(notification.linkTab);
                              setShowNotifications(false);
                            }
                          }}
                          className={`cursor-pointer p-3 text-xs transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60 ${
                            !notification.read
                              ? 'bg-blue-50/40 dark:bg-blue-950/20'
                              : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <span className="font-semibold text-slate-800 dark:text-slate-200">
                              {notification.title}
                            </span>
                            <span className="shrink-0 text-[10px] text-slate-400">
                              {new Date(
                                notification.createdAt
                              ).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric',
                              })}
                            </span>
                          </div>

                          <p className="mt-0.5 line-clamp-2 text-slate-600 dark:text-slate-400">
                            {notification.message}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Reset demo data */}
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-rose-50 hover:text-rose-600 dark:text-slate-400 dark:hover:bg-rose-950/30 dark:hover:text-rose-400"
              title="Reset all demo data back to clean initial state"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span className="hidden xl:inline">Reset Demo</span>
            </button>

            {/* Current user */}
            <div className="flex items-center gap-2 border-l border-slate-200 pl-2 dark:border-slate-800">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-8 w-8 rounded-full object-cover ring-2 ring-brand-blue/30"
              />

              <div className="hidden text-left lg:block">
                <div className="text-xs font-semibold leading-tight text-slate-900 dark:text-white">
                  {currentUser.name}
                </div>
                <div className="text-[10px] font-medium leading-tight text-slate-400">
                  {currentUser.email}
                </div>
              </div>
            </div>

            {/* Sign out */}
            <button
              type="button"
              onClick={() => setShowLogoutConfirm(true)}
              className="flex items-center gap-1.5 rounded-xl border border-slate-200/80 bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-700 transition-colors hover:bg-rose-50 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-950/40 dark:hover:text-rose-300"
              title="Log out from current portal session"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </div>

      {/* Reset confirmation modal */}
      <Modal
        isOpen={showResetConfirm}
        onClose={() => setShowResetConfirm(false)}
        title="Reset Demo Data?"
        description="This will restore all students, companies, internships, applications, and documents to their clean initial state."
        maxWidth="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Use this anytime to restore the canonical worked examples (e.g.
            Demo Student verified profile, NexaTech internships, and initial
            applicant rankings).
          </p>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowResetConfirm(false)}
              className="rounded-xl px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={() => {
                setShowResetConfirm(false);
                onResetData();
              }}
              className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-rose-700"
            >
              Confirm Reset
            </button>
          </div>
        </div>
      </Modal>

      {/* Logout confirmation modal */}
      <Modal
        isOpen={showLogoutConfirm}
        onClose={() => setShowLogoutConfirm(false)}
        title="Sign Out of InternHub?"
        description="Terminate current authenticated session and return to Login Gateway"
        maxWidth="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-400">
            You will be signed out from your active{' '}
            <strong className="text-slate-900 dark:text-white">
              {currentUser.role}
            </strong>{' '}
            session ({currentUser.email}).
          </p>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowLogoutConfirm(false)}
              className="rounded-xl px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Stay Logged In
            </button>

            <button
              type="button"
              onClick={() => {
                setShowLogoutConfirm(false);
                void onLogout();
              }}
              className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-rose-700"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Confirm Sign Out</span>
            </button>
          </div>
        </div>
      </Modal>
    </header>
  );
};

export default Navbar;

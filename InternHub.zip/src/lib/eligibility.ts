import { Student, EligibilityCriteria, EligibilityResult, AcademicRecord } from '@/types';

function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Standard known skills catalog for extraction and matching.
 */
export const KNOWN_SKILLS = [
  'Java', 'Python', 'C++', 'C#', 'C', 'JavaScript', 'TypeScript', 'SQL',
  'PostgreSQL', 'MySQL', 'MongoDB', 'React', 'Angular', 'Vue.js', 'Next.js',
  'Node.js', 'Express', 'Spring Boot', 'Hibernate', 'Docker', 'Kubernetes',
  'AWS', 'Azure', 'GCP', 'Git', 'GitHub', 'Linux', 'REST API', 'GraphQL',
  'Machine Learning', 'Deep Learning', 'Data Science', 'Data Structures',
  'Algorithms', 'DBMS', 'OOP', 'Django', 'Flask', 'Pandas', 'NumPy',
  'TensorFlow', 'PyTorch', 'Tailwind CSS', 'Bootstrap', 'HTML', 'CSS',
  'Cybersecurity', 'Microservices', 'Kafka', 'Redis'
];

/**
 * CORE BUSINESS RULE: Eligibility Engine
 * Compares a Student profile with an Internship's EligibilityCriteria.
 * Returns { eligible: boolean, reasons: string[], fixHints: string[] }.
 */
export function evaluateEligibility(
  student: Student,
  criteria: EligibilityCriteria | null | undefined
): EligibilityResult {
  const reasons: string[] = [];
  const fixHints: string[] = [];

  // Rule 1: Student profile must be verified by faculty.
  if (!student.verified) {
    reasons.push('Student profile has not yet been verified by faculty.');
    fixHints.push('Upload your marksheets and documents, then request faculty approval.');
  }

  if (criteria) {
    // Rule 2: CGPA >= minCgpa
    if (criteria.minCgpa !== undefined && criteria.minCgpa !== null && criteria.minCgpa > 0) {
      if (student.cgpa === undefined || student.cgpa === null || student.cgpa < criteria.minCgpa) {
        reasons.push(`CGPA ${student.cgpa ?? '0.0'} is below the required minimum of ${criteria.minCgpa.toFixed(1)}.`);
        fixHints.push(`Raise your cumulative grade or explore roles accepting CGPA ${student.cgpa ?? 0}+.`);
      }
    }

    // Rule 3: Backlogs <= maxBacklogs
    if (criteria.maxBacklogs !== undefined && criteria.maxBacklogs !== null) {
      if (student.backlogs !== undefined && student.backlogs > criteria.maxBacklogs) {
        reasons.push(`Active backlogs count (${student.backlogs}) exceeds the maximum allowed (${criteria.maxBacklogs}).`);
        fixHints.push('Clear pending backlogs during upcoming remedial or supplementary exam sessions.');
      }
    }

    // Rule 4: Branch is in eligibleBranches (comma list / array, case-insensitive; empty = any)
    if (criteria.eligibleBranches && criteria.eligibleBranches.length > 0) {
      const allowed = criteria.eligibleBranches
        .map(b => b.trim().toUpperCase())
        .filter(Boolean);

      if (allowed.length > 0) {
        const studentBranch = (student.department || '').trim().toUpperCase();
        if (!studentBranch || !allowed.includes(studentBranch)) {
          reasons.push(`Branch "${student.department || 'Unknown'}" is not in the eligible branches list: ${criteria.eligibleBranches.join(', ')}.`);
          fixHints.push(`Target openings designated for ${student.department || 'your'} department or open to all branches.`);
        }
      }
    }

    // Rule 5: Semester equals requiredSemester if set
    if (criteria.requiredSemester !== undefined && criteria.requiredSemester !== null && criteria.requiredSemester > 0) {
      if (student.semester !== criteria.requiredSemester) {
        reasons.push(`Requires semester ${criteria.requiredSemester}, but you are currently in semester ${student.semester}.`);
        fixHints.push(`Check internships that welcome semester ${student.semester} students.`);
      }
    }

    // Rule 6: Student has ALL requiredSkills (matched case-insensitively)
    if (criteria.requiredSkills && criteria.requiredSkills.length > 0) {
      const reqSkills = criteria.requiredSkills
        .map(s => s.trim())
        .filter(Boolean);

      const studentSkillSet = new Set(
        (student.skills || []).map(s => s.name.trim().toUpperCase())
      );

      const missingSkills = reqSkills.filter(
        req => !studentSkillSet.has(req.toUpperCase())
      );

      if (missingSkills.length > 0) {
        reasons.push(`Missing required skills: ${missingSkills.join(', ')}.`);
        fixHints.push(`Update your Skills profile to showcase verified coursework or projects in ${missingSkills.join(', ')}.`);
      }
    }

    // Rule 7: Student has ALL requiredCertifications (matched case-insensitively)
    if (criteria.requiredCertifications && criteria.requiredCertifications.length > 0) {
      const reqCerts = criteria.requiredCertifications
        .map(c => c.trim())
        .filter(Boolean);

      const studentCertSet = new Set(
        (student.certifications || []).map(c => c.trim().toUpperCase())
      );

      const missingCerts = reqCerts.filter(
        req => !studentCertSet.has(req.toUpperCase())
      );

      if (missingCerts.length > 0) {
        reasons.push(`Missing required certifications: ${missingCerts.join(', ')}.`);
        fixHints.push(`Complete the certified credential (${missingCerts.join(', ')}) and add it under Profile.`);
      }
    }
  }

  return {
    eligible: reasons.length === 0,
    reasons,
    fixHints
  };
}

/**
 * Computes Resume Completeness score (0-100) based on standard section coverage and length.
 */
export function calculateResumeCompleteness(rawText: string): number {
  if (!rawText || !rawText.trim()) return 0;
  const upper = rawText.toUpperCase();
  let score = 0;

  if (upper.includes('EDUCATION') || upper.includes('ACADEMIC') || upper.includes('DEGREE')) score += 20;
  if (upper.includes('PROJECT') || upper.includes('PORTFOLIO') || upper.includes('GITHUB')) score += 20;
  if (upper.includes('SKILL') || upper.includes('TECHNOLOGIES') || upper.includes('FRAMEWORKS')) score += 20;
  if (upper.includes('CERTIFICATION') || upper.includes('CERTIFICATE') || upper.includes('COURSE')) score += 15;
  if (upper.includes('EXPERIENCE') || upper.includes('INTERNSHIP') || upper.includes('WORK')) score += 15;
  if (rawText.length > 600) score += 10;

  return Math.min(100, score);
}

/**
 * Extracts skills found in resume as whole words.
 */
export function extractSkillsFromResume(rawText: string, catalog: string[] = KNOWN_SKILLS): string[] {
  if (!rawText || !rawText.trim()) return [];
  const found: string[] = [];

  for (const skill of catalog) {
    // Whole-word boundary search so "Java" doesn't match "JavaScript"
    const regex = new RegExp(`(^|[^a-zA-Z0-9+#.])${escapeRegExp(skill)}(?=[^a-zA-Z0-9+#.]|$)`, 'i');
    if (regex.test(rawText)) {
      found.push(skill);
    }
  }

  return Array.from(new Set(found));
}

/**
 * CORE BUSINESS RULE: Resume Match Score
 * Percent of required skills found as whole words in resume text.
 * Whole word boundary ensures "JavaScript" does NOT satisfy "Java".
 */
export function calculateResumeMatchScore(rawText: string, requiredSkills: string[]): number {
  if (!requiredSkills || requiredSkills.length === 0) return 100;
  if (!rawText || !rawText.trim()) return 0;

  let matched = 0;
  for (const skill of requiredSkills) {
    const trimmed = skill.trim();
    if (!trimmed) continue;
    const regex = new RegExp(`(^|[^a-zA-Z0-9+#.])${escapeRegExp(trimmed)}(?=[^a-zA-Z0-9+#.]|$)`, 'i');
    if (regex.test(rawText)) {
      matched++;
    }
  }

  return Math.round((matched / requiredSkills.length) * 100);
}

/**
 * CORE BUSINESS RULE: Candidate Ranking Score
 * Ranking Score = 0.6 * resumeMatch + 0.4 * ATR
 */
export function calculateCandidateRankingScore(resumeMatchScore: number, atrScore: number | null | undefined): number {
  const resume = Math.max(0, Math.min(100, resumeMatchScore || 0));
  const atr = Math.max(0, Math.min(100, atrScore ?? 0));
  const composite = 0.6 * resume + 0.4 * atr;
  return Math.round(composite * 10) / 10;
}

/**
 * Calculates student cumulative CGPA from academic records.
 */
export function calculateCgpaFromSgpa(records: AcademicRecord[]): number {
  const valid = records.filter(r => r.sgpa !== null && r.sgpa !== undefined && !isNaN(r.sgpa) && r.sgpa > 0);
  if (valid.length === 0) return 0;
  const sum = valid.reduce((acc, curr) => acc + Number(curr.sgpa), 0);
  return Math.round((sum / valid.length) * 100) / 100;
}

/**
 * Live preview statistics for companies when tuning internship criteria.
 */
export function getLivePreviewMatches(
  students: Student[],
  criteria: EligibilityCriteria
): {
  matchCount: number;
  totalStudents: number;
  insights: string[];
} {
  const totalStudents = students.length;
  const currentMatches = students.filter(s => evaluateEligibility(s, criteria).eligible).length;

  const insights: string[] = [];

  // Simulate lowering CGPA by 0.5
  if (criteria.minCgpa > 6.0) {
    const lowerCgpaCrit = { ...criteria, minCgpa: Math.max(6.0, criteria.minCgpa - 0.5) };
    const simulated = students.filter(s => evaluateEligibility(s, lowerCgpaCrit).eligible).length;
    const diff = simulated - currentMatches;
    if (diff > 0) {
      insights.push(`+${diff} more eligible students if you lower minimum CGPA to ${lowerCgpaCrit.minCgpa.toFixed(1)}.`);
    }
  }

  // Simulate allowing 1 backlog
  if (criteria.maxBacklogs === 0) {
    const allowBacklogCrit = { ...criteria, maxBacklogs: 1 };
    const simulated = students.filter(s => evaluateEligibility(s, allowBacklogCrit).eligible).length;
    const diff = simulated - currentMatches;
    if (diff > 0) {
      insights.push(`+${diff} more students if candidates with 1 cleared backlog are accepted.`);
    }
  }

  // Simulate relaxing branch restrictions
  if (criteria.eligibleBranches && criteria.eligibleBranches.length > 0) {
    const allBranchesCrit = { ...criteria, eligibleBranches: [] };
    const simulated = students.filter(s => evaluateEligibility(s, allBranchesCrit).eligible).length;
    const diff = simulated - currentMatches;
    if (diff > 0) {
      insights.push(`+${diff} more applicants if open to all engineering departments.`);
    }
  }

  return {
    matchCount: currentMatches,
    totalStudents,
    insights
  };
}

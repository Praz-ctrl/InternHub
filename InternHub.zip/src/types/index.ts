export type Role = 'STUDENT' | 'FACULTY' | 'COMPANY' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  role: Role;
  name: string;
  avatar?: string;
  enabled: boolean;
  profileId: string;
}

export interface StudentSkill {
  name: string;
  proficiency: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';
}

export interface AcademicRecord {
  id: string;
  studentId: string;
  semester: number;
  subject: string;
  marks: number;
  sgpa: number;
}

export type DocumentType = 'MARKSHEET' | 'RESUME' | 'ID_CARD' | 'CERTIFICATE';
export type VerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

export interface StudentDocument {
  id: string;
  studentId: string;
  documentType: DocumentType;
  fileName: string;
  fileSize: string;
  fileUrl: string;
  verificationStatus: VerificationStatus;
  uploadedAt: string;
  remarks?: string;
}

export interface StudentResume {
  id: string;
  studentId: string;
  rawText: string;
  resumeScore: number;
  extractedSkills: string[];
  fileName?: string;
  updatedAt: string;
  aiFeedback?: string[];
}

export interface Student {
  id: string;
  userId: string;
  name: string;
  prn: string;
  email: string;
  department: string;
  semester: number;
  cgpa: number;
  backlogs: number;
  phone: string;
  internshipPreferences: string;
  certifications: string[];
  projects: string;
  verified: boolean;
  verifiedBy?: string;
  verifiedAt?: string;
  skills: StudentSkill[];
  bookmarkedInternshipIds: string[];
}

export interface Company {
  id: string;
  userId: string;
  companyName: string;
  industry: string;
  location: string;
  website: string;
  contact: string;
  logo?: string;
}

export interface Faculty {
  id: string;
  userId: string;
  name: string;
  department: string;
  designation: string;
  email: string;
}

export interface EligibilityCriteria {
  minCgpa: number;
  maxBacklogs: number;
  eligibleBranches: string[]; // empty array means any branch
  requiredSkills: string[];
  requiredCertifications: string[];
  requiredSemester?: number | null;
  minResumeScore?: number | null;
  minAtrScore?: number | null;
}

export type InterviewStage = 'APTITUDE_TEST' | 'CODING_TEST' | 'TECHNICAL' | 'HR' | 'GROUP_DISCUSSION';
export type InternshipStatus = 'PENDING_APPROVAL' | 'OPEN' | 'CLOSED' | 'REJECTED';
export type WorkMode = 'REMOTE' | 'HYBRID' | 'ONSITE';

export interface Internship {
  id: string;
  companyId: string;
  company: Company;
  role: string;
  description: string;
  duration: string;
  stipend: number;
  location: string;
  workMode: WorkMode;
  vacancies: number;
  deadline: string; // YYYY-MM-DD
  interviewStages: InterviewStage[];
  status: InternshipStatus;
  criteria: EligibilityCriteria;
  createdAt: string;
}

export type ApplicationStatus =
  | 'APPLIED'
  | 'RESUME_SCORED'
  | 'FACULTY_SHORTLISTED'
  | 'COMPANY_SHORTLISTED'
  | 'INTERVIEW_SCHEDULED'
  | 'SELECTED'
  | 'REJECTED'
  | 'WITHDRAWN';

export interface Interview {
  id: string;
  applicationId: string;
  round: number;
  type: InterviewStage;
  scheduledDate: string; // ISO
  mode: 'ONLINE' | 'OFFLINE';
  result: 'PENDING' | 'PASS' | 'FAIL';
  remarks?: string;
}

export interface Assessment {
  id: string;
  applicationId: string;
  atrScore: number | null;
  aptitudeScore: number | null;
  codingScore: number | null;
  updatedAt: string;
}

export type OfferStatus = 'EXTENDED' | 'ACCEPTED' | 'DECLINED';

export interface Offer {
  id: string;
  applicationId: string;
  studentId: string;
  companyId: string;
  status: OfferStatus;
  offerDate: string;
  stipend: number;
  validUntil: string;
  letterText?: string;
}

export interface InternshipApplication {
  id: string;
  internshipId: string;
  studentId: string;
  student: Student;
  internship: Internship;
  applicationDate: string;
  status: ApplicationStatus;
  resumeMatchScore: number;
  assessment?: Assessment;
  interviews: Interview[];
  offer?: Offer;
  rejectionReason?: string;
}

export type NotificationType =
  | 'VERIFICATION'
  | 'APPLICATION'
  | 'SHORTLIST'
  | 'INTERVIEW'
  | 'INTERVIEW_RESULT'
  | 'SELECTION'
  | 'OFFER'
  | 'CRITERIA_MATCH'
  | 'SYSTEM';

export interface NotificationItem {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  linkTab?: string;
}

export interface EligibilityResult {
  eligible: boolean;
  reasons: string[];
  fixHints: string[];
}

export interface RankedCandidate {
  application: InternshipApplication;
  resumeMatchScore: number;
  atrScore: number | null;
  compositeScore: number;
}

export type AuditEventStatus = 'SUCCESS' | 'BLOCKED' | 'WARNING';

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userEmail: string;
  userRole: Role;
  action: string;
  details: string;
  status: AuditEventStatus;
  resourceId?: string;
  ipAddress?: string;
}

export interface AuthSession {
  token: string;
  user: User;
  issuedAt: number;
  expiresAt: number;
  signature: string;
}

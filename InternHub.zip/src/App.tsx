import React, { useState, useEffect, useCallback } from 'react';
import { NotificationItem } from '@/types';
import { api } from '@/services/api';
import { ToastProvider, useToast } from '@/components/Toast';
import { AuthProvider, useAuth } from '@/core/auth/useAuth';
import { RoleGuard } from '@/core/guards/RoleGuard';
import { ProtectedRoute } from '@/core/guards/ProtectedRoute';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { LoginPage } from '@/pages/LoginPage';
import { StudentDashboard } from '@/pages/StudentDashboard';
import { FacultyDashboard } from '@/pages/FacultyDashboard';
import { CompanyDashboard } from '@/pages/CompanyDashboard';
import { AdminDashboard } from '@/pages/AdminDashboard';
import { GraduationCap } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { success, error } = useToast();
  const { currentUser, isLoading, switchUser, refreshSession } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [currentNavTab, setCurrentNavTab] = useState<string>('');
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem('internhub_theme') === 'dark' ||
        (!localStorage.getItem('internhub_theme') &&
          window.matchMedia('(prefers-color-scheme: dark)').matches)
      );
    }
    return false;
  });

  // Sync theme
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('internhub_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('internhub_theme', 'light');
    }
  }, [isDark]);

  // Load user notifications whenever currentUser changes
  const loadNotifications = useCallback(async () => {
    if (currentUser) {
      try {
        const notifs = await api.getMyNotifications(currentUser.id);
        setNotifications(notifs);
      } catch {
        setNotifications([]);
      }
    } else {
      setNotifications([]);
    }
  }, [currentUser]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const handleResetData = async () => {
    try {
      await api.resetDemoData();
      await refreshSession();
      setNotifications([]);
      success('Demo data restored to initial clean state!', 'All student, faculty, and company records refreshed.');
    } catch (err: any) {
      error('Reset failed', err.message);
    }
  };

  const handleMarkNotificationRead = async (id: string) => {
    await api.markNotificationRead(id);
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const handleMarkAllNotificationsRead = async () => {
    if (currentUser) {
      await api.markAllNotificationsRead(currentUser.id);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      success('All notifications marked as read.');
    }
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-brand-blue flex items-center justify-center text-white animate-spin shadow-lg shadow-brand-blue/30">
            <GraduationCap className="w-6 h-6" />
          </div>
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            Verifying 7-Layer Campus Security &amp; Token Integrity...
          </span>
        </div>
      </div>
    );
  }

  // TIER 1 LOGIN FIRST: If unauthenticated, show Login Page only
  if (!currentUser) {
    return (
      <LoginPage
        onLoginSuccess={() => refreshSession()}
        isDark={isDark}
        onToggleDark={() => setIsDark(prev => !prev)}
        onResetData={handleResetData}
      />
    );
  }

  // TIER 2 & 3: Authenticated Dashboard within Protected Route and RoleGuard
  return (
    <ProtectedRoute>
      <DashboardLayout
        notifications={notifications}
        onMarkNotificationRead={handleMarkNotificationRead}
        onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
        onResetData={handleResetData}
        isDark={isDark}
        onToggleDark={() => setIsDark(prev => !prev)}
        currentNavTab={currentNavTab}
        onNavigateTab={tab => setCurrentNavTab(tab)}
      >
        {/* Layer 2 Role Guard: Strictly isolates student dashboard */}
        {currentUser.role === 'STUDENT' && (
          <RoleGuard
            requiredRole="STUDENT"
            onNavigateHome={() => setCurrentNavTab('')}
          >
            <StudentDashboard
              currentUser={currentUser}
              initialTab={currentNavTab || 'browse'}
            />
          </RoleGuard>
        )}

        {/* Layer 2 Role Guard: Strictly isolates faculty dashboard */}
        {currentUser.role === 'FACULTY' && (
          <RoleGuard
            requiredRole="FACULTY"
            onNavigateHome={() => setCurrentNavTab('')}
          >
            <FacultyDashboard
              currentUser={currentUser}
              initialTab={currentNavTab || 'verification'}
            />
          </RoleGuard>
        )}

        {/* Layer 2 Role Guard: Strictly isolates company dashboard */}
        {currentUser.role === 'COMPANY' && (
          <RoleGuard
            requiredRole="COMPANY"
            onNavigateHome={() => setCurrentNavTab('')}
          >
            <CompanyDashboard
              currentUser={currentUser}
              initialTab={currentNavTab || 'post'}
            />
          </RoleGuard>
        )}

        {/* Layer 2 Role Guard: Strictly isolates admin dashboard */}
        {currentUser.role === 'ADMIN' && (
          <RoleGuard
            requiredRole="ADMIN"
            onNavigateHome={() => setCurrentNavTab('')}
          >
            <AdminDashboard
              currentUser={currentUser}
              onSwitchUser={switchUser}
              onResetData={handleResetData}
            />
          </RoleGuard>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  );
};

export const App: React.FC = () => {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainAppContent />
      </AuthProvider>
    </ToastProvider>
  );
};

export default App;

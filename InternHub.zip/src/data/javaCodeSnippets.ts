export interface AcademicConceptItem {
  id: string;
  name: string;
  category: 'OOP Core' | 'Design Patterns' | 'Java Language Features' | 'Enterprise Architecture';
  fileName: string;
  filePath: string;
  summary: string;
  rubricCriterion: string;
  codeSnippet: string;
}

export const ACADEMIC_CONCEPTS_MAP: AcademicConceptItem[] = [
  {
    id: 'encapsulation',
    name: 'Encapsulation & Data Hiding',
    category: 'OOP Core',
    fileName: 'Student.java',
    filePath: 'backend-java/src/main/java/com/internhub/model/Student.java',
    summary: 'Private fields with controlled getter/setter access, parameter boundaries, and defensive encapsulation of critical academic metrics (CGPA, backlogs, PRN).',
    rubricCriterion: 'Enforces strict data integrity and prevents direct mutation of model state from external layers.',
    codeSnippet: `@Entity
@Table(name = "students")
public class Student extends BaseEntity {

    @Column(nullable = false, unique = true)
    private String prn;

    private double cgpa;
    private int backlogs;
    private boolean verified = false;

    // Encapsulated getters & setters with validation invariants
    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) {
        if (cgpa < 0.0 || cgpa > 10.0) {
            throw new IllegalArgumentException("CGPA must be between 0.0 and 10.0");
        }
        this.cgpa = cgpa;
    }
}`
  },
  {
    id: 'inheritance',
    name: 'Inheritance & Mapped Superclass',
    category: 'OOP Core',
    fileName: 'BaseEntity.java',
    filePath: 'backend-java/src/main/java/com/internhub/model/BaseEntity.java',
    summary: 'Abstract BaseEntity with common primary key, audit timestamps (createdAt, updatedAt), and optimistic locking version field inherited by all models.',
    rubricCriterion: 'Code reuse across User, Student, Internship, and Application entities via object-oriented class inheritance.',
    codeSnippet: `@MappedSuperclass
public abstract class BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Version
    private Long version; // Optimistic locking

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
}`
  },
  {
    id: 'polymorphism_dynamic',
    name: 'Dynamic Polymorphism (Interface Dispatch)',
    category: 'OOP Core',
    fileName: 'EligibilityRule.java & Rules',
    filePath: 'backend-java/src/main/java/com/internhub/service/rules/EligibilityRule.java',
    summary: 'EligibilityRule interface implemented by CgpaEligibilityRule, BacklogsEligibilityRule, DepartmentEligibilityRule, etc., evaluated polymorphically.',
    rubricCriterion: 'Dynamic runtime method dispatch allows injecting rules without modifying the evaluation engine.',
    codeSnippet: `public interface EligibilityRule {
    Optional<String> validate(Student student, EligibilityCriteria criteria);
    String getRuleName();
}

// In EligibilityService.java:
public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria) {
    List<String> violations = rules.stream()
            .map(rule -> rule.validate(student, criteria)) // Dynamic polymorphic dispatch
            .filter(Optional::isPresent)
            .map(Optional::get)
            .collect(Collectors.toList());
}`
  },
  {
    id: 'polymorphism_static',
    name: 'Static Polymorphism (Method Overloading)',
    category: 'OOP Core',
    fileName: 'EligibilityService.java',
    filePath: 'backend-java/src/main/java/com/internhub/service/EligibilityService.java',
    summary: 'Compile-time polymorphism with overloaded method signatures for standard vs dean-override evaluation and multi-channel notifications.',
    rubricCriterion: 'Overloaded method signatures resolved statically by the compiler based on argument types and counts.',
    codeSnippet: `// Overload 1: Standard rule evaluation
public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria) {
    // Standard rule evaluation
}

// Overload 2: Overload with placement dean override bypass
public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria, boolean deanOverride) {
    if (deanOverride) {
        return new EligibilityResult.Builder().eligible(true).build();
    }
    return evaluateEligibility(student, criteria);
}`
  },
  {
    id: 'strategy_pattern',
    name: 'Strategy Pattern (Behavioral Design Pattern)',
    category: 'Design Patterns',
    fileName: 'RankingStrategy.java',
    filePath: 'backend-java/src/main/java/com/internhub/service/strategy/RankingStrategy.java',
    summary: 'Family of interchangeable candidate scoring algorithms (CompositeRankingStrategy, CgpaWeightedRankingStrategy, AtsWeightedRankingStrategy).',
    rubricCriterion: 'Open/Closed Principle (SOLID) - allows adding new company ranking criteria without modifying client invocation code.',
    codeSnippet: `public interface RankingStrategy {
    double calculateScore(Student student, double atsResumeScore, double assessmentScore);
    String getStrategyName();
}

@Component("compositeRankingStrategy")
public class CompositeRankingStrategy implements RankingStrategy {
    @Override
    public double calculateScore(Student student, double ats, double assessment) {
        double cgpa = (student != null) ? student.getCgpa() * 10.0 : 0.0;
        return (ats * 0.40) + (assessment * 0.40) + (cgpa * 0.20);
    }
}`
  },
  {
    id: 'builder_pattern',
    name: 'Builder Pattern (Creational Design Pattern)',
    category: 'Design Patterns',
    fileName: 'EligibilityService.java & ApiResponse.java',
    filePath: 'backend-java/src/main/java/com/internhub/dto/ApiResponse.java',
    summary: 'Step-by-step fluent object construction pattern providing immutability for evaluation results and generic REST envelopes.',
    rubricCriterion: 'Decouples construction of complex objects with multiple optional parameters from their representations.',
    codeSnippet: `public static class Builder<T> {
    private boolean success = true;
    private String message;
    private T data;
    private String errorCode;

    public Builder<T> success(boolean s) { this.success = s; return this; }
    public Builder<T> data(T data) { this.data = data; return this; }
    public ApiResponse<T> build() { return new ApiResponse<>(this); }
}

// Fluent usage:
ApiResponse<StudentDTO> response = new ApiResponse.Builder<StudentDTO>()
        .success(true)
        .data(dto)
        .message("Profile retrieved")
        .build();`
  },
  {
    id: 'factory_pattern',
    name: 'Factory Method Pattern (Creational Design Pattern)',
    category: 'Design Patterns',
    fileName: 'NotificationFactory.java',
    filePath: 'backend-java/src/main/java/com/internhub/service/factory/NotificationFactory.java',
    summary: 'Encapsulates complex instantiation logic for system alerts, security warnings, and interview invitation notification objects.',
    rubricCriterion: 'Centralizes object creation, shielding client services from concrete construction details.',
    codeSnippet: `@Component
public class NotificationFactory {
    public Notification createSecurityAlert(User recipient, String suspiciousAction) {
        return createNotification(recipient, "Security Alert",
                "Suspicious activity detected: " + suspiciousAction, "SECURITY");
    }

    public Notification createInterviewInvite(User recipient, String companyName, String roundName) {
        return createNotification(recipient, "Interview Scheduled",
                companyName + " scheduled round: " + roundName, "INTERVIEW");
    }
}`
  },
  {
    id: 'observer_pattern',
    name: 'Observer Pattern & Event-Driven Architecture',
    category: 'Design Patterns',
    fileName: 'ApplicationEventListener.java',
    filePath: 'backend-java/src/main/java/com/internhub/event/ApplicationEventListener.java',
    summary: 'Decoupled event publishing when an application status updates, automatically triggering asynchronous notification handling.',
    rubricCriterion: 'Decouples core business transactions from secondary side-effects (push notifications, SMS, email).',
    codeSnippet: `// Event Publisher in ApplicationService:
eventPublisher.publishEvent(new ApplicationStatusChangedEvent(this, appId, studentId, internshipId, oldStatus, newStatus));

// Event Consumer / Observer:
@Component
public class ApplicationEventListener {
    @Async
    @EventListener
    public void handleApplicationStatusChange(ApplicationStatusChangedEvent event) {
        notificationService.sendNotification(
            event.getStudentId(), "Application Updated",
            "Status moved to " + event.getNewStatus(), "APPLICATION"
        );
    }
}`
  },
  {
    id: 'streams_lambdas',
    name: 'Stream API & Functional Lambdas',
    category: 'Java Language Features',
    fileName: 'CandidateRankingService.java',
    filePath: 'backend-java/src/main/java/com/internhub/service/CandidateRankingService.java',
    summary: 'Declarative stream pipelines using filter(), map(), sorted(), and Collectors to rank applicants without imperative loops.',
    rubricCriterion: 'Demonstrates modern Java 8+ functional programming, comparator combinators, and stream terminal collectors.',
    codeSnippet: `public List<Application> rankApplications(List<Application> applications, String strategyName) {
    return applications.stream()
            .filter(app -> app != null && app.getStudent() != null)
            .sorted(Comparator.comparingDouble((Application app) -> {
                double ats = app.getAtsScore() != null ? app.getAtsScore() : 0.0;
                double assessment = app.getAssessmentScore() != null ? app.getAssessmentScore() : 0.0;
                return calculateCompositeScore(app.getStudent(), ats, assessment, strategyName);
            }).reversed())
            .collect(Collectors.toList());
}`
  },
  {
    id: 'generics',
    name: 'Generics (<T>) Type Safety',
    category: 'Java Language Features',
    fileName: 'ApiResponse.java',
    filePath: 'backend-java/src/main/java/com/internhub/dto/ApiResponse.java',
    summary: 'Generic wrapper envelope providing compile-time type safety for arbitrary API payloads while eliminating runtime ClassCastException risks.',
    rubricCriterion: 'Type-safe container pattern utilizing generic type parameters and generic factory methods.',
    codeSnippet: `public class ApiResponse<T> {
    private final boolean success;
    private final String message;
    private final T data; // Generic payload type
    private final String errorCode;

    public static <T> ApiResponse<T> success(T data, String message) {
        return new Builder<T>().success(true).data(data).message(message).build();
    }
}`
  },
  {
    id: 'exception_handling',
    name: 'Structured Exceptions & @RestControllerAdvice',
    category: 'Enterprise Architecture',
    fileName: 'GlobalExceptionHandler.java',
    filePath: 'backend-java/src/main/java/com/internhub/exception/GlobalExceptionHandler.java',
    summary: 'Hierarchy of custom domain exceptions intercepted by centralized Spring Controller Advice to yield standardized HTTP status codes.',
    rubricCriterion: 'Cross-cutting exception handling avoiding try-catch clutter inside business controllers.',
    codeSnippet: `@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse<Object>> handleNotFound(ResourceNotFoundException ex) {
        return new ResponseEntity<>(ApiResponse.error(ex.getMessage(), ex.getErrorCode()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ApiResponse<Object>> handleValidation(ValidationException ex) {
        return new ResponseEntity<>(ApiResponse.error(ex.getMessage(), ex.getErrorCode()), HttpStatus.BAD_REQUEST);
    }
}`
  },
  {
    id: 'concurrency',
    name: 'Concurrency & Asynchronous Tasks (@Async)',
    category: 'Enterprise Architecture',
    fileName: 'NotificationService.java',
    filePath: 'backend-java/src/main/java/com/internhub/service/NotificationService.java',
    summary: 'Non-blocking notification delivery using Spring @Async and CompletableFuture<T> on dedicated thread pool executor.',
    rubricCriterion: 'Main HTTP request thread returns instantly while long-running I/O processes complete concurrently in background.',
    codeSnippet: `@Async
public CompletableFuture<Notification> sendNotification(Long studentId, String title, String message, String type) {
    Optional<Student> studentOpt = studentRepository.findById(studentId);
    if (studentOpt.isPresent()) {
        Notification n = notificationFactory.createNotification(studentOpt.get().getUser(), title, message, type);
        Notification saved = notificationRepository.save(n);
        return CompletableFuture.completedFuture(saved);
    }
    return CompletableFuture.completedFuture(null);
}`
  }
];

export const JAVA_CODE_SNIPPETS: Record<string, string> = {
  'EligibilityService.java': `package com.internhub.service;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import com.internhub.service.rules.EligibilityRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Concept: MULTI-TIER SERVICE LAYER, BUILDER PATTERN, STREAM API & RUNTIME POLYMORPHISM
 * Orchestrates campus eligibility verification via dynamically injected polymorphic rules.
 */
@Service
public class EligibilityService {

    private final List<EligibilityRule> rules;

    @Autowired
    public EligibilityService(List<EligibilityRule> rules) {
        this.rules = rules != null ? rules : Collections.emptyList();
    }

    /**
     * Concept: BUILDER PATTERN & IMMUTABILITY
     */
    public static class EligibilityResult {
        private final boolean eligible;
        private final List<String> reasons;

        private EligibilityResult(Builder builder) {
            this.eligible = builder.eligible;
            this.reasons = Collections.unmodifiableList(builder.reasons);
        }

        public boolean isEligible() { return eligible; }
        public List<String> getReasons() { return reasons; }

        public static class Builder {
            private boolean eligible = true;
            private List<String> reasons = new ArrayList<>();

            public Builder eligible(boolean eligible) {
                this.eligible = eligible;
                return this;
            }

            public Builder addReason(String reason) {
                this.reasons.add(reason);
                this.eligible = false;
                return this;
            }

            public Builder addReasons(List<String> reasons) {
                if (reasons != null && !reasons.isEmpty()) {
                    this.reasons.addAll(reasons);
                    this.eligible = false;
                }
                return this;
            }

            public EligibilityResult build() {
                return new EligibilityResult(this);
            }
        }
    }

    /**
     * Core Method: Polymorphic validation via rule list
     */
    public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria) {
        if (student == null) {
            return new EligibilityResult.Builder()
                    .addReason("Student profile record does not exist")
                    .build();
        }

        // Stream through polymorphic rules and collect all failure reasons
        List<String> violations = rules.stream()
                .map(rule -> rule.validate(student, criteria))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());

        EligibilityResult.Builder builder = new EligibilityResult.Builder();
        if (violations.isEmpty()) {
            builder.eligible(true);
        } else {
            builder.addReasons(violations);
        }

        return builder.build();
    }

    /**
     * Concept: METHOD OVERLOADING (Static Polymorphism)
     * Overloaded method with additional bypass flag for placement dean emergency overrides
     */
    public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria, boolean deanOverride) {
        if (deanOverride) {
            return new EligibilityResult.Builder().eligible(true).build();
        }
        return evaluateEligibility(student, criteria);
    }
}`,

  'CandidateRankingService.java': `package com.internhub.service;

import com.internhub.model.Application;
import com.internhub.model.Student;
import com.internhub.service.strategy.RankingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Concept: SERVICE LAYER, STRATEGY PATTERN & STREAM API
 * Evaluates candidate scores dynamically using injected strategy implementations
 * and ranks candidates using Java 8+ Streams and Lambda expressions.
 */
@Service
public class CandidateRankingService {

    private final Map<String, RankingStrategy> strategyMap;
    private final RankingStrategy defaultStrategy;

    @Autowired
    public CandidateRankingService(List<RankingStrategy> strategies) {
        this.strategyMap = new HashMap<>();
        for (RankingStrategy s : strategies) {
            this.strategyMap.put(s.getStrategyName().toUpperCase(), s);
        }
        this.defaultStrategy = strategyMap.getOrDefault("COMPOSITE_BALANCED", strategies.get(0));
    }

    public double calculateCompositeScore(double resumeMatchScore, double assessmentScore) {
        return defaultStrategy.calculateScore(null, resumeMatchScore, assessmentScore);
    }

    public double calculateCompositeScore(Student student, double resumeMatchScore, double assessmentScore, String strategyName) {
        RankingStrategy strategy = strategyMap.getOrDefault(
                strategyName != null ? strategyName.toUpperCase() : "COMPOSITE_BALANCED",
                defaultStrategy
        );
        return strategy.calculateScore(student, resumeMatchScore, assessmentScore);
    }

    public List<Application> rankApplications(List<Application> applications, String strategyName) {
        if (applications == null || applications.isEmpty()) {
            return Collections.emptyList();
        }

        return applications.stream()
                .filter(app -> app != null && app.getStudent() != null)
                .sorted(Comparator.comparingDouble((Application app) -> {
                    double atsScore = app.getAtsScore() != null ? app.getAtsScore() : 0.0;
                    double assessmentScore = app.getAssessmentScore() != null ? app.getAssessmentScore() : 0.0;
                    return calculateCompositeScore(app.getStudent(), atsScore, assessmentScore, strategyName);
                }).reversed())
                .collect(Collectors.toList());
    }
}`,

  'RankingStrategy.java': `package com.internhub.service.strategy;

import com.internhub.model.Student;

/**
 * Concept: STRATEGY PATTERN & POLYMORPHISM (Runtime Dynamic Dispatch)
 * Defines algorithm contract for calculating candidate ranking scores.
 */
public interface RankingStrategy {
    double calculateScore(Student student, double atsResumeScore, double assessmentScore);
    String getStrategyName();
}`,

  'EligibilityRule.java': `package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import java.util.Optional;

/**
 * Concept: INTERFACE ABSTRACTION & POLYMORPHISM (Rules Engine Pattern)
 */
public interface EligibilityRule {
    Optional<String> validate(Student student, EligibilityCriteria criteria);
    String getRuleName();
}`,

  'NotificationFactory.java': `package com.internhub.service.factory;

import com.internhub.model.Notification;
import com.internhub.model.User;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;

/**
 * Concept: FACTORY METHOD PATTERN (Creational Pattern)
 */
@Component
public class NotificationFactory {

    public Notification createNotification(User recipient, String title, String message, String type) {
        Notification notification = new Notification();
        notification.setUser(recipient);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(type != null ? type.toUpperCase() : "GENERAL");
        notification.setRead(false);
        notification.setCreatedAt(LocalDateTime.now());
        return notification;
    }

    public Notification createSecurityAlert(User recipient, String suspiciousAction) {
        return createNotification(recipient, "Security Alert",
                "Suspicious activity detected: " + suspiciousAction, "SECURITY");
    }

    public Notification createInterviewInvite(User recipient, String companyName, String roundName) {
        return createNotification(recipient, "Interview Scheduled",
                companyName + " scheduled round: " + roundName, "INTERVIEW");
    }
}`,

  'ApplicationEventListener.java': `package com.internhub.event;

import com.internhub.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Concept: OBSERVER CONSUMER & ASYNCHRONOUS CONCURRENCY (@Async)
 */
@Component
public class ApplicationEventListener {

    @Autowired
    private NotificationService notificationService;

    @Async
    @EventListener
    public void handleApplicationStatusChange(ApplicationStatusChangedEvent event) {
        String message = String.format("Application (#%d) transitioned to %s.",
                event.getApplicationId(), event.getNewStatus().name());
        notificationService.sendNotification(event.getStudentId(), "Application Status Updated", message, "APPLICATION");
    }
}`,

  'BaseEntity.java': `package com.internhub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Concept: INHERITANCE & ABSTRACTION
 */
@MappedSuperclass
public abstract class BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Version
    private Long version;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public Long getVersion() { return version; }
}`,

  'ApiResponse.java': `package com.internhub.dto;

import java.time.LocalDateTime;

/**
 * Concept: GENERICS (<T>) & BUILDER PATTERN
 */
public class ApiResponse<T> {

    private final boolean success;
    private final String message;
    private final T data;
    private final String errorCode;
    private final LocalDateTime timestamp;

    private ApiResponse(Builder<T> builder) {
        this.success = builder.success;
        this.message = builder.message;
        this.data = builder.data;
        this.errorCode = builder.errorCode;
        this.timestamp = LocalDateTime.now();
    }

    public static <T> ApiResponse<T> success(T data, String message) {
        return new Builder<T>().success(true).message(message).data(data).build();
    }

    public static <T> ApiResponse<T> error(String message, String errorCode) {
        return new Builder<T>().success(false).message(message).errorCode(errorCode).build();
    }

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public T getData() { return data; }
    public String getErrorCode() { return errorCode; }

    public static class Builder<T> {
        private boolean success = true;
        private String message;
        private T data;
        private String errorCode;

        public Builder<T> success(boolean s) { this.success = s; return this; }
        public Builder<T> message(String m) { this.message = m; return this; }
        public Builder<T> data(T d) { this.data = d; return this; }
        public Builder<T> errorCode(String c) { this.errorCode = c; return this; }
        public ApiResponse<T> build() { return new ApiResponse<>(this); }
    }
}`,

  'GlobalExceptionHandler.java': `package com.internhub.exception;

import com.internhub.dto.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Concept: GLOBAL EXCEPTION HANDLING & CROSS-CUTTING CONCERN
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse<Object>> handleNotFound(ResourceNotFoundException ex) {
        ApiResponse<Object> response = ApiResponse.error(ex.getMessage(), ex.getErrorCode());
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ApiResponse<Object>> handleValidation(ValidationException ex) {
        ApiResponse<Object> response = ApiResponse.error(ex.getMessage(), ex.getErrorCode());
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Object>> handleGeneral(Exception ex) {
        ApiResponse<Object> response = ApiResponse.error(ex.getMessage(), "ERR_INTERNAL");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}`,

  'Student.java': `package com.internhub.model;

import jakarta.persistence.*;

/**
 * Concept: ENCAPSULATION & JPA ENTITY MAPPING
 */
@Entity
@Table(name = "students")
public class Student extends BaseEntity {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String prn;

    @Column(nullable = false)
    private String department;

    private int semester;
    private double cgpa;
    private int backlogs;
    private String phone;
    private boolean verified = false;

    public Student() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPrn() { return prn; }
    public void setPrn(String prn) { this.prn = prn; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }
    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }
    public int getBacklogs() { return backlogs; }
    public void setBacklogs(int backlogs) { this.backlogs = backlogs; }
    public boolean isVerified() { return verified; }
    public void setVerified(boolean verified) { this.verified = verified; }
}`,

  'AuthController.java': `package com.internhub.controller;

import com.internhub.model.User;
import com.internhub.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Concept: CONTROLLER LAYER & AUTHENTICATION ENDPOINTS
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> creds) {
        Optional<User> userOpt = authService.authenticate(creds.get("email"), creds.get("password"));
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "Invalid email or password"));
        }

        User user = userOpt.get();
        Long profileId = authService.resolveProfileId(user);
        String token = "jwt_token_" + user.getId() + "_" + System.currentTimeMillis();

        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("accessToken", token);
        response.put("email", user.getEmail());
        response.put("role", user.getRole().name());
        response.put("profileId", profileId);

        return ResponseEntity.ok(response);
    }
}`,

  'pom.xml': `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.3</version>
        <relativePath/>
    </parent>
    <groupId>com.internhub</groupId>
    <artifactId>internhub-portal-backend</artifactId>
    <version>1.0.0</version>
    <name>InternHub Enterprise Portal Backend</name>
    <description>Enterprise Layered Java Spring Boot Backend for InternHub</description>

    <properties>
        <java.version>17</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>
    </dependencies>
</project>`
};

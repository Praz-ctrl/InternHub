package com.internhub.exception;

import org.springframework.http.HttpStatus;

/**
 * Concept: SPECIALIZED EXCEPTION (Inheritance & Security)
 * Thrown when RBAC check fails or an IDOR attempt is detected.
 */
public class UnauthorizedAccessException extends BaseAppException {

    public UnauthorizedAccessException(String message) {
        super(message, HttpStatus.FORBIDDEN, "ERR_FORBIDDEN_ACCESS");
    }
}

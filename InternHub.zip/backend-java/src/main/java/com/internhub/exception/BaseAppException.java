package com.internhub.exception;

import org.springframework.http.HttpStatus;

/**
 * Concept: INHERITANCE IN EXCEPTION HIERARCHY
 * Root unchecked exception for all domain-specific application errors.
 *
 * Marks Criteria:
 * - Exception Handling: Structured custom exceptions extending RuntimeException
 * - Encapsulation: HttpStatus and error code tied directly to exception
 */
public abstract class BaseAppException extends RuntimeException {

    private final HttpStatus status;
    private final String errorCode;

    public BaseAppException(String message, HttpStatus status, String errorCode) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
    }

    public BaseAppException(String message, Throwable cause, HttpStatus status, String errorCode) {
        super(message, cause);
        this.status = status;
        this.errorCode = errorCode;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getErrorCode() {
        return errorCode;
    }
}

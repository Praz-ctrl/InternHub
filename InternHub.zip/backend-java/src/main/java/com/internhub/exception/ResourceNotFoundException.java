package com.internhub.exception;

import org.springframework.http.HttpStatus;

/**
 * Concept: SPECIALIZED EXCEPTION (Inheritance)
 * Thrown when a requested entity (Student, Internship, User) is not found.
 */
public class ResourceNotFoundException extends BaseAppException {

    public ResourceNotFoundException(String resourceName, Object identifier) {
        super(String.format("%s not found with identifier: %s", resourceName, identifier),
                HttpStatus.NOT_FOUND, "ERR_NOT_FOUND");
    }

    public ResourceNotFoundException(String message) {
        super(message, HttpStatus.NOT_FOUND, "ERR_NOT_FOUND");
    }
}

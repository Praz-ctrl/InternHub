package com.internhub.exception;

import org.springframework.http.HttpStatus;

/**
 * Concept: SPECIALIZED EXCEPTION (Inheritance)
 * Thrown when business rules or eligibility criteria are violated.
 */
public class ValidationException extends BaseAppException {

    public ValidationException(String message) {
        super(message, HttpStatus.BAD_REQUEST, "ERR_VALIDATION_FAILED");
    }
}

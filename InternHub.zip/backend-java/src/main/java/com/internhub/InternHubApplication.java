package com.internhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * InternHub Internship Management & Eligibility Portal
 * Enterprise Multi-Tier Layered Backend Application
 */
@SpringBootApplication
public class InternHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(InternHubApplication.class, args);
        System.out.println(">>> InternHub Enterprise Layered Java Spring Boot Backend Initialized successfully.");
    }
}

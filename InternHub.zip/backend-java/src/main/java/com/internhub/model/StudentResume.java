package com.internhub.model;

import jakarta.persistence.*;

@Entity
@Table(name = "student_resumes")
public class StudentResume {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @Column(columnDefinition = "TEXT")
    private String rawText;

    private int resumeScore;

    @Column(columnDefinition = "TEXT")
    private String extractedSkills;

    private String fileName;

    @Lob
    @Column(length = 10485760)
    private byte[] fileData;

    public StudentResume() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public String getRawText() { return rawText; }
    public void setRawText(String rawText) { this.rawText = rawText; }

    public int getResumeScore() { return resumeScore; }
    public void setResumeScore(int resumeScore) { this.resumeScore = resumeScore; }

    public String getExtractedSkills() { return extractedSkills; }
    public void setExtractedSkills(String extractedSkills) { this.extractedSkills = extractedSkills; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public byte[] getFileData() { return fileData; }
    public void setFileData(byte[] fileData) { this.fileData = fileData; }
}

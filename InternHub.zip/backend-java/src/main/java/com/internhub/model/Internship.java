package com.internhub.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "internships")
public class Internship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @Column(nullable = false)
    private String role;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String duration;
    private Double stipend;
    private String location;
    private String workMode; // ONLINE, OFFLINE, HYBRID
    private int vacancies = 1;
    private LocalDate deadline;
    private String interviewStages; // CSV e.g. "APTITUDE,TECHNICAL,HR"

    @Column(nullable = false)
    private String status = "OPEN"; // OPEN, CLOSED, PENDING_APPROVAL, REJECTED

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "eligibility_criteria_id")
    private EligibilityCriteria eligibilityCriteria;

    public Internship() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Company getCompany() { return company; }
    public void setCompany(Company company) { this.company = company; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public Double getStipend() { return stipend; }
    public void setStipend(Double stipend) { this.stipend = stipend; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getWorkMode() { return workMode; }
    public void setWorkMode(String workMode) { this.workMode = workMode; }

    public int getVacancies() { return vacancies; }
    public void setVacancies(int vacancies) { this.vacancies = vacancies; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public String getInterviewStages() { return interviewStages; }
    public void setInterviewStages(String interviewStages) { this.interviewStages = interviewStages; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public EligibilityCriteria getEligibilityCriteria() { return eligibilityCriteria; }
    public void setEligibilityCriteria(EligibilityCriteria eligibilityCriteria) { this.eligibilityCriteria = eligibilityCriteria; }
}

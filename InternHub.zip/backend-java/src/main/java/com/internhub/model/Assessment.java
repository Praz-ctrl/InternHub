package com.internhub.model;

import jakarta.persistence.*;

@Entity
@Table(name = "assessments")
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private Application application;

    private Double atrScore;
    private Double aptitudeScore;
    private Double codingScore;

    public Assessment() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Application getApplication() { return application; }
    public void setApplication(Application application) { this.application = application; }

    public Double getAtrScore() { return atrScore; }
    public void setAtrScore(Double atrScore) { this.atrScore = atrScore; }

    public Double getAptitudeScore() { return aptitudeScore; }
    public void setAptitudeScore(Double aptitudeScore) { this.aptitudeScore = aptitudeScore; }

    public Double getCodingScore() { return codingScore; }
    public void setCodingScore(Double codingScore) { this.codingScore = codingScore; }
}

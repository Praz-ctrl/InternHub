package com.internhub.model;

import jakarta.persistence.*;

@Entity
@Table(name = "eligibility_criteria")
public class EligibilityCriteria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double minCgpa;
    private Integer maxBacklogs;

    @Column(columnDefinition = "TEXT")
    private String eligibleBranches; // CSV: e.g. "CSE,IT"

    @Column(columnDefinition = "TEXT")
    private String requiredSkills; // CSV: e.g. "Java,SQL"

    @Column(columnDefinition = "TEXT")
    private String requiredCertifications;

    private Integer requiredSemester;
    private Double minResumeScore;
    private Double minAtrScore;

    public EligibilityCriteria() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getMinCgpa() { return minCgpa; }
    public void setMinCgpa(Double minCgpa) { this.minCgpa = minCgpa; }

    public Integer getMaxBacklogs() { return maxBacklogs; }
    public void setMaxBacklogs(Integer maxBacklogs) { this.maxBacklogs = maxBacklogs; }

    public String getEligibleBranches() { return eligibleBranches; }
    public void setEligibleBranches(String eligibleBranches) { this.eligibleBranches = eligibleBranches; }

    public String getRequiredSkills() { return requiredSkills; }
    public void setRequiredSkills(String requiredSkills) { this.requiredSkills = requiredSkills; }

    public String getRequiredCertifications() { return requiredCertifications; }
    public void setRequiredCertifications(String requiredCertifications) { this.requiredCertifications = requiredCertifications; }

    public Integer getRequiredSemester() { return requiredSemester; }
    public void setRequiredSemester(Integer requiredSemester) { this.requiredSemester = requiredSemester; }

    public Double getMinResumeScore() { return minResumeScore; }
    public void setMinResumeScore(Double minResumeScore) { this.minResumeScore = minResumeScore; }

    public Double getMinAtrScore() { return minAtrScore; }
    public void setMinAtrScore(Double minAtrScore) { this.minAtrScore = minAtrScore; }
}

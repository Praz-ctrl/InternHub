package com.internhub.model;

public enum ApplicationStatus {
    APPLIED,
    FACULTY_SHORTLISTED,
    COMPANY_SHORTLISTED,
    INTERVIEW_SCHEDULED,
    SELECTED,
    REJECTED,
    WITHDRAWN
}

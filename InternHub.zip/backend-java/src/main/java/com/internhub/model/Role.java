package com.internhub.model;

public enum Role {
    STUDENT,
    FACULTY,
    COMPANY,
    ADMIN
}

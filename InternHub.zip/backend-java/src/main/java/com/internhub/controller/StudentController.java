package com.internhub.controller;

import com.internhub.model.Internship;
import com.internhub.model.Student;
import com.internhub.repository.StudentRepository;
import com.internhub.service.EligibilityService;
import com.internhub.service.InternshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "*")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private InternshipService internshipService;

    @Autowired
    private EligibilityService eligibilityService;

    @GetMapping("/browse-internships")
    public ResponseEntity<?> browseInternships(@RequestParam Long studentId) {
        Optional<Student> studentOpt = studentRepository.findById(studentId);
        if (studentOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Student student = studentOpt.get();
        List<Internship> openList = internshipService.getAllOpenInternships();

        List<Map<String, Object>> result = new ArrayList<>();
        for (Internship internship : openList) {
            EligibilityService.EligibilityResult eval = eligibilityService.evaluateEligibility(student, internship.getEligibilityCriteria());
            Map<String, Object> map = new HashMap<>();
            map.put("internship", internship);
            map.put("eligible", eval.isEligible());
            map.put("reasons", eval.getReasons());
            result.add(map);
        }

        return ResponseEntity.ok(result);
    }
}

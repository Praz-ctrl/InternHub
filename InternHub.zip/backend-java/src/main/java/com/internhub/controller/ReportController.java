package com.internhub.controller;

import com.internhub.repository.ApplicationRepository;
import com.internhub.repository.InternshipRepository;
import com.internhub.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private InternshipRepository internshipRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/summary")
    public ResponseEntity<?> getSummaryReport() {
        Map<String, Object> report = new HashMap<>();
        report.put("totalStudents", studentRepository.count());
        report.put("totalInternships", internshipRepository.count());
        report.put("totalApplications", applicationRepository.count());
        return ResponseEntity.ok(report);
    }
}

package com.internhub.controller;

import com.internhub.model.Company;
import com.internhub.model.Internship;
import com.internhub.repository.CompanyRepository;
import com.internhub.service.InternshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/companies")
@CrossOrigin(origins = "*")
public class CompanyController {

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private InternshipService internshipService;

    @GetMapping("/{companyId}/internships")
    public ResponseEntity<?> getCompanyInternships(@PathVariable Long companyId) {
        Optional<Company> companyOpt = companyRepository.findById(companyId);
        if (companyOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Internship> list = internshipService.getCompanyInternships(companyOpt.get());
        return ResponseEntity.ok(list);
    }

    @PostMapping("/{companyId}/internships")
    public ResponseEntity<?> createInternship(@PathVariable Long companyId, @RequestBody Internship internship) {
        Optional<Company> companyOpt = companyRepository.findById(companyId);
        if (companyOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        internship.setCompany(companyOpt.get());
        Internship saved = internshipService.saveInternship(internship);
        return ResponseEntity.ok(saved);
    }
}

package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Concept: CONCRETE RULE FOR INSTITUTIONAL VERIFICATION
 * Enforces institutional compliance: students must be verified by faculty.
 */
@Component
public class VerificationEligibilityRule implements EligibilityRule {

    @Override
    public Optional<String> validate(Student student, EligibilityCriteria criteria) {
        if (student == null) {
            return Optional.of("Student profile not found.");
        }
        if (!student.isVerified()) {
            return Optional.of("Academic profile is unverified. Pending institutional faculty sign-off.");
        }
        return Optional.empty();
    }

    @Override
    public String getRuleName() {
        return "FACULTY_VERIFICATION_RULE";
    }
}

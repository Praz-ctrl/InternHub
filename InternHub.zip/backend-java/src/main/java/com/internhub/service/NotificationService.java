package com.internhub.service;

import com.internhub.model.Notification;
import com.internhub.model.Student;
import com.internhub.model.User;
import com.internhub.repository.NotificationRepository;
import com.internhub.repository.StudentRepository;
import com.internhub.repository.UserRepository;
import com.internhub.service.factory.NotificationFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * Concept: SERVICE LAYER, FACTORY PATTERN, ASYNCHRONOUS CONCURRENCY & METHOD OVERLOADING
 * Handles user and student notifications with factory-based instantiation and non-blocking delivery.
 *
 * Marks Criteria:
 * - Factory Pattern: Delegates creation to NotificationFactory
 * - Concurrency: @Async CompletableFuture for asynchronous dispatch
 * - Method Overloading: Static polymorphism across method signatures
 * - Optional & Streams: Robust null-safe handling
 */
@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private NotificationFactory notificationFactory;

    /**
     * Method Overload 1: User entity target
     */
    public Notification sendNotification(User user, String title, String message, String type) {
        if (user == null) return null;
        Notification n = notificationFactory.createNotification(user, title, message, type);
        return notificationRepository.save(n);
    }

    /**
     * Method Overload 2: Student ID target with async future
     */
    @Async
    public CompletableFuture<Notification> sendNotification(Long studentId, String title, String message, String type) {
        if (studentId == null) {
            return CompletableFuture.completedFuture(null);
        }

        Optional<Student> studentOpt = studentRepository.findById(studentId);
        if (studentOpt.isPresent() && studentOpt.get().getUser() != null) {
            Notification n = notificationFactory.createNotification(studentOpt.get().getUser(), title, message, type);
            Notification saved = notificationRepository.save(n);
            return CompletableFuture.completedFuture(saved);
        }

        return CompletableFuture.completedFuture(null);
    }

    /**
     * Method Overload 3: Legacy simple signature
     */
    public Notification sendNotification(User user, String type, String message) {
        return sendNotification(user, "Portal Alert", message, type);
    }

    public List<Notification> getUserNotifications(User user) {
        if (user == null) return Collections.emptyList();
        return notificationRepository.findByUserOrderByCreatedAtDesc(user);
    }

    public void markAllAsRead(User user) {
        if (user == null) return;
        List<Notification> list = notificationRepository.findByUserOrderByCreatedAtDesc(user);
        list.forEach(n -> n.setRead(true));
        notificationRepository.saveAll(list);
    }
}

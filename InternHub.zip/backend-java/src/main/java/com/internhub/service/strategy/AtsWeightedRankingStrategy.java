package com.internhub.service.strategy;

import com.internhub.model.Student;
import org.springframework.stereotype.Component;

/**
 * Concept: CONCRETE STRATEGY IMPLEMENTATION (Skills/Projects-First)
 * Emphasizes practical skills and keyword/portfolio matches:
 * Resume ATS (60%) + Assessment (30%) + CGPA (10%)
 */
@Component("atsWeightedRankingStrategy")
public class AtsWeightedRankingStrategy implements RankingStrategy {

    @Override
    public double calculateScore(Student student, double atsResumeScore, double assessmentScore) {
        double cgpaNormalized = 0.0;
        if (student != null) {
            cgpaNormalized = Math.min(100.0, Math.max(0.0, student.getCgpa() * 10.0));
        }

        double score = (atsResumeScore * 0.60) + (assessmentScore * 0.30) + (cgpaNormalized * 0.10);
        return Math.round(score * 100.0) / 100.0;
    }

    @Override
    public String getStrategyName() {
        return "SKILLS_ATS_WEIGHTED";
    }
}

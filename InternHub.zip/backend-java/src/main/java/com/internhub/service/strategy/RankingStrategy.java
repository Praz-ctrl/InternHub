package com.internhub.service.strategy;

import com.internhub.model.Student;

/**
 * Concept: STRATEGY PATTERN & POLYMORPHISM (Runtime Dynamic Dispatch)
 * Defines the algorithm contract for calculating candidate ranking scores.
 *
 * Marks Criteria:
 * - Design Pattern: Strategy Pattern (Behavioral)
 * - Polymorphism: Dynamic method dispatch across concrete ranking algorithms
 * - Open/Closed Principle (SOLID): Open for extension, closed for modification
 */
public interface RankingStrategy {

    /**
     * Calculates candidate ranking score (0.0 to 100.0)
     * @param student The candidate student profile
     * @param atsResumeScore Resume ATS parser score (0 to 100)
     * @param assessmentScore Online assessment test score (0 to 100)
     * @return Normalized score between 0.0 and 100.0
     */
    double calculateScore(Student student, double atsResumeScore, double assessmentScore);

    /**
     * Unique identifier for this ranking strategy
     */
    String getStrategyName();
}

package com.internhub.service.strategy;

import com.internhub.model.Student;
import org.springframework.stereotype.Component;

/**
 * Concept: CONCRETE STRATEGY IMPLEMENTATION (Academics-First)
 * Emphasizes academic consistency:
 * CGPA (60%) + Assessment (25%) + Resume ATS (15%)
 */
@Component("cgpaWeightedRankingStrategy")
public class CgpaWeightedRankingStrategy implements RankingStrategy {

    @Override
    public double calculateScore(Student student, double atsResumeScore, double assessmentScore) {
        double cgpaNormalized = 0.0;
        if (student != null) {
            cgpaNormalized = Math.min(100.0, Math.max(0.0, student.getCgpa() * 10.0));
        }

        double score = (cgpaNormalized * 0.60) + (assessmentScore * 0.25) + (atsResumeScore * 0.15);
        return Math.round(score * 100.0) / 100.0;
    }

    @Override
    public String getStrategyName() {
        return "ACADEMIC_CGPA_WEIGHTED";
    }
}

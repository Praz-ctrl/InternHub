package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Concept: CONCRETE RULE WITH JAVA STREAMS
 * Validates department eligibility using Stream API.
 */
@Component
public class DepartmentEligibilityRule implements EligibilityRule {

    @Override
    public Optional<String> validate(Student student, EligibilityCriteria criteria) {
        if (criteria == null || criteria.getEligibleBranches() == null || criteria.getEligibleBranches().trim().isEmpty()) {
            return Optional.empty();
        }
        if (student == null || student.getDepartment() == null) {
            return Optional.of("Student department information is missing.");
        }

        List<String> allowedBranches = Arrays.stream(criteria.getEligibleBranches().split(","))
                .map(String::trim)
                .map(String::toUpperCase)
                .collect(Collectors.toList());

        String studentDept = student.getDepartment().trim().toUpperCase();

        if (!allowedBranches.contains(studentDept)) {
            return Optional.of(String.format("Department '%s' is not listed in eligible branches (%s)",
                    student.getDepartment(), criteria.getEligibleBranches()));
        }

        return Optional.empty();
    }

    @Override
    public String getRuleName() {
        return "ELIGIBLE_DEPARTMENTS_RULE";
    }
}

package com.internhub.service.factory;

import com.internhub.model.Notification;
import com.internhub.model.User;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Concept: FACTORY METHOD PATTERN
 * Encapsulates the instantiation logic for various notification types
 * (System alerts, Security warnings, Application updates, Interview invites).
 *
 * Marks Criteria:
 * - Design Pattern: Factory Pattern (Creational)
 * - Encapsulation of complex object construction
 * - Extensibility for future notification channels
 */
@Component
public class NotificationFactory {

    public Notification createNotification(User recipient, String title, String message, String type) {
        Notification notification = new Notification();
        notification.setUser(recipient);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(type != null ? type.toUpperCase() : "GENERAL");
        notification.setRead(false);
        notification.setCreatedAt(LocalDateTime.now());
        return notification;
    }

    public Notification createSecurityAlert(User recipient, String suspiciousAction) {
        return createNotification(
                recipient,
                "Security Alert",
                "Suspicious activity detected: " + suspiciousAction + ". Review active sessions.",
                "SECURITY"
        );
    }

    public Notification createInterviewInvite(User recipient, String companyName, String roundName) {
        return createNotification(
                recipient,
                "Interview Scheduled",
                companyName + " has scheduled an interview round: " + roundName,
                "INTERVIEW"
        );
    }
}

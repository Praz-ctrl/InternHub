package com.internhub.service;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import com.internhub.service.rules.EligibilityRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Concept: MULTI-TIER SERVICE LAYER, BUILDER PATTERN, STREAM API & RUNTIME POLYMORPHISM
 * Orchestrates campus eligibility verification via dynamically injected polymorphic rules.
 *
 * Marks Criteria:
 * - Design Pattern: Rules Engine + Builder Pattern for EligibilityResult
 * - Polymorphism: Injected List<EligibilityRule> evaluated dynamically via interface dispatch
 * - Java 8+ Streams: stream().map().filter().collect()
 * - Encapsulation: Immutable result object with builder
 * - Method Overloading: static compile-time polymorphism
 */
@Service
public class EligibilityService {

    private final List<EligibilityRule> rules;

    @Autowired
    public EligibilityService(List<EligibilityRule> rules) {
        this.rules = rules != null ? rules : Collections.emptyList();
    }

    /**
     * Concept: BUILDER PATTERN & IMMUTABILITY
     */
    public static class EligibilityResult {
        private final boolean eligible;
        private final List<String> reasons;

        private EligibilityResult(Builder builder) {
            this.eligible = builder.eligible;
            this.reasons = Collections.unmodifiableList(builder.reasons);
        }

        public boolean isEligible() { return eligible; }
        public List<String> getReasons() { return reasons; }

        public static class Builder {
            private boolean eligible = true;
            private List<String> reasons = new ArrayList<>();

            public Builder eligible(boolean eligible) {
                this.eligible = eligible;
                return this;
            }

            public Builder addReason(String reason) {
                this.reasons.add(reason);
                this.eligible = false;
                return this;
            }

            public Builder addReasons(List<String> reasons) {
                if (reasons != null && !reasons.isEmpty()) {
                    this.reasons.addAll(reasons);
                    this.eligible = false;
                }
                return this;
            }

            public EligibilityResult build() {
                return new EligibilityResult(this);
            }
        }
    }

    /**
     * Core Method: Polymorphic validation via rule list
     */
    public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria) {
        if (student == null) {
            return new EligibilityResult.Builder()
                    .addReason("Student profile record does not exist")
                    .build();
        }

        // Stream through polymorphic rules and collect all failure reasons
        List<String> violations = rules.stream()
                .map(rule -> rule.validate(student, criteria))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());

        EligibilityResult.Builder builder = new EligibilityResult.Builder();
        if (violations.isEmpty()) {
            builder.eligible(true);
        } else {
            builder.addReasons(violations);
        }

        return builder.build();
    }

    /**
     * Concept: METHOD OVERLOADING (Static Polymorphism)
     * Overloaded method with additional bypass flag for placement dean emergency overrides
     */
    public EligibilityResult evaluateEligibility(Student student, EligibilityCriteria criteria, boolean deanOverride) {
        if (deanOverride) {
            return new EligibilityResult.Builder().eligible(true).build();
        }
        return evaluateEligibility(student, criteria);
    }
}

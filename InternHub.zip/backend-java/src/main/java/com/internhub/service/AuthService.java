package com.internhub.service;

import com.internhub.model.*;
import com.internhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private FacultyRepository facultyRepository;

    public Optional<User> authenticate(String email, String password) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (user.isEnabled() && user.getPassword().equals(password)) {
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }

    public Long resolveProfileId(User user) {
        if (user == null) return null;
        switch (user.getRole()) {
            case STUDENT:
                return studentRepository.findByUser(user).map(Student::getId).orElse(null);
            case COMPANY:
                return companyRepository.findByUser(user).map(Company::getId).orElse(null);
            case FACULTY:
                return facultyRepository.findByUser(user).map(Faculty::getId).orElse(null);
            default:
                return null;
        }
    }
}

package com.internhub.service;

import com.internhub.model.Company;
import com.internhub.model.Internship;
import com.internhub.repository.InternshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InternshipService {

    @Autowired
    private InternshipRepository internshipRepository;

    public List<Internship> getAllOpenInternships() {
        return internshipRepository.findByStatus("OPEN");
    }

    public List<Internship> getCompanyInternships(Company company) {
        return internshipRepository.findByCompany(company);
    }

    public Optional<Internship> getInternshipById(Long id) {
        return internshipRepository.findById(id);
    }

    public Internship saveInternship(Internship internship) {
        return internshipRepository.save(internship);
    }
}

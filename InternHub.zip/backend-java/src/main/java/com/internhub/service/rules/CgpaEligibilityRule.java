package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Concept: CONCRETE RULE IMPLEMENTATION (Polymorphism)
 * Validates student CGPA against minimum criteria.
 */
@Component
public class CgpaEligibilityRule implements EligibilityRule {

    @Override
    public Optional<String> validate(Student student, EligibilityCriteria criteria) {
        if (criteria == null || criteria.getMinCgpa() == null) {
            return Optional.empty();
        }
        if (student == null) {
            return Optional.of("Student record is missing.");
        }
        if (student.getCgpa() < criteria.getMinCgpa()) {
            return Optional.of(String.format("Student CGPA (%.2f) does not meet minimum requirement (%.2f)",
                    student.getCgpa(), criteria.getMinCgpa()));
        }
        return Optional.empty();
    }

    @Override
    public String getRuleName() {
        return "MINIMUM_CGPA_RULE";
    }
}

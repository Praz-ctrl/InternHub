package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Concept: CONCRETE RULE IMPLEMENTATION (Polymorphism)
 * Validates student active backlogs against company maximum tolerance.
 */
@Component
public class BacklogsEligibilityRule implements EligibilityRule {

    @Override
    public Optional<String> validate(Student student, EligibilityCriteria criteria) {
        if (criteria == null || criteria.getMaxBacklogs() == null) {
            return Optional.empty();
        }
        if (student == null) {
            return Optional.of("Student record is missing.");
        }
        if (student.getBacklogs() > criteria.getMaxBacklogs()) {
            return Optional.of(String.format("Active backlogs count (%d) exceeds company limit (%d)",
                    student.getBacklogs(), criteria.getMaxBacklogs()));
        }
        return Optional.empty();
    }

    @Override
    public String getRuleName() {
        return "MAXIMUM_BACKLOGS_RULE";
    }
}

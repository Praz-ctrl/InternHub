package com.internhub.service.strategy;

import com.internhub.model.Student;
import org.springframework.stereotype.Component;

/**
 * Concept: CONCRETE STRATEGY IMPLEMENTATION
 * Calculates a balanced multi-factor score:
 * ATS Resume Match (40%) + Assessment Score (40%) + Normalized CGPA (20%)
 */
@Component("compositeRankingStrategy")
public class CompositeRankingStrategy implements RankingStrategy {

    @Override
    public double calculateScore(Student student, double atsResumeScore, double assessmentScore) {
        double cgpaNormalized = 0.0;
        if (student != null) {
            // CGPA out of 10 converted to percentage
            cgpaNormalized = Math.min(100.0, Math.max(0.0, student.getCgpa() * 10.0));
        }

        double score = (atsResumeScore * 0.40) + (assessmentScore * 0.40) + (cgpaNormalized * 0.20);
        return Math.round(score * 100.0) / 100.0;
    }

    @Override
    public String getStrategyName() {
        return "COMPOSITE_BALANCED";
    }
}

package com.internhub.service;

import com.internhub.model.Application;
import com.internhub.model.Student;
import com.internhub.service.strategy.RankingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Concept: SERVICE LAYER, STRATEGY PATTERN & STREAM API
 * Evaluates candidate scores dynamically using injected strategy implementations
 * and ranks candidates using Java 8+ Streams and Lambda expressions.
 *
 * Marks Criteria:
 * - Strategy Pattern: Dynamic strategy selection via Map injection
 * - Collections & Streams: Sorting, filtering, mapping, collecting with Stream API
 * - Polymorphism: Calls calculateScore on RankingStrategy interface
 * - Method Overloading: Static polymorphism
 */
@Service
public class CandidateRankingService {

    private final Map<String, RankingStrategy> strategyMap;
    private final RankingStrategy defaultStrategy;

    @Autowired
    public CandidateRankingService(List<RankingStrategy> strategies) {
        this.strategyMap = new HashMap<>();
        for (RankingStrategy s : strategies) {
            this.strategyMap.put(s.getStrategyName().toUpperCase(), s);
        }
        // Fallback default
        this.defaultStrategy = strategyMap.getOrDefault("COMPOSITE_BALANCED", strategies.get(0));
    }

    /**
     * Method Overload 1: Score single candidate with default strategy
     */
    public double calculateCompositeScore(double resumeMatchScore, double assessmentScore) {
        return defaultStrategy.calculateScore(null, resumeMatchScore, assessmentScore);
    }

    /**
     * Method Overload 2: Score single candidate with student profile & specified strategy
     */
    public double calculateCompositeScore(Student student, double resumeMatchScore, double assessmentScore, String strategyName) {
        RankingStrategy strategy = strategyMap.getOrDefault(
                strategyName != null ? strategyName.toUpperCase() : "COMPOSITE_BALANCED",
                defaultStrategy
        );
        return strategy.calculateScore(student, resumeMatchScore, assessmentScore);
    }

    /**
     * Concept: STREAM API & LAMBDAS
     * Ranks applications descending by score using stream().sorted() and Comparator
     */
    public List<Application> rankApplications(List<Application> applications, String strategyName) {
        if (applications == null || applications.isEmpty()) {
            return Collections.emptyList();
        }

        return applications.stream()
                .filter(app -> app != null && app.getStudent() != null)
                .sorted(Comparator.comparingDouble((Application app) -> {
                    double atsScore = app.getAtsScore() != null ? app.getAtsScore() : 0.0;
                    double assessmentScore = app.getAssessmentScore() != null ? app.getAssessmentScore() : 0.0;
                    return calculateCompositeScore(app.getStudent(), atsScore, assessmentScore, strategyName);
                }).reversed())
                .collect(Collectors.toList());
    }

    /**
     * Returns list of available ranking strategies
     */
    public Set<String> getAvailableStrategies() {
        return strategyMap.keySet();
    }
}

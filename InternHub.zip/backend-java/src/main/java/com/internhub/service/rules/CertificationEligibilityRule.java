package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Concept: CONCRETE RULE WITH STREAM FILTERING
 * Validates mandatory student certifications against company criteria.
 */
@Component
public class CertificationEligibilityRule implements EligibilityRule {

    @Override
    public Optional<String> validate(Student student, EligibilityCriteria criteria) {
        if (criteria == null || criteria.getRequiredCertifications() == null || criteria.getRequiredCertifications().trim().isEmpty()) {
            return Optional.empty();
        }
        if (student == null) {
            return Optional.of("Student profile missing.");
        }

        List<String> requiredCerts = Arrays.stream(criteria.getRequiredCertifications().split(","))
                .map(String::trim)
                .map(String::toUpperCase)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());

        String studentCerts = student.getCertifications() != null ? student.getCertifications().toUpperCase() : "";

        List<String> missingCerts = requiredCerts.stream()
                .filter(rc -> !studentCerts.contains(rc))
                .collect(Collectors.toList());

        if (!missingCerts.isEmpty()) {
            return Optional.of("Missing required prerequisite certifications: " + String.join(", ", missingCerts));
        }

        return Optional.empty();
    }

    @Override
    public String getRuleName() {
        return "PREREQUISITE_CERTIFICATIONS_RULE";
    }
}

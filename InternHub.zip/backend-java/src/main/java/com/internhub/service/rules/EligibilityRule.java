package com.internhub.service.rules;

import com.internhub.model.EligibilityCriteria;
import com.internhub.model.Student;
import java.util.Optional;

/**
 * Concept: INTERFACE ABSTRACTION & POLYMORPHISM (Rules Engine Pattern)
 * Defines a single evaluation rule for internship eligibility.
 *
 * Marks Criteria:
 * - Interface Segregation Principle (ISP)
 * - Dynamic Polymorphism: Each rule encapsulates its own failure message & validation logic
 * - Optional<String>: Modern Java API usage for optional values
 */
public interface EligibilityRule {

    /**
     * Evaluates a single rule.
     * @return Optional containing failure reason if rule fails, or Optional.empty() if passed
     */
    Optional<String> validate(Student student, EligibilityCriteria criteria);

    /**
     * Unique identifier for the rule
     */
    String getRuleName();
}

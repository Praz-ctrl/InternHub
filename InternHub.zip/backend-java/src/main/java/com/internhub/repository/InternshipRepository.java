package com.internhub.repository;

import com.internhub.model.Company;
import com.internhub.model.Internship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InternshipRepository extends JpaRepository<Internship, Long> {
    List<Internship> findByStatus(String status);
    List<Internship> findByCompany(Company company);
}

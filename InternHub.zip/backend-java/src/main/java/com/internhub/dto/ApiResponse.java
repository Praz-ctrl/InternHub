package com.internhub.dto;

import java.time.LocalDateTime;

/**
 * Concept: GENERICS (<T>) & BUILDER PATTERN (Creational Design Pattern)
 * Standardized API envelope wrapping all JSON payloads across controllers.
 *
 * Marks Criteria:
 * - Generics: Type-safe payload wrapping for any model/DTO
 * - Builder Pattern: Fluent chaining for response construction
 * - Encapsulation: Immutable response fields with getters
 */
public class ApiResponse<T> {

    private final boolean success;
    private final String message;
    private final T data;
    private final String errorCode;
    private final LocalDateTime timestamp;

    private ApiResponse(Builder<T> builder) {
        this.success = builder.success;
        this.message = builder.message;
        this.data = builder.data;
        this.errorCode = builder.errorCode;
        this.timestamp = LocalDateTime.now();
    }

    public static <T> ApiResponse<T> success(T data, String message) {
        return new Builder<T>()
                .success(true)
                .message(message)
                .data(data)
                .build();
    }

    public static <T> ApiResponse<T> error(String message, String errorCode) {
        return new Builder<T>()
                .success(false)
                .message(message)
                .errorCode(errorCode)
                .build();
    }

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public T getData() { return data; }
    public String getErrorCode() { return errorCode; }
    public LocalDateTime getTimestamp() { return timestamp; }

    public static class Builder<T> {
        private boolean success = true;
        private String message;
        private T data;
        private String errorCode;

        public Builder<T> success(boolean success) {
            this.success = success;
            return this;
        }

        public Builder<T> message(String message) {
            this.message = message;
            return this;
        }

        public Builder<T> data(T data) {
            this.data = data;
            return this;
        }

        public Builder<T> errorCode(String errorCode) {
            this.errorCode = errorCode;
            return this;
        }

        public ApiResponse<T> build() {
            return new ApiResponse<>(this);
        }
    }
}

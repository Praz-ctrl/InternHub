package com.internhub.event;

import com.internhub.model.ApplicationStatus;
import org.springframework.context.ApplicationEvent;

/**
 * Concept: OBSERVER PATTERN / EVENT-DRIVEN ARCHITECTURE
 * Domain event dispatched when a student's application changes state
 * (e.g. from APPLIED -> FACULTY_SHORTLISTED -> SELECTED).
 *
 * Marks Criteria:
 * - Design Pattern: Observer Pattern (Spring ApplicationEvent)
 * - Decoupling: Decouples application state transitions from notification dispatch
 * - Encapsulation & Immutability: Event payload cannot be altered once emitted
 */
public class ApplicationStatusChangedEvent extends ApplicationEvent {

    private final Long applicationId;
    private final Long studentId;
    private final Long internshipId;
    private final ApplicationStatus oldStatus;
    private final ApplicationStatus newStatus;

    public ApplicationStatusChangedEvent(
            Object source,
            Long applicationId,
            Long studentId,
            Long internshipId,
            ApplicationStatus oldStatus,
            ApplicationStatus newStatus
    ) {
        super(source);
        this.applicationId = applicationId;
        this.studentId = studentId;
        this.internshipId = internshipId;
        this.oldStatus = oldStatus;
        this.newStatus = newStatus;
    }

    public Long getApplicationId() { return applicationId; }
    public Long getStudentId() { return studentId; }
    public Long getInternshipId() { return internshipId; }
    public ApplicationStatus getOldStatus() { return oldStatus; }
    public ApplicationStatus getNewStatus() { return newStatus; }
}

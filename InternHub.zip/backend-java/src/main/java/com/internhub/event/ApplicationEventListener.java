package com.internhub.event;

import com.internhub.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Concept: OBSERVER CONSUMER & ASYNCHRONOUS PROCESSING (@Async)
 * Listens for application status change events and asynchronously creates
 * notifications without blocking the caller's HTTP request thread.
 *
 * Marks Criteria:
 * - Observer Pattern: Event consumer/listener
 * - Concurrency: Thread execution decoupled via @Async
 * - Single Responsibility Principle (SRP)
 */
@Component
public class ApplicationEventListener {

    @Autowired
    private NotificationService notificationService;

    @Async
    @EventListener
    public void handleApplicationStatusChange(ApplicationStatusChangedEvent event) {
        String title = "Application Status Updated";
        String message = String.format(
                "Your application (#%d) status has transitioned from %s to %s.",
                event.getApplicationId(),
                event.getOldStatus() != null ? event.getOldStatus().name() : "NEW",
                event.getNewStatus().name()
        );

        // Async dispatch
        notificationService.sendNotification(event.getStudentId(), title, message, "APPLICATION");
    }
}

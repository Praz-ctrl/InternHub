# InternHub — Java Enterprise Architecture & Academic Marking Rubric

This comprehensive document details every core **Object-Oriented Programming (OOP)**, **Software Engineering Design Pattern**, **Java 8-21 Language Feature**, and **Enterprise Spring Boot Architecture Concept** implemented in the backend codebase, along with exact file locations, code references, and academic criteria explanations for high distinction marks.

---

## Quick Reference: Concepts-to-Code Matrix

| Category | Concept | Primary Java File | Implementation Detail |
| :--- | :--- | :--- | :--- |
| **OOP** | **Encapsulation** | `model/Student.java`<br>`model/User.java`<br>`model/EligibilityCriteria.java` | Private variables, public getters/setters, parameter validation, defensive copying, immutable builders. |
| **OOP** | **Inheritance** | `model/BaseEntity.java`<br>`exception/BaseAppException.java` | `BaseEntity` mapped superclass inherited by entities with `@Version` and audit timestamps; custom exception hierarchy. |
| **OOP** | **Polymorphism (Dynamic)** | `service/rules/EligibilityRule.java`<br>`service/strategy/RankingStrategy.java` | Interface implementation and runtime dynamic method dispatch across concrete rules and ranking strategies. |
| **OOP** | **Polymorphism (Static)** | `service/EligibilityService.java`<br>`service/CandidateRankingService.java`<br>`service/NotificationService.java` | Method Overloading across distinct parameter signatures (e.g., student + criteria vs student + criteria + deanOverride). |
| **OOP** | **Abstraction** | `model/BaseEntity.java`<br>`service/rules/EligibilityRule.java`<br>`repository/UserRepository.java` | Abstract classes preventing direct instantiation; interfaces establishing behavioral contracts decoupled from storage. |
| **Patterns** | **Strategy Pattern** | `service/strategy/RankingStrategy.java`<br>`CompositeRankingStrategy.java`<br>`CgpaWeightedRankingStrategy.java`<br>`AtsWeightedRankingStrategy.java` | Behavioral pattern allowing runtime swapping of candidate evaluation algorithms (Composite, Academics-first, ATS-first). |
| **Patterns** | **Builder Pattern** | `service/EligibilityService.java`<br>`dto/ApiResponse.java` | Fluent step-by-step object construction and immutability for complex evaluation results and API response envelopes. |
| **Patterns** | **Factory Method Pattern** | `service/factory/NotificationFactory.java` | Creational pattern centralizing the instantiation and customization of system, security, and interview notifications. |
| **Patterns** | **Observer Pattern** | `event/ApplicationStatusChangedEvent.java`<br>`event/ApplicationEventListener.java` | Event-driven decoupled notification triggers on application status lifecycle changes using Spring Application Events. |
| **Patterns** | **Singleton Pattern** | All `@Service`, `@Repository`, `@Component` classes | Spring IoC Container manages single instances with dependency injection. |
| **Patterns** | **Repository Pattern** | `repository/UserRepository.java`<br>`repository/InternshipRepository.java` | Spring Data JPA interfaces abstracting persistence and SQL queries. |
| **Patterns** | **DTO Pattern** | `dto/ApiResponse.java`<br>`controller/AuthController.java` | Data Transfer Objects preventing domain model exposure over HTTP REST boundaries. |
| **Java Core** | **Collections Framework** | `service/CandidateRankingService.java`<br>`service/rules/*.java` | Utilizes `List`, `Map`, `Set`, `Optional` for data manipulation, lookup caches, and defensive aggregation. |
| **Java Core** | **Stream API & Lambdas** | `service/CandidateRankingService.java`<br>`service/EligibilityService.java` | High-order stream pipelines (`filter`, `map`, `sorted`, `collect`, `Collectors.toList()`) with lambda expressions. |
| **Java Core** | **Generics (`<T>`)** | `dto/ApiResponse.java`<br>`repository/*.java` | Compile-time type safety via generic envelopes and repository contracts (`JpaRepository<T, ID>`). |
| **Java Core** | **Exception Handling** | `exception/GlobalExceptionHandler.java`<br>`exception/*.java` | Centralized `@RestControllerAdvice` translating typed exceptions into HTTP status codes and structured payloads. |
| **Enterprise** | **Concurrency & Multithreading** | `event/ApplicationEventListener.java`<br>`service/NotificationService.java` | Non-blocking asynchronous task execution with `@Async` and `CompletableFuture<T>`. |
| **Enterprise** | **Multi-Tier Layered Architecture** | `controller/`, `service/`, `repository/`, `model/` | Decoupled presentation, business logic, persistence, and domain model tiers. |
| **Enterprise** | **Role-Based Access Control** | `model/Role.java`<br>`service/AuthService.java` | Multi-role permission enforcement across STUDENT, FACULTY, COMPANY, and ADMIN personas. |

---

## Detailed Section-by-Section Academic Breakdown

### 1. Object-Oriented Programming (OOP) Pillars

#### A. Encapsulation
- **Where**: `model/Student.java`, `model/Internship.java`, `model/EligibilityCriteria.java`
- **Explanation**: All entity state fields are strictly marked `private`. External access is mediated solely through public getters and validation-enforcing setters. Invariants like CGPA bounds (0.0 to 10.0) and non-negative backlog counters are protected from arbitrary direct modification.
- **Marks Highlight**: Demonstrates data hiding, state integrity protection, and class boundary control.

#### B. Inheritance
- **Where**:
  1. `model/BaseEntity.java` $\to$ inherited by all JPA Entities (`User`, `Student`, `Company`, `Internship`, `Application`, `Notification`).
  2. `exception/BaseAppException.java` $\to$ specialized by `ResourceNotFoundException`, `ValidationException`, `UnauthorizedAccessException`.
- **Explanation**: `BaseEntity` is an abstract `@MappedSuperclass` holding universal fields (`id`, `createdAt`, `updatedAt`, `version`). Subclasses reuse lifecycle callbacks (`@PrePersist`, `@PreUpdate`) without duplicating boilerplate.
- **Marks Highlight**: Code reusability, hierarchical domain classification, and standardized exception handling.

#### C. Polymorphism
- **Dynamic Polymorphism (Method Overriding & Interface Dispatch)**:
  - `service/rules/EligibilityRule.java` implemented by `CgpaEligibilityRule`, `BacklogsEligibilityRule`, `DepartmentEligibilityRule`, `CertificationEligibilityRule`, `VerificationEligibilityRule`.
  - `service/strategy/RankingStrategy.java` implemented by `CompositeRankingStrategy`, `CgpaWeightedRankingStrategy`, `AtsWeightedRankingStrategy`.
  - At runtime, Spring injects all matching implementations into a collection, and the service evaluates them via dynamic dispatch without knowing their concrete types.
- **Static Polymorphism (Method Overloading)**:
  - `EligibilityService.java`: `evaluateEligibility(Student, EligibilityCriteria)` vs `evaluateEligibility(Student, EligibilityCriteria, boolean deanOverride)`.
  - `CandidateRankingService.java`: `calculateCompositeScore(double, double)` vs `calculateCompositeScore(Student, double, double, String)`.
  - `NotificationService.java`: `sendNotification(User, String, String)` vs `sendNotification(Long studentId, String, String, String)`.
- **Marks Highlight**: Demonstrates both runtime interface polymorphism and compile-time signature overloading.

#### D. Abstraction
- **Where**: `model/BaseEntity.java`, `service/rules/EligibilityRule.java`, `repository/*.java`.
- **Explanation**: Abstract classes and interfaces define high-level contracts ("what needs to be done") while hiding low-level implementation details ("how it is done").
- **Marks Highlight**: Promotes loose coupling and separation of concerns.

---

### 2. Design Patterns

#### A. Strategy Pattern (Behavioral)
- **Files**:
  - `service/strategy/RankingStrategy.java` (Strategy Interface)
  - `service/strategy/CompositeRankingStrategy.java` (Balanced Algorithm)
  - `service/strategy/CgpaWeightedRankingStrategy.java` (Academics Algorithm)
  - `service/strategy/AtsWeightedRankingStrategy.java` (Skills Algorithm)
  - `service/CandidateRankingService.java` (Context)
- **Why It's Used**: Companies have differing recruiting criteria—some prioritize academic standing (CGPA), others emphasize hands-on projects and resume keyword matches (ATS score). The Strategy Pattern enables selecting or swapping ranking algorithms dynamically at runtime without modifying client code.

#### B. Builder Pattern (Creational)
- **Files**:
  - `service/EligibilityService.java` (`EligibilityResult.Builder`)
  - `dto/ApiResponse.java` (`ApiResponse.Builder<T>`)
- **Why It's Used**: Complex objects with multiple optional parameters (e.g. eligibility failure reasons, generic response payloads) can be constructed fluently and remain immutable once built.

#### C. Factory Method Pattern (Creational)
- **Files**:
  - `service/factory/NotificationFactory.java`
- **Why It's Used**: Centralizes the creation logic for notifications of different types (system alerts, interview invites, security notices) with preset formats, timestamps, and default flags.

#### D. Observer Pattern (Behavioral / Event-Driven)
- **Files**:
  - `event/ApplicationStatusChangedEvent.java` (Subject/Event)
  - `event/ApplicationEventListener.java` (Observer/Listener)
- **Why It's Used**: When an application status changes (e.g., shortlisted or selected), the status update transaction completes immediately and an event is published. The observer listens and triggers notifications asynchronously, preventing business logic from becoming tightly coupled to delivery channels.

#### E. Repository Pattern (Architectural)
- **Files**: `repository/UserRepository.java`, `repository/StudentRepository.java`, `repository/InternshipRepository.java`, `repository/ApplicationRepository.java`
- **Why It's Used**: Decouples the business logic layer from underlying database technologies, SQL generation, and query execution.

---

### 3. Java Language & Functional Programming Features

#### A. Java 8+ Stream API & Lambdas
- **Files**: `service/CandidateRankingService.java`, `service/EligibilityService.java`, `service/rules/DepartmentEligibilityRule.java`
- **Techniques Used**:
  - `.filter()`: Eliminating null or invalid candidates
  - `.map()`: Transforming rules into error evaluations
  - `.sorted(Comparator.comparingDouble(...).reversed())`: Dynamic descending ranking
  - `.collect(Collectors.toList())`: Re-aggregating streams into immutable collections

#### B. Java Generics (`<T>`)
- **Files**: `dto/ApiResponse.java`, Spring Data `JpaRepository<T, ID>`
- **Techniques Used**: Parameterized types ensure compile-time type safety for API envelopes, avoiding runtime `ClassCastException`.

#### C. Centralized Exception Handling
- **Files**: `exception/GlobalExceptionHandler.java`, `exception/BaseAppException.java`
- **Techniques Used**: `@RestControllerAdvice` intercepts exceptions across all REST controllers and maps them to appropriate HTTP status codes (400, 403, 404, 500) and uniform JSON payloads.

#### D. Concurrency & Asynchronous Execution
- **Files**: `event/ApplicationEventListener.java`, `service/NotificationService.java`
- **Techniques Used**: `@Async` annotation with `CompletableFuture<T>` ensures that notification dispatches execute on dedicated background thread pools without adding latency to student HTTP responses.

---

## How to Verify & Review in the Application GUI

1. Open the **InternHub Portal** in your browser.
2. In the top navigation bar or the footer, click **"7-Layer Security: Active"** or **"Inspect Layered Architecture"** to open the **Multi-Layered Architecture Inspector Modal**.
3. Select the **"Java Source Code (Spring Boot)"** tab:
   - Browse individual Java files (`EligibilityService.java`, `CandidateRankingService.java`, `Student.java`, `RankingStrategy.java`, etc.).
   - Copy source code directly to clipboard for submission or viva presentation.
4. Select the **"Academic Marking Rubric & Concepts"** view to review the complete alignment with university grading criteria.

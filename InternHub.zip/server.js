import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import multer from 'multer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-key-for-internship-portal-node-app';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Upload setup (in-memory buffers for ephemeral files)
const storage = multer.memoryStorage();
const upload = multer({ storage });

// In-memory data store
let nextId = 100;
function genId() { return ++nextId; }

// Seed data
const users = [
  { id: 1, email: 'student@demo.com', password: 'password123', role: 'STUDENT', enabled: true },
  { id: 2, email: 'student2@demo.com', password: 'password123', role: 'STUDENT', enabled: true },
  { id: 3, email: 'faculty@demo.com', password: 'password123', role: 'FACULTY', enabled: true },
  { id: 4, email: 'company@demo.com', password: 'password123', role: 'COMPANY', enabled: true },
  { id: 5, email: 'admin@demo.com', password: 'password123', role: 'ADMIN', enabled: true },
];

const skillsCatalog = [
  { id: 1, name: 'Java' },
  { id: 2, name: 'SQL' },
  { id: 3, name: 'Python' },
  { id: 4, name: 'React' },
  { id: 5, name: 'Spring Boot' },
  { id: 6, name: 'Machine Learning' },
  { id: 7, name: 'Node.js' }
];

const students = [
  {
    id: 1,
    userId: 1,
    name: 'Demo Student',
    prn: 'PRN2026CSE045',
    department: 'CSE',
    semester: 7,
    cgpa: 8.2,
    backlogs: 0,
    phone: '9876543210',
    internshipPreferences: 'Backend Development, Hybrid',
    certifications: 'Oracle Java SE',
    projects: 'Internship management portal (Spring Boot + MySQL)',
    verified: true,
  },
  {
    id: 2,
    userId: 2,
    name: 'Second Student',
    prn: 'PRN2026CSE046',
    department: 'CSE',
    semester: 7,
    cgpa: 7.9,
    backlogs: 1,
    phone: '9876543211',
    internshipPreferences: 'Web Development',
    certifications: '',
    projects: 'Personal Blog',
    verified: false,
  }
];

const studentSkills = [
  { id: 1, studentId: 1, skill: { id: 1, name: 'Java' }, proficiency: 'ADVANCED' },
  { id: 2, studentId: 1, skill: { id: 2, name: 'SQL' }, proficiency: 'ADVANCED' },
  { id: 3, studentId: 1, skill: { id: 3, name: 'Python' }, proficiency: 'INTERMEDIATE' },
  { id: 4, studentId: 2, skill: { id: 1, name: 'Java' }, proficiency: 'BEGINNER' }
];

const studentRecords = [
  { id: 1, studentId: 1, semester: 6, subject: 'Advanced Database Systems', marks: 88, sgpa: 8.4 },
  { id: 2, studentId: 1, semester: 6, subject: 'Cloud Computing & DevOps', marks: 82, sgpa: 8.0 }
];

const resumes = [
  {
    id: 1,
    studentId: 1,
    rawText: 'Demo Student. Education: B.Tech CSE CGPA 8.2. Projects: Internship Management Portal with Java, SQL, REST API, Spring Boot, MySQL. Skills: Java, SQL, Python, Git. Certification: Oracle Java SE. Experience: Software Intern.',
    resumeScore: 90,
    extractedSkills: 'JAVA, SQL, PYTHON, GIT, REST API, SPRING BOOT',
    fileBuffer: null,
    fileName: 'resume.txt'
  }
];

const documents = [];

const faculty = [
  { id: 1, userId: 3, name: 'Dr. Mehta', department: 'CSE' }
];

const companies = [
  { id: 1, userId: 4, companyName: 'NexaTech Solutions', industry: 'Software Services', contact: 'hr@nexatech.example' }
];

const internships = [
  {
    id: 1,
    companyId: 1,
    company: { id: 1, companyName: 'NexaTech Solutions', industry: 'Software Services', contact: 'hr@nexatech.example' },
    role: 'Backend Development Intern',
    description: 'Work on REST APIs and database design using Java and MySQL.',
    duration: '6 months',
    stipend: 15000.0,
    location: 'Pune',
    workMode: 'HYBRID',
    vacancies: 3,
    deadline: new Date(Date.now() + 60 * 24 * 3600 * 1000).toISOString().split('T')[0],
    interviewStages: 'APTITUDE_TEST,CODING_TEST,TECHNICAL,HR',
    status: 'OPEN',
    eligibilityCriteria: {
      id: 1,
      minCgpa: 7.5,
      maxBacklogs: 0,
      eligibleBranches: 'CSE,IT',
      requiredSkills: 'Java,SQL',
      minAtrScore: null,
      requiredSemester: null,
      requiredCertifications: null
    }
  },
  {
    id: 2,
    companyId: 1,
    company: { id: 1, companyName: 'NexaTech Solutions', industry: 'Software Services', contact: 'hr@nexatech.example' },
    role: 'Data Science Intern',
    description: 'Build and evaluate machine-learning models on real datasets.',
    duration: '6 months',
    stipend: 20000.0,
    location: 'Bengaluru',
    workMode: 'ONLINE',
    vacancies: 3,
    deadline: new Date(Date.now() + 60 * 24 * 3600 * 1000).toISOString().split('T')[0],
    interviewStages: 'APTITUDE_TEST,TECHNICAL',
    status: 'OPEN',
    eligibilityCriteria: {
      id: 2,
      minCgpa: 9.0,
      maxBacklogs: 0,
      eligibleBranches: 'CSE',
      requiredSkills: 'Python,Machine Learning',
      minAtrScore: 60.0,
      requiredSemester: null,
      requiredCertifications: null
    }
  }
];

const applications = [];
const interviews = [];
const assessments = [];
const offers = [];
const notifications = [
  {
    id: 1,
    userId: 1,
    type: 'SYSTEM',
    message: 'Welcome to the Internship Management & Eligibility Portal.',
    read: false,
    createdAt: new Date().toISOString()
  }
];
const verifications = [];

// Helper functions
function findUserByEmail(email) {
  return users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
}

function findStudentByUser(user) {
  return students.find(s => s.userId === user.id);
}

function findCompanyByUser(user) {
  return companies.find(c => c.userId === user.id);
}

function findFacultyByUser(user) {
  return faculty.find(f => f.userId === user.id);
}

function evaluateEligibility(student, criteria) {
  const reasons = [];
  if (!student.verified) {
    reasons.push('Your profile has not been verified by faculty yet');
  }
  if (criteria) {
    if (criteria.minCgpa != null && student.cgpa != null && student.cgpa < criteria.minCgpa) {
      reasons.push(`CGPA ${student.cgpa} is below the required minimum ${criteria.minCgpa}`);
    }
    if (criteria.maxBacklogs != null && student.backlogs != null && student.backlogs > criteria.maxBacklogs) {
      reasons.push(`Backlogs ${student.backlogs} exceed the allowed maximum ${criteria.maxBacklogs}`);
    }
    if (criteria.eligibleBranches && criteria.eligibleBranches.trim()) {
      const allowed = criteria.eligibleBranches.split(',').map(b => b.trim().toUpperCase());
      if (!student.department || !allowed.includes(student.department.trim().toUpperCase())) {
        reasons.push(`Branch ${student.department} is not in the eligible list: ${criteria.eligibleBranches}`);
      }
    }
    if (criteria.requiredSemester != null && student.semester != null && criteria.requiredSemester !== student.semester) {
      reasons.push(`Requires semester ${criteria.requiredSemester}, student is in semester ${student.semester}`);
    }
    if (criteria.requiredSkills && criteria.requiredSkills.trim()) {
      const reqSkills = criteria.requiredSkills.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      const studentSkillNames = studentSkills
        .filter(ss => ss.studentId === student.id)
        .map(ss => ss.skill.name.trim().toUpperCase());
      const missing = reqSkills.filter(s => !studentSkillNames.includes(s));
      if (missing.length > 0) {
        reasons.push(`Missing required skills: ${missing.join(', ')}`);
      }
    }
    if (criteria.requiredCertifications && criteria.requiredCertifications.trim()) {
      const reqCerts = criteria.requiredCertifications.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      const studentCerts = (student.certifications || '').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      const missingCerts = reqCerts.filter(c => !studentCerts.includes(c));
      if (missingCerts.length > 0) {
        reasons.push(`Missing required certifications: ${missingCerts.join(', ')}`);
      }
    }
  }
  return {
    eligible: reasons.length === 0,
    reasons
  };
}

function computeResumeCompleteness(text) {
  if (!text) return 0;
  const upper = text.toUpperCase();
  let score = 0;
  if (upper.includes('EDUCATION')) score += 20;
  if (upper.includes('PROJECT')) score += 20;
  if (upper.includes('SKILL')) score += 20;
  if (upper.includes('CERTIFICATION') || upper.includes('CERTIFICATE')) score += 15;
  if (upper.includes('EXPERIENCE') || upper.includes('INTERNSHIP')) score += 15;
  if (text.length > 800) score += 10;
  return Math.min(100, score);
}

function computeResumeMatchScore(text, requiredSkillsCsv) {
  if (!requiredSkillsCsv || !requiredSkillsCsv.trim()) return 100;
  const req = requiredSkillsCsv.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
  if (req.length === 0) return 100;
  if (!text) return 0;
  const norm = ' ' + text.toUpperCase().replace(/[^A-Z0-9+#. ]/g, ' ').replace(/\s+/g, ' ') + ' ';
  let matched = 0;
  for (const s of req) {
    if (norm.includes(' ' + s + ' ')) matched++;
  }
  return Math.round((matched * 100) / req.length);
}

function notify(userId, type, message) {
  const notif = {
    id: genId(),
    userId,
    type,
    message,
    read: false,
    createdAt: new Date().toISOString()
  };
  notifications.unshift(notif);
}

// Auth Middleware
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization required' });
  }
  const token = authHeader.substring(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = users.find(u => u.id === decoded.id);
    if (!user || !user.enabled) {
      return res.status(401).json({ message: 'User invalid or disabled' });
    }
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Session expired - please log in again' });
  }
}

// ----------------- AUTH ROUTES -----------------
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = findUserByEmail(email);
  if (!user || user.password !== password) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  if (!user.enabled) {
    return res.status(403).json({ message: 'Account is disabled' });
  }

  let profileId = null;
  if (user.role === 'STUDENT') {
    const s = findStudentByUser(user);
    if (s) profileId = s.id;
  } else if (user.role === 'COMPANY') {
    const c = findCompanyByUser(user);
    if (c) profileId = c.id;
  } else if (user.role === 'FACULTY') {
    const f = findFacultyByUser(user);
    if (f) profileId = f.id;
  }

  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({
    token,
    accessToken: token,
    refreshToken: token,
    tokenType: 'Bearer',
    email: user.email,
    role: user.role,
    profileId
  });
});

app.post('/api/auth/register', (req, res) => {
  const { email, password, role, name, prn, department, facultyDepartment, companyName, industry } = req.body;
  if (!email || !password || !role) {
    return res.status(400).json({ message: 'Email, password, and role are required' });
  }
  if (findUserByEmail(email)) {
    return res.status(400).json({ message: 'User with this email already exists' });
  }

  const user = {
    id: genId(),
    email,
    password,
    role,
    enabled: true
  };
  users.push(user);

  let profileId = null;
  if (role === 'STUDENT') {
    const student = {
      id: genId(),
      userId: user.id,
      name: name || 'Student',
      prn: prn || '',
      department: department || 'CSE',
      semester: 1,
      cgpa: 0,
      backlogs: 0,
      phone: '',
      internshipPreferences: '',
      certifications: '',
      projects: '',
      verified: false
    };
    students.push(student);
    profileId = student.id;
  } else if (role === 'FACULTY') {
    const f = {
      id: genId(),
      userId: user.id,
      name: name || 'Faculty Member',
      department: facultyDepartment || department || 'CSE'
    };
    faculty.push(f);
    profileId = f.id;
  } else if (role === 'COMPANY') {
    const c = {
      id: genId(),
      userId: user.id,
      companyName: companyName || 'Company',
      industry: industry || 'Tech',
      contact: email
    };
    companies.push(c);
    profileId = c.id;
  }

  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({
    token,
    accessToken: token,
    refreshToken: token,
    tokenType: 'Bearer',
    email: user.email,
    role: user.role,
    profileId
  });
});

app.post('/api/auth/refresh', (req, res) => {
  const token = req.body?.refreshToken || req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ message: 'No token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = users.find(u => u.id === decoded.id);
    if (!user) return res.status(401).json({ message: 'User not found' });
    const newToken = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({
      token: newToken,
      accessToken: newToken,
      refreshToken: newToken,
      tokenType: 'Bearer',
      email: user.email,
      role: user.role
    });
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  return res.json({ message: 'Logged out successfully' });
});

// ----------------- STUDENT ROUTES -----------------
app.get('/api/students/me', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student profile not found' });
  res.json(student);
});

app.put('/api/students/me', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student profile not found' });

  const { name, department, semester, cgpa, backlogs, phone, internshipPreferences, certifications, projects } = req.body;
  if (name !== undefined) student.name = name;
  if (department !== undefined) student.department = department;
  if (semester !== undefined) student.semester = semester;
  if (cgpa !== undefined) student.cgpa = cgpa;
  if (backlogs !== undefined) student.backlogs = backlogs;
  if (phone !== undefined) student.phone = phone;
  if (internshipPreferences !== undefined) student.internshipPreferences = internshipPreferences;
  if (certifications !== undefined) student.certifications = certifications;
  if (projects !== undefined) student.projects = projects;

  res.json(student);
});

// Academic records
app.get('/api/students/me/academic-records', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  const records = studentRecords.filter(r => r.studentId === student.id);
  res.json(records);
});

app.post('/api/students/me/academic-records', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  const { semester, subject, marks, sgpa } = req.body;
  const rec = { id: genId(), studentId: student.id, semester, subject, marks, sgpa };
  studentRecords.push(rec);
  res.json(rec);
});

app.delete('/api/students/me/academic-records/:id', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const id = Number(req.params.id);
  const idx = studentRecords.findIndex(r => r.id === id && r.studentId === student.id);
  if (idx !== -1) studentRecords.splice(idx, 1);
  res.json({ message: 'Deleted' });
});

app.post('/api/students/me/academic-records/recalculate-cgpa', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const records = studentRecords.filter(r => r.studentId === student.id && r.sgpa != null);
  if (records.length > 0) {
    const avg = records.reduce((sum, r) => sum + Number(r.sgpa), 0) / records.length;
    student.cgpa = Math.round(avg * 100) / 100;
  }
  student.verified = false;
  res.json(student);
});

// Skills
app.get('/api/students/me/skills', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  const list = studentSkills.filter(s => s.studentId === student.id);
  res.json(list);
});

app.put('/api/students/me/skills', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  const { skills: skillNames } = req.body;

  // Remove existing
  for (let i = studentSkills.length - 1; i >= 0; i--) {
    if (studentSkills[i].studentId === student.id) {
      studentSkills.splice(i, 1);
    }
  }

  // Add new
  const updated = [];
  if (Array.isArray(skillNames)) {
    for (const name of skillNames) {
      let skillObj = skillsCatalog.find(s => s.name.toUpperCase() === name.toUpperCase());
      if (!skillObj) {
        skillObj = { id: genId(), name };
        skillsCatalog.push(skillObj);
      }
      const entry = { id: genId(), studentId: student.id, skill: skillObj, proficiency: 'INTERMEDIATE' };
      studentSkills.push(entry);
      updated.push(entry);
    }
  }
  res.json(updated);
});

// Resume
app.get('/api/students/me/resume', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const r = resumes.find(item => item.studentId === student.id);
  if (!r) return res.status(404).json({ message: 'Resume not found' });
  res.json(r);
});

app.post('/api/students/me/resume', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const { rawText } = req.body;
  let r = resumes.find(item => item.studentId === student.id);
  const score = computeResumeCompleteness(rawText);

  // Extract skills
  const extracted = skillsCatalog
    .filter(s => (' ' + (rawText || '').toUpperCase() + ' ').includes(' ' + s.name.toUpperCase() + ' '))
    .map(s => s.name.toUpperCase())
    .join(', ');

  if (!r) {
    r = { id: genId(), studentId: student.id, rawText, resumeScore: score, extractedSkills: extracted, filePath: null, fileName: null };
    resumes.push(r);
  } else {
    r.rawText = rawText;
    r.resumeScore = score;
    r.extractedSkills = extracted;
  }
  res.json(r);
});

app.post('/api/students/me/resume/file', authMiddleware, upload.single('file'), (req, res) => {
  const student = findStudentByUser(req.user);
  const file = req.file;
  if (!file) return res.status(400).json({ message: 'File is required' });

  const rawText = file.buffer.toString('utf-8');
  const score = computeResumeCompleteness(rawText);
  const extracted = skillsCatalog
    .filter(s => (' ' + rawText.toUpperCase() + ' ').includes(' ' + s.name.toUpperCase() + ' '))
    .map(s => s.name.toUpperCase())
    .join(', ');

  let r = resumes.find(item => item.studentId === student.id);
  if (!r) {
    r = {
      id: genId(),
      studentId: student.id,
      rawText,
      resumeScore: score,
      extractedSkills: extracted,
      fileBuffer: file.buffer,
      fileName: file.originalname,
      filePath: '/students/me/resume/file'
    };
    resumes.push(r);
  } else {
    r.rawText = rawText;
    r.resumeScore = score;
    r.extractedSkills = extracted;
    r.fileBuffer = file.buffer;
    r.fileName = file.originalname;
    r.filePath = '/students/me/resume/file';
  }
  res.json(r);
});

app.get('/api/students/me/resume/file', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const r = resumes.find(item => item.studentId === student.id);
  if (!r || (!r.fileBuffer && !r.rawText)) {
    return res.status(404).send('Resume file not found');
  }
  const content = r.fileBuffer || Buffer.from(r.rawText || '', 'utf-8');
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', `inline; filename="${r.fileName || 'resume.txt'}"`);
  res.send(content);
});

// Documents
app.get('/api/students/me/documents', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const docs = documents.filter(d => d.studentId === student.id);
  res.json(docs);
});

app.post('/api/students/me/documents', authMiddleware, upload.single('file'), (req, res) => {
  const student = findStudentByUser(req.user);
  const { documentType } = req.body;
  const file = req.file;
  const doc = {
    id: genId(),
    studentId: student.id,
    documentType: documentType || 'MARKSHEET',
    fileName: file ? file.originalname : 'document.pdf',
    fileBuffer: file ? file.buffer : Buffer.from('Sample Document Content', 'utf-8'),
    verificationStatus: 'PENDING',
    createdAt: new Date().toISOString()
  };
  documents.push(doc);
  res.json(doc);
});

app.get('/api/students/me/documents/:id/file', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const doc = documents.find(d => d.id === Number(req.params.id) && d.studentId === student.id);
  if (!doc) return res.status(404).send('Document not found');
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${doc.fileName}"`);
  res.send(doc.fileBuffer);
});

// Browse Internships
app.get('/api/students/me/internships', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  if (!student) return res.status(404).json({ message: 'Student not found' });

  const openInternships = internships.filter(i => i.status === 'OPEN');
  const views = openInternships.map(internship => {
    const { eligible, reasons } = evaluateEligibility(student, internship.eligibilityCriteria);
    const applied = applications.some(a => a.studentId === student.id && a.internshipId === internship.id && a.status !== 'WITHDRAWN');
    return {
      internship,
      eligible,
      reasons,
      applied
    };
  });
  res.json(views);
});

app.get('/api/students/me/eligible-internships', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const openInternships = internships.filter(i => i.status === 'OPEN');
  const eligible = openInternships.filter(i => evaluateEligibility(student, i.eligibilityCriteria).eligible);
  res.json(eligible);
});

app.post('/api/students/me/applications/:internshipId', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const internshipId = Number(req.params.internshipId);
  const internship = internships.find(i => i.id === internshipId);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });

  const evalResult = evaluateEligibility(student, internship.eligibilityCriteria);
  if (!evalResult.eligible) {
    return res.status(400).json({ message: 'Not eligible to apply: ' + evalResult.reasons.join(', ') });
  }

  const existing = applications.find(a => a.studentId === student.id && a.internshipId === internshipId && a.status !== 'WITHDRAWN');
  if (existing) {
    return res.status(400).json({ message: 'Already applied' });
  }

  const resume = resumes.find(r => r.studentId === student.id);
  const matchScore = computeResumeMatchScore(resume ? resume.rawText : '', internship.eligibilityCriteria?.requiredSkills);

  const appObj = {
    id: genId(),
    studentId: student.id,
    student,
    internshipId: internship.id,
    internship,
    applicationDate: new Date().toISOString(),
    status: 'APPLIED',
    resumeMatchScore: matchScore
  };
  applications.push(appObj);

  // Notify company
  const companyUser = users.find(u => u.id === internship.company.userId || (companies.find(c => c.id === internship.companyId)?.userId === u.id));
  if (companyUser) {
    notify(companyUser.id, 'APPLICATION', `${student.name} applied for ${internship.role}`);
  }
  notify(req.user.id, 'APPLICATION', `Your application for ${internship.role} at ${internship.company.companyName} was submitted`);

  res.json(appObj);
});

app.get('/api/students/me/applications', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const list = applications.filter(a => a.studentId === student.id);
  res.json(list);
});

app.delete('/api/students/me/applications/:applicationId', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const appId = Number(req.params.applicationId);
  const appObj = applications.find(a => a.id === appId && a.studentId === student.id);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  if (['SELECTED', 'REJECTED', 'WITHDRAWN'].includes(appObj.status)) {
    return res.status(400).json({ message: 'Application cannot be withdrawn' });
  }
  appObj.status = 'WITHDRAWN';
  res.json({ message: 'Withdrawn' });
});

app.get('/api/students/me/applications/:applicationId/interviews', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const list = interviews.filter(i => i.applicationId === appId);
  res.json(list);
});

app.get('/api/students/me/offers', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const list = offers.filter(o => o.application.studentId === student.id);
  res.json(list);
});

app.post('/api/students/me/offers/:offerId/respond', authMiddleware, (req, res) => {
  const student = findStudentByUser(req.user);
  const offerId = Number(req.params.offerId);
  const status = req.query.status;
  const offer = offers.find(o => o.id === offerId && o.application.studentId === student.id);
  if (!offer) return res.status(404).json({ message: 'Offer not found' });
  offer.status = status;
  res.json(offer);
});

// ----------------- COMPANY ROUTES -----------------
app.get('/api/companies/me', authMiddleware, (req, res) => {
  const c = findCompanyByUser(req.user);
  if (!c) return res.status(404).json({ message: 'Company not found' });
  res.json(c);
});

app.get('/api/companies/me/internships', authMiddleware, (req, res) => {
  const c = findCompanyByUser(req.user);
  if (!c) return res.status(404).json({ message: 'Company not found' });
  const list = internships.filter(i => i.companyId === c.id);
  res.json(list);
});

app.post('/api/companies/me/internships', authMiddleware, (req, res) => {
  const c = findCompanyByUser(req.user);
  if (!c) return res.status(404).json({ message: 'Company not found' });

  const {
    role, description, duration, stipend, location, workMode, vacancies, deadline,
    interviewStages, minCgpa, maxBacklogs, eligibleBranches, requiredSkills,
    requiredCertifications, requiredSemester, minResumeScore, minAtrScore
  } = req.body;

  const internship = {
    id: genId(),
    companyId: c.id,
    company: c,
    role,
    description,
    duration,
    stipend,
    location,
    workMode,
    vacancies: vacancies || 1,
    deadline: deadline || null,
    interviewStages: interviewStages || 'TECHNICAL,HR',
    status: 'OPEN',
    eligibilityCriteria: {
      id: genId(),
      minCgpa: minCgpa ?? 0,
      maxBacklogs: maxBacklogs ?? 99,
      eligibleBranches: eligibleBranches || '',
      requiredSkills: requiredSkills || '',
      requiredCertifications: requiredCertifications || '',
      requiredSemester: requiredSemester || null,
      minResumeScore: minResumeScore || null,
      minAtrScore: minAtrScore || null
    }
  };
  internships.push(internship);
  res.json(internship);
});

app.put(['/api/companies/me/internships/:id', '/api/companies/me/internships/:id/criteria'], authMiddleware, (req, res) => {
  const c = findCompanyByUser(req.user);
  const id = Number(req.params.id);
  const internship = internships.find(i => i.id === id && i.companyId === c.id);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });

  const { minCgpa, maxBacklogs, eligibleBranches, requiredSkills, description, stipend, location, workMode } = req.body;
  if (description !== undefined) internship.description = description;
  if (stipend !== undefined) internship.stipend = stipend;
  if (location !== undefined) internship.location = location;
  if (workMode !== undefined) internship.workMode = workMode;

  if (internship.eligibilityCriteria) {
    if (minCgpa !== undefined) internship.eligibilityCriteria.minCgpa = minCgpa;
    if (maxBacklogs !== undefined) internship.eligibilityCriteria.maxBacklogs = maxBacklogs;
    if (eligibleBranches !== undefined) internship.eligibilityCriteria.eligibleBranches = eligibleBranches;
    if (requiredSkills !== undefined) internship.eligibilityCriteria.requiredSkills = requiredSkills;
  }
  res.json(internship);
});

app.post('/api/companies/me/internships/:id/close', authMiddleware, (req, res) => {
  const c = findCompanyByUser(req.user);
  const id = Number(req.params.id);
  const internship = internships.find(i => i.id === id && i.companyId === c.id);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });
  internship.status = 'CLOSED';
  res.json({ message: 'Closed' });
});

app.get('/api/companies/me/internships/:id/applications', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const list = applications.filter(a => a.internshipId === id);
  res.json(list);
});

app.get('/api/companies/me/internships/:id/ranking', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const apps = applications.filter(a => a.internshipId === id && a.status !== 'WITHDRAWN');

  const ranked = apps.map(app => {
    const assess = assessments.find(asm => asm.applicationId === app.id);
    const atr = assess?.atrScore ?? null;
    const resume = app.resumeMatchScore ?? 0;
    const composite = Math.round((resume * 0.6 + (atr != null ? atr : 0) * 0.4) * 10) / 10;
    return {
      application: app,
      resumeMatchScore: app.resumeMatchScore,
      atrScore: atr,
      compositeScore: composite
    };
  });
  ranked.sort((a, b) => b.compositeScore - a.compositeScore);
  res.json(ranked);
});

app.get('/api/companies/me/internships/:id/eligible-students', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const internship = internships.find(i => i.id === id);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });

  const eligible = students
    .filter(s => evaluateEligibility(s, internship.eligibilityCriteria).eligible)
    .map(s => ({
      id: s.id,
      name: s.name,
      department: s.department,
      cgpa: s.cgpa,
      backlogs: s.backlogs,
      verified: s.verified
    }));
  res.json(eligible);
});

app.post('/api/companies/me/applications/:applicationId/shortlist', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  appObj.status = 'COMPANY_SHORTLISTED';
  notify(appObj.student.userId, 'SHORTLIST', `${appObj.internship.company.companyName} shortlisted you for ${appObj.internship.role}`);
  res.json(appObj);
});

app.post('/api/companies/me/applications/:applicationId/select', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  appObj.status = 'SELECTED';
  notify(appObj.student.userId, 'SELECTION', `Congratulations! You have been selected for ${appObj.internship.role}`);
  res.json(appObj);
});

app.post('/api/companies/me/applications/:applicationId/reject', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const reason = req.query.reason || '';
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  appObj.status = 'REJECTED';
  notify(appObj.student.userId, 'REJECTION', `Your application for ${appObj.internship.role} was not selected${reason ? ': ' + reason : ''}`);
  res.json(appObj);
});

app.post('/api/companies/me/applications/:applicationId/offer', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });

  const offer = {
    id: genId(),
    applicationId: appObj.id,
    application: appObj,
    status: 'EXTENDED',
    offerDate: new Date().toISOString().split('T')[0]
  };
  offers.push(offer);
  notify(appObj.student.userId, 'OFFER', `You have received an internship offer from ${appObj.internship.company.companyName}`);
  res.json(offer);
});

// ----------------- FACULTY ROUTES -----------------
app.get('/api/faculty/me', authMiddleware, (req, res) => {
  const f = findFacultyByUser(req.user);
  if (!f) return res.status(404).json({ message: 'Faculty not found' });
  res.json(f);
});

app.get('/api/faculty/students', authMiddleware, (req, res) => {
  res.json(students);
});

app.get('/api/faculty/students/:studentId/documents', authMiddleware, (req, res) => {
  const studentId = Number(req.params.studentId);
  const docs = documents.filter(d => d.studentId === studentId);
  res.json(docs);
});

app.get('/api/faculty/documents/:documentId/file', authMiddleware, (req, res) => {
  const doc = documents.find(d => d.id === Number(req.params.documentId));
  if (!doc) return res.status(404).send('Document not found');
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${doc.fileName}"`);
  res.send(doc.fileBuffer);
});

app.post('/api/faculty/documents/:documentId/verify', authMiddleware, (req, res) => {
  const doc = documents.find(d => d.id === Number(req.params.documentId));
  if (!doc) return res.status(404).json({ message: 'Document not found' });
  doc.verificationStatus = req.query.status || 'VERIFIED';
  res.json(doc);
});

app.post('/api/faculty/students/:studentId/verify', authMiddleware, (req, res) => {
  const studentId = Number(req.params.studentId);
  const student = students.find(s => s.id === studentId);
  if (!student) return res.status(404).json({ message: 'Student not found' });
  const status = req.query.status || 'VERIFIED';
  student.verified = (status === 'VERIFIED');

  const ver = {
    id: genId(),
    studentId,
    verifiedBy: req.user.id,
    type: req.query.type || 'PROFILE',
    status,
    remarks: req.query.remarks || '',
    createdAt: new Date().toISOString()
  };
  verifications.push(ver);
  notify(student.userId, 'VERIFICATION', `Your profile was marked as ${status} by faculty.`);
  res.json(ver);
});

app.get('/api/faculty/applications', authMiddleware, (req, res) => {
  res.json(applications);
});

app.post('/api/faculty/applications/:applicationId/shortlist', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  appObj.status = 'FACULTY_SHORTLISTED';
  notify(appObj.student.userId, 'SHORTLIST', `Faculty has shortlisted your application for ${appObj.internship.role}`);
  res.json(appObj);
});

app.post('/api/faculty/applications/:applicationId/reject', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const reason = req.query.reason || '';
  const appObj = applications.find(a => a.id === appId);
  if (!appObj) return res.status(404).json({ message: 'Application not found' });
  appObj.status = 'REJECTED';
  notify(appObj.student.userId, 'REJECTION', `Application for ${appObj.internship.role} was rejected by faculty${reason ? ': ' + reason : ''}`);
  res.json(appObj);
});

app.get('/api/faculty/internships/pending', authMiddleware, (req, res) => {
  const list = internships.filter(i => i.status === 'PENDING_APPROVAL');
  res.json(list);
});

app.post('/api/faculty/internships/:id/approve', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const internship = internships.find(i => i.id === id);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });
  internship.status = 'OPEN';
  res.json(internship);
});

app.post('/api/faculty/internships/:id/decline', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const internship = internships.find(i => i.id === id);
  if (!internship) return res.status(404).json({ message: 'Internship not found' });
  internship.status = 'REJECTED';
  res.json(internship);
});

// ----------------- INTERVIEWS & ASSESSMENTS -----------------
app.post('/api/interviews/schedule', authMiddleware, (req, res) => {
  const { applicationId, type, scheduledDate, mode } = req.body;
  const appObj = applications.find(a => a.id === Number(applicationId));
  if (!appObj) return res.status(404).json({ message: 'Application not found' });

  const existingInterviews = interviews.filter(i => i.applicationId === appObj.id);
  const round = existingInterviews.length + 1;

  const interview = {
    id: genId(),
    applicationId: appObj.id,
    round,
    type: type || 'TECHNICAL',
    scheduledDate,
    mode: mode || 'ONLINE',
    result: 'PENDING',
    remarks: ''
  };
  interviews.push(interview);
  appObj.status = 'INTERVIEW_SCHEDULED';

  notify(appObj.student.userId, 'INTERVIEW', `Round ${round} (${interview.type}) interview scheduled for ${scheduledDate}`);
  res.json(interview);
});

app.post('/api/interviews/:id/result', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const { result, remarks } = req.body;
  const interview = interviews.find(i => i.id === id);
  if (!interview) return res.status(404).json({ message: 'Interview not found' });
  interview.result = result;
  if (remarks !== undefined) interview.remarks = remarks;

  const appObj = applications.find(a => a.id === interview.applicationId);
  if (appObj) {
    notify(appObj.student.userId, 'INTERVIEW_RESULT', `Interview Round ${interview.round} result: ${result}`);
  }
  res.json(interview);
});

app.get('/api/interviews/application/:applicationId', authMiddleware, (req, res) => {
  const appId = Number(req.params.applicationId);
  const list = interviews.filter(i => i.applicationId === appId);
  res.json(list);
});

app.post('/api/interviews/assessment', authMiddleware, (req, res) => {
  const { applicationId, atrScore, aptitudeScore, codingScore } = req.body;
  const appId = Number(applicationId);
  let asm = assessments.find(a => a.applicationId === appId);
  if (!asm) {
    asm = { id: genId(), applicationId: appId, atrScore: null, aptitudeScore: null, codingScore: null };
    assessments.push(asm);
  }
  if (atrScore !== undefined) asm.atrScore = atrScore;
  if (aptitudeScore !== undefined) asm.aptitudeScore = aptitudeScore;
  if (codingScore !== undefined) asm.codingScore = codingScore;
  res.json(asm);
});

// ----------------- NOTIFICATIONS -----------------
app.get('/api/notifications/me', authMiddleware, (req, res) => {
  const list = notifications.filter(n => n.userId === req.user.id);
  res.json(list);
});

app.get('/api/notifications/me/paged', authMiddleware, (req, res) => {
  const list = notifications.filter(n => n.userId === req.user.id);
  res.json({ content: list, totalElements: list.length });
});

app.post('/api/notifications/:id/read', authMiddleware, (req, res) => {
  const notif = notifications.find(n => n.id === Number(req.params.id) && n.userId === req.user.id);
  if (notif) notif.read = true;
  res.json({ message: 'Marked as read' });
});

app.post('/api/notifications/read-all', authMiddleware, (req, res) => {
  notifications.filter(n => n.userId === req.user.id).forEach(n => n.read = true);
  res.json({ message: 'All notifications marked as read' });
});

app.get('/api/notifications/stream', authMiddleware, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.write('data: {"type":"CONNECTED"}\n\n');
  const timer = setInterval(() => {
    res.write('data: {"type":"PING"}\n\n');
  }, 30000);
  req.on('close', () => clearInterval(timer));
});

// ----------------- REPORTS -----------------
app.get('/api/reports/summary', (req, res) => {
  const openInternships = internships.filter(i => i.status === 'OPEN');
  const eligibleStudents = students.filter(s =>
    openInternships.some(i => evaluateEligibility(s, i.eligibilityCriteria).eligible)
  ).length;

  const shortlistedStates = ['FACULTY_SHORTLISTED', 'COMPANY_SHORTLISTED', 'INTERVIEW_SCHEDULED', 'SELECTED'];
  const shortlistedCount = applications.filter(a => shortlistedStates.includes(a.status)).length;
  const selectedStudents = new Set(applications.filter(a => a.status === 'SELECTED').map(a => a.studentId)).size;

  const applicationsByStatus = {
    APPLIED: applications.filter(a => a.status === 'APPLIED').length,
    FACULTY_SHORTLISTED: applications.filter(a => a.status === 'FACULTY_SHORTLISTED').length,
    COMPANY_SHORTLISTED: applications.filter(a => a.status === 'COMPANY_SHORTLISTED').length,
    INTERVIEW_SCHEDULED: applications.filter(a => a.status === 'INTERVIEW_SCHEDULED').length,
    SELECTED: applications.filter(a => a.status === 'SELECTED').length,
    REJECTED: applications.filter(a => a.status === 'REJECTED').length,
    WITHDRAWN: applications.filter(a => a.status === 'WITHDRAWN').length,
  };

  const internshipWise = {};
  const companyWise = {};
  const departmentWise = {};

  for (const a of applications) {
    const iKey = `${a.internship.role} @ ${a.internship.company?.companyName || 'Company'}`;
    internshipWise[iKey] = (internshipWise[iKey] || 0) + 1;

    const cKey = a.internship.company?.companyName || 'Unknown';
    companyWise[cKey] = (companyWise[cKey] || 0) + 1;

    const dKey = a.student?.department || 'Unknown';
    departmentWise[dKey] = (departmentWise[dKey] || 0) + 1;
  }

  res.json({
    totalStudents: students.length,
    verifiedStudents: students.filter(s => s.verified).length,
    eligibleStudents,
    selectedStudents,
    totalInternships: internships.length,
    openInternships: openInternships.length,
    totalApplications: applications.length,
    shortlistedApplications: shortlistedCount,
    applicationsByStatus,
    internshipWise,
    companyWise,
    departmentWise
  });
});

// ----------------- ADMIN -----------------
app.get('/api/admin/users', authMiddleware, (req, res) => {
  res.json(users.map(u => ({ id: u.id, email: u.email, role: u.role, enabled: u.enabled })));
});

app.post('/api/admin/users/:id/enabled', authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  const val = req.query.value === 'true';
  const u = users.find(user => user.id === id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  if (req.user.id === id) {
    return res.status(400).json({ message: 'You cannot disable your own account' });
  }
  u.enabled = val;
  res.json({ message: 'Updated' });
});

// ----------------- STATIC ASSETS & SPA SERVING -----------------
const distDir = path.join(__dirname, 'dist');
const publicDir = path.join(__dirname, 'public');
const staticDir = fs.existsSync(distDir) ? distDir : publicDir;

app.use(express.static(staticDir));

app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ error: 'Endpoint not found' });
  }
  const file = path.join(staticDir, req.path);
  if (fs.existsSync(file) && fs.statSync(file).isFile()) {
    return res.sendFile(file);
  }
  const distIndex = path.join(distDir, 'index.html');
  if (fs.existsSync(distIndex)) {
    return res.sendFile(distIndex);
  }
  const rootIndex = path.join(__dirname, 'index.html');
  if (fs.existsSync(rootIndex)) {
    return res.sendFile(rootIndex);
  }
  res.sendFile(path.join(publicDir, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Internship Eligibility Portal server running on http://0.0.0.0:${PORT}`);
});
